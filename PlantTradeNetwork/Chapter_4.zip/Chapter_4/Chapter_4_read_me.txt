#Read me document for all the code used to produce the results in chapter 4


#Rcpp R package ArmaDiseaseFuns,
	o	Package has one script with all the functions for simulating the disease spread on the network


#ArmaDiseaseFuns/src/Armadillo_Disease_Function.cpp
	o	Implements the SI disease spread model from chapter 4
	o	Includes additional functions to run a simpler version of the SI model with no control measures and functions to run many iterations of the model


#Armadillo_version/R_functions_For_Armadillo_Version.R
	o	Script with the functions to run the disease model, input parameter values and run the model in parallel.
	o	Code creates the network to simulate disease spread on
	o	Parallel code runs the same parameter set for seedings in the 4 different node groups


##CODE FOR ANALYSIS


#Armadillo_version/vary_alpha_out_r.R
	o	Code to vary the trade inspection parameter alpha_out with the scheduled inspection parameter r


#Armadillo_version/vary_alpha_in_alpha_out_r.R
	o	Code to vary the trade inspection parameter alpha_out with the scheduled inspection parameter r


#Armadillo_version/v_a_in_out_r_freq_rem_start.R
	o	Code to vary both trade inspection parameters (alpha_in, alpha_out), scheduled inspection parameter r, and different values of inspection frequency (tau) and timepoint of first inspection (z)


#Armadillo_version/vary_alpha_out.R
	o	Code to vary just the outgoing trade inspection parameter alpha_out


#Armadillo_version/vary_betas.R
	o	Code to vary beta values for the "do nothing" version of the disease spread model, where there are no disease control measures 


#Armadillo_version/vary_death_rates.R
	o	Code to vary death rate values for susceptible and infected plants (d_S, d_I) for the "do nothing" version of the disease spread model, where there are no disease control measures 


#Armadillo_version/vary_removals.R
	o	Code to vary the scheduled inspection efficacy parameter r


##PLOTTING CODE

#Armadillo_version/plotting_v_alpha_in_alpha_out_r_hm.R
	o	Code to plot heatmaps for varying both ingoing and outgoing trade inspections (alphas) and the scheduled inspections (r)


#Armadillo_version/plotting_v_alpha_out_r_hm.R
	o	Code to plot heatmaps for varying outgoing trade inspections only (alpha_out) and the scheduled inspections (r)


#Armadillo_version/plotting_heatmap.R
	o	Code to plot heatmaps using the metrics (proportion infected by t=36, time until 20% infected, cost of disease/inspections) for:
		-	varying both trade inspection parameters (alpha_in and alpha_out) and the removal parameter r for different values of inspection frequency (tau) and timepoint of first inspection (z)
		-	Comparing cost of more/less frequent inspections for varied inspection costs


#Armadillo_version/plotting_variation_seeding_network.R
	o	Code for producing a variety of plots: 
		-	timeseries linegraphs for disease progression per node subcategory
		-	median and quantiles plots for varying beta (using the measures proportion infected by t=36, and time until 20% infected)
		 	varying single parameter plots
	 		includes plotting for different nursery scenarios
		-	boxplots for varying death rate parameters
		-	boxplots for varying removal parameter
		-	boxplots for varying trade inspection parameters (alpha_in and alpha_out, alpha_out)