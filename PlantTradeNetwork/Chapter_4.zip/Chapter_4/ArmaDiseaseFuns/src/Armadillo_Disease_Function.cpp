#include <RcppArmadillo.h>
#include <RcppArmadilloExtensions/sample.h>
// [[Rcpp::depends(RcppArmadillo)]]


//using namespace arma;
//using namespace Rcpp;



// how to create and add to a list:
//Rcpp::List ret;

//ret["a_1"] = a_1;
//ret["a_2"] = a_2;


// [[Rcpp::export]]


int mod(int a, double n){
  
  
  return a - floor(a/n)*n;
}



//arma::rowvec Arma_colSums( arma::mat& x) {
//  return arma::sum(x, 0);
//}
// Rows ----------------


//arma::colvec Arma_rowSums( arma::mat& x) {
//  return arma::sum(x, 1);
//}


// [[Rcpp::export]]

arma::mat Arma_sp_colsums( arma::sp_mat A_matrix ){
  

  arma::mat sumCols = A_matrix.t() * arma::ones(A_matrix.n_rows, 1);
  
    
    return sumCols ;
    
    }

// [[Rcpp::export]]
arma::mat Arma_sp_rowsums( arma::sp_mat A_matrix ){
  
  
  arma::mat sumrows = A_matrix * arma::ones(A_matrix.n_cols, 1);
  
  
  
  return sumrows ;
  
}


// [[Rcpp::export]]
arma::mat N_sizes_function(
    arma::sp_mat A_matrix
){
 // int ncol_A = A_matrix.n_cols;
  arma::mat row_sums = Arma_sp_rowsums( A_matrix );
  arma::mat col_sums = Arma_sp_colsums(A_matrix);
  arma::mat N_sizes = max(row_sums, col_sums ) * 12 ;
  
  return N_sizes ;    
}


// SI_array has dimensions (time, SI, Node_group ) = (params_list$time, 2, 7)

/*
arma::cube Virus_SI_Sim_Fun(
    
    arma::sp_mat A_matrix,
    arma::vec param_vec){
  
  
  // will be inputs later, but for testing...
  
  double  alpha_n_in  = param_vec(0);
  double  alpha_n_out  = param_vec(1);
  double  alpha_r_in = param_vec(2);
  double  alpha_r_out = param_vec(3);
  double  p_grown = param_vec(4);
  double  beta_n = param_vec(5) ;
  double  beta_r = param_vec(6) ;
  double  removal_n = param_vec(7);
  double  removal_r = param_vec(8);
  double  alpha_export_in = param_vec(9);
  double  p_import = param_vec(10);
  double  death_s = param_vec(11);
  double  death_i = param_vec(12) ;
  double  customer_death_S =  param_vec(13);
  double  customer_death_I = param_vec(14);
  int  total_time = param_vec(15);
  double  tau_import = param_vec(16);
  double tau_insp = param_vec(17);
  double ncom = param_vec(18);
  double ncons = param_vec(19);
  double nnur = param_vec(20);
  double nret = param_vec(21);
  int seeding = param_vec(22);
  
  
  
  // end of inputs
  
  double Vinitial = 0; 
  double ncol_A = A_matrix.n_cols ;
  
  
//  Rcpp::List test_list(11);
  
  
  arma::cube SI_array(total_time+1, 2, 7);
  
  
  
  // int com_pos = A_matrix.n_cols - 2;
  // int cons_pos = com_pos + 1;
  
  arma::vec N_com_pos = arma::linspace<arma::vec>( (1-1) , (ncom-1) );
  arma::vec N_cons_pos = arma::linspace<arma::vec>( ncom , (ncom+ncons-1) );
  arma::vec N_nur_pos = arma::linspace<arma::vec>( ncom +ncons , (ncom+ncons + nnur -1) );
  arma::vec N_ret_pos = arma::linspace<arma::vec>( ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) );
  arma::vec ret_pos = arma::linspace<arma::vec>( ncom+ncons + nnur + nret,  ncol_A-3 );
  arma::vec Nur_pos = arma::linspace<arma::vec>(0, (ncom+ncons + nnur + nret -1)  );
  arma::vec N_to_R = arma::linspace<arma::vec>(0, ncol_A-3 );  
  
  
  
  //indices.list = list("com.pos" = com.pos, "cons.pos"  =cons.pos,
  //                     "N.com.pos" = N.com.pos, "N.cons.pos" = N.cons.pos, "N.nur.pos" = N.nur.pos,
  //                     "N.ret.pos" = N.ret.pos, "Nur.pos" = Nur.pos, "ret.pos" = ret.pos, "N.to.R" = N.to.R )
  
  
  arma::mat dummy( 1, ncol_A, arma::fill::zeros );  
  
  arma::mat dummy_alpha_in = dummy;
  
  dummy_alpha_in.cols(0,(160 -1)) = arma::mat(1, 160 , arma::fill::value(alpha_n_in)) ;// nurseries
  dummy_alpha_in.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(alpha_r_in)) ;//retailers
  
  arma::mat dummy_alpha_out = dummy;
  
  dummy_alpha_out.cols(0,(160 -1)) = arma::mat(1, (160 ) , arma::fill::value(alpha_n_out));//  nurseries
  dummy_alpha_out.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(alpha_r_out)); // retailers
  
  
  arma::mat dummy_p_grown = dummy;
  dummy_p_grown.cols(0,(160 -1)) = arma::mat(1, (160) , arma::fill::value(p_grown)); // nurseries
  dummy_p_grown.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::zeros) ;//retailers
  
  
  arma::mat dummy_beta = dummy;
  dummy_beta.cols(0,(160 -1)) = arma::mat(1, (160) , arma::fill::value(beta_n));
  dummy_beta.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(beta_r)) ;
  
  
  arma::mat dummy_removal = dummy;
  
  dummy_removal.cols(0,(160 -1)) = arma::mat(1, (160) , arma::fill::value(removal_n));
  dummy_removal.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(removal_r)) ;
  
  
  
  
  
  arma::mat N_sizes = N_sizes_function(A_matrix).t();
  
  if(seeding == 1){ Vinitial = Rcpp::RcppArmadillo::sample(N_com_pos, 1, false).eval()(0); };
  if(seeding == 2){Vinitial =  Rcpp::RcppArmadillo::sample(N_cons_pos, 1, false).eval()(0);};
  if(seeding == 3){Vinitial =  Rcpp::RcppArmadillo::sample(N_nur_pos, 1, false).eval()(0);};
  if(seeding == 4){Vinitial =  Rcpp::RcppArmadillo::sample(N_ret_pos, 1, false).eval()(0);};
  if(seeding == 5){Vinitial =  0;};
 
  
  arma::mat S(total_time+1, ncol_A, arma::fill::zeros);
  arma::mat I = S;
  
  
  S.row(0) = N_sizes;
  S(0, ncol_A-2)  = 0;
  S(0, ncol_A-1)  = 0;
  
  I(0, Vinitial) = 1;
  S(0,Vinitial)  = S(0, Vinitial) - I(0, Vinitial);
  
  
  //#initial S
  
  SI_array(0,0,0) = 0 ;
  SI_array(0,0,1) = 0 ;
  SI_array(0,0,2) = sum(S.row(0).cols( 0,ncom -1  )) ;
  SI_array(0,0,3) = sum(S.row(0).cols( ncom , (ncom+ncons-1)  )) ;
  SI_array(0,0,4) = sum(S.row(0).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
  SI_array(0,0,5) = sum(S.row(0).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
  SI_array(0,0,6) = sum(S.row(0).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ;
  
  //#initial I
  //  SIR.node.array[1,2,] <- c((I[1,com.pos]), (I[1,cons.pos]), sum(I[1,N.com.pos]), sum(I[1,N.cons.pos]), sum(I[1,N.nur.pos]), sum(I[1,N.ret.pos]), sum(I[1,ret.pos]))
  
  
  SI_array(0,1,0) = 0 ;
  SI_array(0,1,1) = 0 ;
  SI_array(0,1,2) = sum(I.row(0).cols( 0,ncom -1  )) ;
  SI_array(0,1,3) = sum(I.row(0).cols( ncom , (ncom+ncons-1)  )) ;
  SI_array(0,1,4) = sum(I.row(0).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
  SI_array(0,1,5) = sum(I.row(0).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
  SI_array(0,1,6) = 0 ;
  
  
  
  //      a can be calculated outside the time step
  //a <- colSums(A.matrix[,N.to.R]) - colSums(  t(A.matrix[N.to.R,]) )
  
  arma::mat  a_1(1, ncol_A-2, arma::fill::zeros);
  arma::mat  a_2(1, ncol_A-2, arma::fill::zeros);
  
  
  a_1 = Arma_sp_colsums(A_matrix.cols(0,ncol_A-3)); // These are [N_to_R, 1] matrices
  //a_2= Arma_sp_rowsums(A_matrix.rows(0,A_matrix.n_cols-3)) ;
  a_2= Arma_sp_colsums(   arma::trans(A_matrix.rows(0,ncol_A-3))  ) ;
  arma::mat a = a_1 - a_2;
  
  a = arma::trans(a) ;
  
  
  // initialise every new object I need outside the for loop
  
  
  arma::mat I_over_N(1, ncol_A);
  arma::mat F_I_K(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik1(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik2(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik3(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik4(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik41(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik42(ncol_A-2  , ncol_A, arma::fill::zeros );
  
  
  arma::mat insp_removal(1, ncol_A, arma::fill::zeros);
  
  arma::mat b_1(1, ncol_A - 2);
  arma::mat b_2(1, ncol_A - 2);
  arma::mat b_3(ncol_A - 2, ncol_A);
  arma::mat b_4(ncol_A - 2, ncol_A);
  arma::mat b_5(ncol_A - 2, ncol_A);
  arma::mat b(1, ncol_A - 2);
  
  arma::sp_mat c(1, ncol_A - 2 );
  arma::sp_mat c_1(1, ncol_A - 2 );
  arma::sp_mat c_2(1, ncol_A - 2 );
  arma::sp_mat c_3(1, ncol_A - 2 );
  
  arma::sp_mat G_vector(1,  ncol_A - 2) ;
  arma::sp_mat imp_vector(1,  ncol_A - 2) ;
  arma::sp_mat export_vector(1,  ncol_A - 2) ;
  
  arma::mat customer_bought(  ncol_A - 2, 2 ) ;
  
  arma::mat I_1 = arma::ones( 1, ncol_A );
  arma::mat I_2 = arma::ones( 1, ncol_A - 2 );
  
  arma::mat s_1 = arma::mat(ncol_A-2, (ncol_A) );
  arma::mat s_2 = arma::mat(ncol_A, (ncol_A-2) );
  arma::mat s_3 = arma::mat(ncol_A, (ncol_A-2) );
  arma::mat s_4 = arma::mat(ncol_A, (ncol_A-2) );
  arma::mat s_5 = arma::mat(ncol_A, (ncol_A-2) );
  arma::mat s_6 = arma::mat(ncol_A, (ncol_A-2) );
  
  
  // arma::mat dummy_mat_1(ncol_A-2, ncol_A, arma::fill::ones);
  //  arma::mat dummy_mat_2(ncol_A, ncol_A-2, arma::fill::ones);
  
  
  int q1 = 0 ; 
  
 for(int t = 0; t < (total_time ); ++t){
//       int t = 0;
    
    I_over_N = I.row(t)/N_sizes;
    
    
    
    //fik1 =  arma::repmat( (arma::ones( 1, ncol_A ) - dummy_alpha_in)  , (ncol_A-2),   1);
    
    fik1.each_row() = (I_1 - dummy_alpha_in);
    
    
    
    
    
    //fik2 =  arma::repmat( arma::trans( (I_2 - dummy_alpha_out.cols(0,ncol_A-3)) % I_over_N.cols(0,(ncol_A-3)) ), 1  , ncol_A) ;
    
    fik2.each_col() = arma::trans( (I_2 - dummy_alpha_out.cols(0,ncol_A-3)) % I_over_N.cols(0,(ncol_A-3)) )  ;
    
    //fik3 =  arma::repmat(arma::trans(I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,(ncol_A-3))), 1  , ncol_A);
    
    fik3.each_col() = arma::trans(I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,(ncol_A-3)))  ;
    
    
    //  fik4 =   arma::ones(ncol_A-2,ncol_A) - (arma::repmat(dummy_alpha_in,(ncol_A-2),1) %arma::repmat(arma::trans(I_over_N.cols(0,(ncol_A-3))%( I_2 - dummy_alpha_out.cols(0,(ncol_A-3)) ) /( I_2 - 
    //    dummy_alpha_out.cols(0,(ncol_A-3))%I_over_N.cols(0,(ncol_A-3)) )), 1, ncol_A)) ; 
    
    fik41.each_row() = dummy_alpha_in;
    
    fik42.each_col() = arma::trans(I_over_N.cols(0,(ncol_A-3))%( I_2 - dummy_alpha_out.cols(0,(ncol_A-3)) ) /( I_2 - 
      dummy_alpha_out.cols(0,(ncol_A-3))%I_over_N.cols(0,(ncol_A-3)) )) ;     
    
    fik4 = arma::ones(ncol_A-2,ncol_A) - fik41 % fik42 ; 
    
    
    
    // F_I_K needs to be a [N_to_R, A_cols] dimension
    // F_I_K = fik1*fik2/(fik3*(fik4) )
    
    
    F_I_K = (fik1 % fik2 )/(fik3 % fik4);
    
    
 //   test_list[0] = F_I_K  ;   
    
    
    // scheduled inspections every tau_inspection time-steps  
    insp_removal = arma::mat( 1, ncol_A, arma::fill::zeros);
    
    
    
    if( (mod(t,tau_insp) == 0 ) && t > 0 ){ insp_removal = dummy_removal ; }; 
    
    
    
    
    b_1 = S.row(t).cols(0,ncol_A - 3)*death_s;
    
    b_2 = (I_2*death_i + insp_removal.cols(0, ncol_A - 3) )% I.row(t).cols(0, ncol_A - 3) ; 
    
    
    //b_3 = arma::repmat( (dummy_alpha_in/ (I_1 - dummy_alpha_in) ), (ncol_A - 2), 1 )  ;
    
    b_3.each_row() = (dummy_alpha_in/ (I_1 - dummy_alpha_in) );
    
    
    
    //   b_4 =  arma::repmat(dummy_alpha_in, (ncol_A-2), 1);
    
    b_4 = fik41 ;
    
    
    //b_5 = arma::repmat( arma::trans( I_over_N.cols(0,ncol_A-3) % ( I_2 - dummy_alpha_out.cols(0,ncol_A-3))/
    //  (I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3)%( I_2*2 - dummy_alpha_out.cols(0,ncol_A-3))) ), 1 ,ncol_A) ;
    
    
    b_5.each_col() = arma::trans( I_over_N.cols(0,ncol_A-3) % ( I_2 - dummy_alpha_out.cols(0,ncol_A-3))/
      (I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3)%( I_2*2 - dummy_alpha_out.cols(0,ncol_A-3))) )   ;
    
    
    // b = b_1 + b_2 + arma::trans(Arma_sp_rowsums( (F_I_K % b_3 + b_4 % b_5) % (A_matrix.rows(0,ncol_A-3)) )) ;
    
    b = b_1 + b_2 + arma::trans(Arma_sp_colsums(    arma::trans((F_I_K % b_3 + b_4 % b_5) % (A_matrix.rows(0,ncol_A-3))) )) ;
    
    
    
 //   test_list[1] = b ;
    
    
    
    c_1 =  (I_2 - dummy_alpha_out.cols(0,ncol_A - 3)) % I_over_N.cols(0, ncol_A - 3) * alpha_export_in ;
    
    c_2 =  I_2/ (I_2 - I_over_N.cols(0, ncol_A - 3) %( dummy_alpha_out.cols(0,ncol_A - 3)*alpha_export_in - dummy_alpha_out.cols(0,ncol_A - 3) - I_2*alpha_export_in) ) ;
    
    
    c_3 =  I_2/( I_2 -   dummy_alpha_out.cols(0,ncol_A - 3) % I_over_N.cols(0, ncol_A - 3) % ( I_2*2 - dummy_alpha_out.cols(0,ncol_A - 3)    )    ) ;
    
    
    c = I_2 + c_1 %(c_2 + c_3)    ;
    
 //   test_list[2] = c ;
    
    
    G_vector = arma::sp_mat(1,  ncol_A - 2) ;
    imp_vector = G_vector;
    export_vector = G_vector ;
    
    
    
    
    G_vector =  clamp((b - a), 0, 1000000000);
    
//    test_list[3] = G_vector ;
    //   q1 = int(Rcpp::RcppArmadillo::sample(arma::find(G_vector), 1, false).eval()(0)) ;
    
    q1 = 0;
    
    
    if(p_import > 0 && mod(t,tau_import) == 0 && t > 1 ){imp_vector.row(0).col(q1) = arma::ones(1,1);} ;
    
    export_vector = clamp((a-b)/c, 0, 1000000000);
    
 //   test_list[4] = export_vector;
    
    
    // For commercial & consumers
    
    // customer_bought = arma::trans(arma::repmat( ( (I_2 - dummy_alpha_out.cols(0,ncol_A -3))%I_over_N.cols(0,ncol_A -3)/(I_2 - dummy_alpha_out.cols(0,ncol_A -3)%I_over_N.cols(0,ncol_A -3)) ), 2, 1  ) ) ;  
    
    customer_bought.each_col() = arma::trans( (I_2 - dummy_alpha_out.cols(0,ncol_A -3))%I_over_N.cols(0,ncol_A -3)/(I_2 - dummy_alpha_out.cols(0,ncol_A -3)%I_over_N.cols(0,ncol_A -3)) );
    
    //customer_bought = arma::trans(customer_bought);
    
    
    S.row(t+1).cols(ncol_A-2,ncol_A-1) = (1 - customer_death_S)*S.row(t).cols(ncol_A-2,ncol_A-1)  +
      
      arma::trans(Arma_sp_colsums( A_matrix.rows(0,ncol_A-3).cols(ncol_A-2,ncol_A-1) %( arma::ones(ncol_A-2,2)   - customer_bought))) ; 
    
    
    I.row(t+1).cols(ncol_A-2,ncol_A-1) = (1 - customer_death_I)*I.row(t).cols(ncol_A-2,ncol_A-1)  +
      
      arma::trans(Arma_sp_colsums( A_matrix.rows(0,ncol_A-3).cols(ncol_A-2,ncol_A-1) % customer_bought )) ;
    
    
    
    
    // create matrices for S(t+1) eqn:
    
    
    // arma::repmat(I_over_N, ncol_A-2, 1 )
    
    s_1.each_row() = I_over_N  ;  
    
    //  arma::repmat( (I_2 - dummy_alpha_in.cols(0,ncol_A - 3)  ), ncol_A, 1)
    
    s_2.each_row() = (I_2 - dummy_alpha_in.cols(0,ncol_A - 3)  ) ; 
    
    //    arma::repmat(  (arma::trans(I_1) -   arma::trans(dummy_alpha_out)  ), 1, ncol_A-2 )
    
    
    s_3.each_col() = (arma::trans(I_1) -   arma::trans(dummy_alpha_out)  ) ;
    
    
    // arma::repmat(  (arma::trans(I_1) -   arma::trans(dummy_alpha_out%I_over_N)  ), 1, ncol_A-2 )
    
    
    s_4.each_col() = (arma::trans(I_1) -   arma::trans(dummy_alpha_out%I_over_N)  ) ;
    
    
    // arma::repmat( dummy_alpha_in.cols(0,ncol_A -3), ncol_A,1) 
    
    
    s_5.each_row() = dummy_alpha_in.cols(0,ncol_A -3)  ;
    
    
    // arma::repmat(arma::trans((  I_over_N % ( I_1 - dummy_alpha_out )/( I_1 - dummy_alpha_out%I_over_N  ) )), 1,ncol_A-2 )
    
    
    s_6.each_col() = arma::trans((  I_over_N % ( I_1 - dummy_alpha_out )/( I_1 - dummy_alpha_out%I_over_N  ) )) ;
    
    
    // for nurseries and retailers
    
    S.row(t+1).cols(0, ncol_A-3 ) = 
      
      
      (1 - death_s)*S.row(t).cols(0, ncol_A-3 ) +   
      // total susceptible bought                        
      //  matrix(I.over.N, nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE )
      arma::trans( Arma_sp_colsums(   (arma::ones(ncol_A, ncol_A-2) - arma::trans(s_1 )%
      
      
      //(1 - matrix(( alpha.vector.in[N.to.R]), nrow = ncol.A, ncol = max(N.to.R), byrow = TRUE ))*
      s_2 %
      
      
      // (1 - matrix(alpha.vector.out, nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE))/
      s_3/(
        
        //(1 - matrix(alpha.vector.out*I.over.N,  nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE ))*
        s_4%
        
        
        
        
        // (1 -  matrix( alpha.vector.in[N.to.R], nrow = ncol.A, ncol = max(N.to.R), byrow = TRUE)*
        ( arma::ones(ncol_A, ncol_A-2) -  s_5 %   
        
        
        //matrix((I.over.N *(1 - alpha.vector.out)/(1 - alpha.vector.out*I.over.N)), nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE) ) ) % 
        
        s_6     ) ) ) %
        
        
        
        A_matrix.cols(0, ncol_A - 3)     ) ) - 
        
        
        // total susceptible sold
        
        
        //arma::trans(Arma_sp_rowsums(  (arma::ones(ncol_A-2,ncol_A) - F_I_K)%A_matrix.rows(0,ncol_A-3) )) +
        
        arma::trans(Arma_sp_colsums( arma::trans(  (arma::ones(ncol_A-2,ncol_A) - F_I_K)%A_matrix.rows(0,ncol_A-3) ) ))  + 
        
        //growth term (Proportion grown term collapses in this iteration)
        G_vector.cols(0, ncol_A - 3) - 
        //importing disease vector
        imp_vector.cols(0, ncol_A - 3) - 
        
        // susceptible plants exported
        
        // (1- I.over.N[N.to.R]*  ((1 - alpha.export.in)*(1 - alpha.vector.out[N.to.R])/   ((1 - alpha.vector.out[N.to.R]* (I.over.N[N.to.R]))*(1 - (alpha.export.in*I.over.N[N.to.R]*
        // (1 - alpha.vector.out[N.to.R]))/(1 -  alpha.vector.out[N.to.R]*I.over.N[N.to.R]))  )   )    )
        
        
        
        (I_2 - I_over_N.cols(0,ncol_A-3) %( (1 - alpha_export_in ) *( I_2 - dummy_alpha_out.cols(0,ncol_A-3)  )/
          ( ( I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3)  )%( ( I_2 -
            (alpha_export_in*I_over_N.cols(0,ncol_A-3)%(I_2 - dummy_alpha_out.cols(0,ncol_A-3))/(I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3) )) )   ))
        )  
        )%export_vector.cols(0,ncol_A-3) -
          
          
          
          // disease spread
          dummy_beta.cols(0, ncol_A-3)%S.row(t).cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3) ; 
          
    
    
    //to not allow negatives
    
    S.row(t+1) = max(S.row(t+1), arma::zeros(1,ncol_A)) ; 
    
    // to not allow more Susceptibles than N.size in nurseries & retailers 
    S.row(t+1).cols(0,ncol_A-3) = min( S.row(t+1).cols(0,ncol_A-3), N_sizes.cols(0,ncol_A-3)) ;
    
    
    I.row(t+1).cols(0,ncol_A-3) = N_sizes.cols(0,ncol_A-3) - S.row(t+1).cols(0,ncol_A-3); 
    
    
    I.row(t+1) = max(I.row(t+1), arma::zeros(1,ncol_A)) ;  
    
    
    
    
    //#initial S
    
    SI_array(t+1,0,0) = sum(S.row(t+1).col(ncol_A-2)) ;
    SI_array(t+1,0,1) = sum(S.row(t+1).col(ncol_A-1)) ;
    SI_array(t+1,0,2) = sum(S.row(t+1).cols( 0,ncom -1  )) ;
    SI_array(t+1,0,3) = sum(S.row(t+1).cols( ncom , (ncom+ncons-1)  )) ;
    SI_array(t+1,0,4) = sum(S.row(t+1).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
    SI_array(t+1,0,5) = sum(S.row(t+1).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
    SI_array(t+1,0,6) = sum(S.row(t+1).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ;
    
    //#initial I
    //  SIR.node.array[1,2,] <- c((I[1,com.pos]), (I[1,cons.pos]), sum(I[1,N.com.pos]), sum(I[1,N.cons.pos]), sum(I[1,N.nur.pos]), sum(I[1,N.ret.pos]), sum(I[1,ret.pos]))
    
    
    SI_array(t+1,1,0) = sum(I.row(t+1).col(ncol_A-2)) ;
    SI_array(t+1,1,1) = sum(I.row(t+1).col(ncol_A-1)) ;
    SI_array(t+1,1,2) = sum(I.row(t+1).cols( 0,ncom -1  )) ;
    SI_array(t+1,1,3) = sum(I.row(t+1).cols( ncom , (ncom+ncons-1)  )) ;
    SI_array(t+1,1,4) = sum(I.row(t+1).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
    SI_array(t+1,1,5) = sum(I.row(t+1).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
    SI_array(t+1,1,6) = sum(I.row(t+1).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ; 
    
    
    
  }
  
  return  SI_array;
 
  
}
*/
// updated version


// [[Rcpp::export]]
arma::cube Virus_SI_Sim_Fun(
    
    arma::sp_mat A_matrix,
    arma::vec param_vec){
  
  
  // will be inputs later, but for testing...
  
  double  alpha_n_in  = param_vec(0);
  double  alpha_n_out  = param_vec(1);
  double  alpha_r_in = param_vec(2);
  double  alpha_r_out = param_vec(3);
  double  p_grown = param_vec(4);
  double  beta_n = param_vec(5) ;
  double  beta_r = param_vec(6) ;
  double  removal_n = param_vec(7);
  double  removal_r = param_vec(8);
  double  alpha_export_in = param_vec(9);
  double  p_import = param_vec(10);
  double  death_s = param_vec(11);
  double  death_i = param_vec(12) ;
  double  customer_death_S =  param_vec(13);
  double  customer_death_I = param_vec(14);
  int  total_time = param_vec(15);
  double  tau_import = param_vec(16);
  double tau_insp = param_vec(17);
  double ncom = param_vec(18);
  double ncons = param_vec(19);
  double nnur = param_vec(20);
  double nret = param_vec(21);
  int seeding = param_vec(22);
  int rem_start = param_vec(23);
  
  // end of inputs
  
  double Vinitial = 0; 
  double ncol_A = A_matrix.n_cols ;
  
  
//  Rcpp::List test_list(11);
  
  arma::cube SI_array(total_time+1, 2, 7);
  
    // int com_pos = A_matrix.n_cols - 2;
  // int cons_pos = com_pos + 1;
  
  arma::vec N_com_pos = arma::linspace<arma::vec>( (1-1) , (ncom-1) );
  arma::vec N_cons_pos = arma::linspace<arma::vec>( ncom , (ncom+ncons-1) );
  arma::vec N_nur_pos = arma::linspace<arma::vec>( ncom +ncons , (ncom+ncons + nnur -1) );
  arma::vec N_ret_pos = arma::linspace<arma::vec>( ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) );
  arma::vec ret_pos = arma::linspace<arma::vec>( ncom+ncons + nnur + nret,  ncol_A-3 );
  arma::vec Nur_pos = arma::linspace<arma::vec>(0, (ncom+ncons + nnur + nret -1)  );
  arma::vec N_to_R = arma::linspace<arma::vec>(0, ncol_A-3 );  
  
  
  
  //indices.list = list("com.pos" = com.pos, "cons.pos"  =cons.pos,
  //                     "N.com.pos" = N.com.pos, "N.cons.pos" = N.cons.pos, "N.nur.pos" = N.nur.pos,
  //                     "N.ret.pos" = N.ret.pos, "Nur.pos" = Nur.pos, "ret.pos" = ret.pos, "N.to.R" = N.to.R )
  
  
  arma::mat dummy( 1, ncol_A, arma::fill::zeros );  
  
  arma::mat dummy_alpha_in = dummy;
  
  dummy_alpha_in.cols(0,(160 -1)) = arma::mat(1, 160 , arma::fill::value(alpha_n_in)) ;// nurseries
  dummy_alpha_in.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(alpha_r_in)) ;//retailers
  
  arma::mat dummy_alpha_out = dummy;
  
  dummy_alpha_out.cols(0,(160 -1)) = arma::mat(1, (160 ) , arma::fill::value(alpha_n_out));//  nurseries
  dummy_alpha_out.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(alpha_r_out)); // retailers
  
  
 // arma::mat dummy_p_grown = dummy;
//  dummy_p_grown.cols(0,(160 -1)) = arma::mat(1, (160) , arma::fill::value(p_grown)); // nurseries
//  dummy_p_grown.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::zeros) ;//retailers
  
  
  arma::mat dummy_beta = dummy;
  dummy_beta.cols(0,(160 -1)) = arma::mat(1, (160) , arma::fill::value(beta_n));
  dummy_beta.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(beta_r)) ;
  
  
  arma::mat dummy_removal = dummy;
  
  dummy_removal.cols(0,(160 -1)) = arma::mat(1, (160) , arma::fill::value(removal_n));
  dummy_removal.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(removal_r)) ;
  
  
  
  
  
  arma::mat N_sizes = N_sizes_function(A_matrix).t();
  
  if(seeding == 1){ Vinitial = Rcpp::RcppArmadillo::sample(N_com_pos, 1, false).eval()(0); };
  if(seeding == 2){Vinitial =  Rcpp::RcppArmadillo::sample(N_cons_pos, 1, false).eval()(0);};
  if(seeding == 3){Vinitial =  Rcpp::RcppArmadillo::sample(N_nur_pos, 1, false).eval()(0);};
  if(seeding == 4){Vinitial =  Rcpp::RcppArmadillo::sample(N_ret_pos, 1, false).eval()(0);};
  if(seeding == 5){Vinitial =  0;};
  
  
  arma::mat S(total_time+1, ncol_A, arma::fill::zeros);
  arma::mat I = S;
  
  
  S.row(0) = N_sizes;
  S(0, ncol_A-2)  = 0;
  S(0, ncol_A-1)  = 0;
  
  I(0, Vinitial) = 1;
  S(0,Vinitial)  = S(0, Vinitial) - I(0, Vinitial);
  
  
  //#initial S
  
  SI_array(0,0,0) = 0 ;
  SI_array(0,0,1) = 0 ;
  SI_array(0,0,2) = sum(S.row(0).cols( 0,ncom -1  )) ;
  SI_array(0,0,3) = sum(S.row(0).cols( ncom , (ncom+ncons-1)  )) ;
  SI_array(0,0,4) = sum(S.row(0).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
  SI_array(0,0,5) = sum(S.row(0).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
  SI_array(0,0,6) = sum(S.row(0).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ;
  
  //#initial I
  //  SIR.node.array[1,2,] <- c((I[1,com.pos]), (I[1,cons.pos]), sum(I[1,N.com.pos]), sum(I[1,N.cons.pos]), sum(I[1,N.nur.pos]), sum(I[1,N.ret.pos]), sum(I[1,ret.pos]))
  
  
  SI_array(0,1,0) = 0 ;
  SI_array(0,1,1) = 0 ;
  SI_array(0,1,2) = sum(I.row(0).cols( 0,ncom -1  )) ;
  SI_array(0,1,3) = sum(I.row(0).cols( ncom , (ncom+ncons-1)  )) ;
  SI_array(0,1,4) = sum(I.row(0).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
  SI_array(0,1,5) = sum(I.row(0).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
  SI_array(0,1,6) = 0 ;
  
  
  
  //      a can be calculated outside the time step
  //a <- colSums(A.matrix[,N.to.R]) - colSums(  t(A.matrix[N.to.R,]) )
  
  arma::mat  a_1(1, ncol_A-2, arma::fill::zeros);
  arma::mat  a_2(1, ncol_A-2, arma::fill::zeros);
  
  
  a_1 = Arma_sp_colsums(A_matrix.cols(0,ncol_A-3)); // These are [N_to_R, 1] matrices
  //a_2= Arma_sp_rowsums(A_matrix.rows(0,A_matrix.n_cols-3)) ;
  a_2= Arma_sp_colsums(   arma::trans(A_matrix.rows(0,ncol_A-3))  ) ;
  arma::mat a = a_1 - a_2;
  
  a = arma::trans(a) ;
  
  
  // initialise every new object I need outside the for loop
  
  
  arma::mat I_over_N(1, ncol_A);
  arma::mat F_I_K(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik1(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik2(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik3(ncol_A-2  , ncol_A, arma::fill::zeros );
 // arma::mat fik4(ncol_A-2  , ncol_A, arma::fill::zeros );
  arma::mat fik41(ncol_A-2  , ncol_A, arma::fill::zeros );
//  arma::mat fik42(ncol_A-2  , ncol_A, arma::fill::zeros );
  
  
  arma::mat insp_removal(1, ncol_A, arma::fill::zeros);
  
  arma::mat b_1(1, ncol_A - 2);
  arma::mat b_2(1, ncol_A - 2);
  arma::mat b_3(ncol_A - 2, ncol_A);
//  arma::mat b_4(ncol_A - 2, ncol_A);
  arma::mat b_5(ncol_A - 2, ncol_A);
  arma::mat b(1, ncol_A - 2);
  
  arma::sp_mat c(1, ncol_A - 2 );
  arma::sp_mat c_1(1, ncol_A - 2 );
  arma::sp_mat c_2(1, ncol_A - 2 );
 // arma::sp_mat c_3(1, ncol_A - 2 );
  
  arma::sp_mat G_vector(1,  ncol_A - 2) ;
  arma::sp_mat imp_vector(1,  ncol_A - 2) ;
  arma::sp_mat export_vector(1,  ncol_A - 2) ;
  
  arma::mat customer_bought(  ncol_A - 2, 2 ) ;
  
  arma::mat I_1 = arma::ones( 1, ncol_A );
  arma::mat I_2 = arma::ones( 1, ncol_A - 2 );
  
  arma::mat s_1 = arma::mat(ncol_A-2, (ncol_A) );
  arma::mat s_2 = arma::mat(ncol_A, (ncol_A-2) );
  arma::mat s_3 = arma::mat(ncol_A, (ncol_A-2) );
  arma::mat s_4 = arma::mat(ncol_A, (ncol_A-2) );
  arma::mat s_5 = arma::mat(ncol_A, (ncol_A-2) );
  arma::mat s_6 = arma::mat(ncol_A, (ncol_A-2) );
  
  
  // arma::mat dummy_mat_1(ncol_A-2, ncol_A, arma::fill::ones);
  //  arma::mat dummy_mat_2(ncol_A, ncol_A-2, arma::fill::ones);
  
  
  int q1 = 0 ; 
  
  s_2.each_row() = (I_2 - dummy_alpha_in.cols(0,ncol_A - 3)  ) ; 
  s_3.each_col() = (arma::trans(I_1 - dummy_alpha_out)  ) ;
  s_5.each_row() = dummy_alpha_in.cols(0,ncol_A -3)  ;
   fik1.each_row() = (I_1 - dummy_alpha_in);
   fik41.each_row() = dummy_alpha_in;
   b_3.each_row() = (dummy_alpha_in/ (I_1 - dummy_alpha_in) );
  
   for(int t = 0; t < (total_time ); ++t){
//  int t = 0;
  
  I_over_N = I.row(t)/N_sizes;
  
  
  
  //fik1 =  arma::repmat( (arma::ones( 1, ncol_A ) - dummy_alpha_in)  , (ncol_A-2),   1);
  
 
  //fik2 =  arma::repmat( arma::trans( (I_2 - dummy_alpha_out.cols(0,ncol_A-3)) % I_over_N.cols(0,(ncol_A-3)) ), 1  , ncol_A) ;
  
  fik2.each_col() = arma::trans( (I_2 - dummy_alpha_out.cols(0,ncol_A-3)) % I.row(t).cols(0,(ncol_A-3)) )  ;
  
  //fik3 =  arma::repmat(arma::trans(I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,(ncol_A-3))), 1  , ncol_A);
  c_1 = ( N_sizes.cols(0,(ncol_A-3)) - dummy_alpha_out.cols(0,ncol_A-3)%I.row(t).cols(0,(ncol_A-3)) );
  
  fik3.each_col() = arma::trans(( N_sizes.cols(0,(ncol_A-3)) - dummy_alpha_out.cols(0,ncol_A-3)%I.row(t).cols(0,(ncol_A-3)) ) )  ;
  
  
  //  fik4 =   arma::ones(ncol_A-2,ncol_A) - (arma::repmat(dummy_alpha_in,(ncol_A-2),1) %arma::repmat(arma::trans(I_over_N.cols(0,(ncol_A-3))%( I_2 - dummy_alpha_out.cols(0,(ncol_A-3)) ) /( I_2 - 
  //    dummy_alpha_out.cols(0,(ncol_A-3))%I_over_N.cols(0,(ncol_A-3)) )), 1, ncol_A)) ; 
  
 
  
  
  
  // F_I_K needs to be a [N_to_R, A_cols] dimension
  // F_I_K = fik1*fik2/(fik3*(fik4) )
  
  
//F_I_K = A_ij*( ((1 - a_out)*I*(1 - a_in))/(N - a_out*I - a_in*(1 - a_out)*I))
  
  
  F_I_K = (fik1 % fik2 )/(fik3 - fik2%fik41);
  
  
//  test_list[0] = F_I_K  ;   
  
  
  // scheduled inspections every tau_inspection time-steps  
  insp_removal = arma::mat( 1, ncol_A, arma::fill::zeros);
  
  
  
 // if( (mod(t,tau_insp) == 0 ) && t > 0 ){ insp_removal = dummy_removal ; }; 
  
  
  if( t == rem_start  ){ insp_removal = dummy_removal ;  };
  
  if( (mod( (t - rem_start)  ,tau_insp) == 0 ) && t > 0 ){ insp_removal = dummy_removal ; }; 
  
  
  b_1 = S.row(t).cols(0,ncol_A - 3)*death_s;
  
  b_2 = (I_2*death_i + insp_removal.cols(0, ncol_A - 3) )% I.row(t).cols(0, ncol_A - 3) ; 
  
  
  //b_3 = arma::repmat( (dummy_alpha_in/ (I_1 - dummy_alpha_in) ), (ncol_A - 2), 1 )  ;
  
 
  
  
  
  //   b_4 =  arma::repmat(dummy_alpha_in, (ncol_A-2), 1);
  
//  b_4 = fik41 ;
  
  
  //b_5 = arma::repmat( arma::trans( I_over_N.cols(0,ncol_A-3) % ( I_2 - dummy_alpha_out.cols(0,ncol_A-3))/
  //  (I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3)%( I_2*2 - dummy_alpha_out.cols(0,ncol_A-3))) ), 1 ,ncol_A) ;
  
  
  //b_5.each_col() = arma::trans( I_over_N.cols(0,ncol_A-3) % ( I_2 - dummy_alpha_out.cols(0,ncol_A-3))/
  //  (I_2 - dummy_alpha_out.cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3)%( I_2*2 - dummy_alpha_out.cols(0,ncol_A-3))) )   ;
  
  
  b_5.each_col() = arma::trans(I.row(t).cols(0,ncol_A-3)%dummy_alpha_out.cols(0,ncol_A-3)/c_1);
  
  
  
  // b = b_1 + b_2 + arma::trans(Arma_sp_rowsums( (F_I_K % b_3 + b_4 % b_5) % (A_matrix.rows(0,ncol_A-3)) )) ;
  
//  b = b_1 + b_2 + arma::trans(Arma_sp_colsums(    arma::trans((F_I_K % b_3 + fik41 % b_5) % (A_matrix.rows(0,ncol_A-3))) )) ;
  
  
  b = b_1 + b_2 + arma::trans(Arma_sp_colsums( arma::trans(  (F_I_K % b_3 + (arma::ones(ncol_A-2,ncol_A) + F_I_K % b_3)%b_5   ) % A_matrix.rows(0,ncol_A-3) ) ) );
  
  
//  test_list[1] = b ;
  
  
  
//  c_1 =  (I_2 - dummy_alpha_out.cols(0,ncol_A - 3)) % I_over_N.cols(0, ncol_A - 3) * alpha_export_in ;
  
//  c_2 =  I_2/ (I_2 - I_over_N.cols(0, ncol_A - 3) %( dummy_alpha_out.cols(0,ncol_A - 3)*alpha_export_in - dummy_alpha_out.cols(0,ncol_A - 3) - I_2*alpha_export_in) ) ;
  
  
//  c_3 =  I_2/( I_2 -   dummy_alpha_out.cols(0,ncol_A - 3) % I_over_N.cols(0, ncol_A - 3) % ( I_2*2 - dummy_alpha_out.cols(0,ncol_A - 3)    )    ) ;
  
  
 
  
//  c = I_2 + c_1 %(c_2 + c_3)    ;
  
  //c_1 = ( N_sizes.cols(0,(ncol_A-3)) - dummy_alpha_out.cols(0,ncol_A-3)%I.row(t).cols(0,(ncol_A-3)) );
  
  c_2 = alpha_export_in * I.row(t).cols(0,(ncol_A-3))%(I_2 - dummy_alpha_out.cols(0,ncol_A - 3))/
    (c_1 - alpha_export_in * I.row(t).cols(0,(ncol_A-3))%(I_2 - dummy_alpha_out.cols(0,ncol_A - 3)) ) ;
  
  
  c = I_2 + ( dummy_alpha_out.cols(0,ncol_A-3)%I.row(t).cols(0,(ncol_A-3))/c_1 ) %( I_2 + c_2 ) +  c_2 ;
  
//  test_list[2] = c ;
  
  
  G_vector = arma::sp_mat(1,  ncol_A - 2) ;
  imp_vector = G_vector;
  export_vector = G_vector ;
  
  
  
  
  G_vector =  clamp((b - a), 0, 1000000000);
  
//  test_list[3] = G_vector ;
  //   q1 = int(Rcpp::RcppArmadillo::sample(arma::find(G_vector), 1, false).eval()(0)) ;
  
  q1 = 0;
  
  
//  if(p_import > 0 && mod(t,tau_import) == 0 && t > 1 ){imp_vector.row(0).col(q1) = arma::ones(1,1);} ;
  
  export_vector = clamp((a-b)/c, 0, 1000000000);
  
 // test_list[4] = export_vector;
  
  
  // For commercial & consumers
  
  // customer_bought = arma::trans(arma::repmat( ( (I_2 - dummy_alpha_out.cols(0,ncol_A -3))%I_over_N.cols(0,ncol_A -3)/(I_2 - dummy_alpha_out.cols(0,ncol_A -3)%I_over_N.cols(0,ncol_A -3)) ), 2, 1  ) ) ;  
  
  customer_bought.each_col() = arma::trans( (I_2 - dummy_alpha_out.cols(0,ncol_A -3))%I_over_N.cols(0,ncol_A -3)/(I_2 - dummy_alpha_out.cols(0,ncol_A -3)%I_over_N.cols(0,ncol_A -3)) );
  
  //customer_bought = arma::trans(customer_bought);
  
  
  S.row(t+1).cols(ncol_A-2,ncol_A-1) = (1 - customer_death_S)*S.row(t).cols(ncol_A-2,ncol_A-1)  +
    
    arma::trans(Arma_sp_colsums( A_matrix.rows(0,ncol_A-3).cols(ncol_A-2,ncol_A-1) %( arma::ones(ncol_A-2,2)   - customer_bought))) ; 
  
  
  I.row(t+1).cols(ncol_A-2,ncol_A-1) = (1 - customer_death_I)*I.row(t).cols(ncol_A-2,ncol_A-1)  +
    
    arma::trans(Arma_sp_colsums( A_matrix.rows(0,ncol_A-3).cols(ncol_A-2,ncol_A-1) % customer_bought )) ;
  
  
  
  
  // create matrices for S(t+1) eqn:
  
  
  // arma::repmat(I_over_N, ncol_A-2, 1 )
  
  s_1.each_row() = I_over_N  ;  
  
  //  arma::repmat( (I_2 - dummy_alpha_in.cols(0,ncol_A - 3)  ), ncol_A, 1)
  

  //    arma::repmat(  (arma::trans(I_1) -   arma::trans(dummy_alpha_out)  ), 1, ncol_A-2 )
 
  
 
  
  
  // arma::repmat(  (arma::trans(I_1) -   arma::trans(dummy_alpha_out%I_over_N)  ), 1, ncol_A-2 )
  
  
  s_4.each_col() = (arma::trans(I_1 - dummy_alpha_out%I_over_N)  ) ;
  
  
  // arma::repmat( dummy_alpha_in.cols(0,ncol_A -3), ncol_A,1) 
  
  
 
  
  
  // arma::repmat(arma::trans((  I_over_N % ( I_1 - dummy_alpha_out )/( I_1 - dummy_alpha_out%I_over_N  ) )), 1,ncol_A-2 )
  
  
  s_6.each_col() = arma::trans((  I_over_N % ( I_1 - dummy_alpha_out )/( I_1 - dummy_alpha_out%I_over_N  ) )) ;
  
  
  // for nurseries and retailers
  
  S.row(t+1).cols(0, ncol_A-3 ) = 
    
    
    (1 - death_s)*S.row(t).cols(0, ncol_A-3 ) +   
    // total susceptible bought                        
    //  matrix(I.over.N, nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE )
    arma::trans( Arma_sp_colsums(   (arma::ones(ncol_A, ncol_A-2) - arma::trans(s_1 )%
    
    
    //(1 - matrix(( alpha.vector.in[N.to.R]), nrow = ncol.A, ncol = max(N.to.R), byrow = TRUE ))*
    s_2 %
    
    
    // (1 - matrix(alpha.vector.out, nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE))/
    s_3/(
      
      //(1 - matrix(alpha.vector.out*I.over.N,  nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE ))*
      s_4%
      
      
      
      
      // (1 -  matrix( alpha.vector.in[N.to.R], nrow = ncol.A, ncol = max(N.to.R), byrow = TRUE)*
      ( arma::ones(ncol_A, ncol_A-2) -  s_5 %   
      
      
      //matrix((I.over.N *(1 - alpha.vector.out)/(1 - alpha.vector.out*I.over.N)), nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE) ) ) % 
      
      s_6     ) ) ) %
      
      
      
      A_matrix.cols(0, ncol_A - 3)     ) ) - 
      
      
      // total susceptible sold
      
      
      //arma::trans(Arma_sp_rowsums(  (arma::ones(ncol_A-2,ncol_A) - F_I_K)%A_matrix.rows(0,ncol_A-3) )) +
      
      arma::trans(Arma_sp_colsums( arma::trans(  (arma::ones(ncol_A-2,ncol_A) - F_I_K)%A_matrix.rows(0,ncol_A-3) ) ))  + 
      
      //growth term (Proportion grown term collapses in this iteration)
      G_vector.cols(0, ncol_A - 3) - 
      //importing disease vector
      imp_vector.cols(0, ncol_A - 3) - 
      
      // susceptible plants exported
      
      // (1- I.over.N[N.to.R]*  ((1 - alpha.export.in)*(1 - alpha.vector.out[N.to.R])/   ((1 - alpha.vector.out[N.to.R]* (I.over.N[N.to.R]))*(1 - (alpha.export.in*I.over.N[N.to.R]*
      // (1 - alpha.vector.out[N.to.R]))/(1 -  alpha.vector.out[N.to.R]*I.over.N[N.to.R]))  )   )    )
      
      
      
      (I_2 -  (1 -alpha_export_in) * I.row(t).cols(0,(ncol_A-3))%(I_2 - dummy_alpha_out.cols(0,ncol_A - 3))/
        (c_1 - alpha_export_in * I.row(t).cols(0,(ncol_A-3))%(I_2 - dummy_alpha_out.cols(0,ncol_A - 3)) )  
      )%export_vector.cols(0,ncol_A-3) -
        
        
        
        // disease spread
        dummy_beta.cols(0, ncol_A-3)%S.row(t).cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3) ; 
  
  
  
  //to not allow negatives
  
  S.row(t+1) = max(S.row(t+1), arma::zeros(1,ncol_A)) ; 
  
  // to not allow more Susceptibles than N.size in nurseries & retailers 
  S.row(t+1).cols(0,ncol_A-3) = min( S.row(t+1).cols(0,ncol_A-3), N_sizes.cols(0,ncol_A-3)) ;
  
  
  I.row(t+1).cols(0,ncol_A-3) = N_sizes.cols(0,ncol_A-3) - S.row(t+1).cols(0,ncol_A-3); 
  
  
  I.row(t+1) = max(I.row(t+1), arma::zeros(1,ncol_A)) ;  
  
  
  
  
  //#initial S
  
  SI_array(t+1,0,0) = sum(S.row(t+1).col(ncol_A-2)) ;
  SI_array(t+1,0,1) = sum(S.row(t+1).col(ncol_A-1)) ;
  SI_array(t+1,0,2) = sum(S.row(t+1).cols( 0,ncom -1  )) ;
  SI_array(t+1,0,3) = sum(S.row(t+1).cols( ncom , (ncom+ncons-1)  )) ;
  SI_array(t+1,0,4) = sum(S.row(t+1).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
  SI_array(t+1,0,5) = sum(S.row(t+1).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
  SI_array(t+1,0,6) = sum(S.row(t+1).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ;
  
  //#initial I
  //  SIR.node.array[1,2,] <- c((I[1,com.pos]), (I[1,cons.pos]), sum(I[1,N.com.pos]), sum(I[1,N.cons.pos]), sum(I[1,N.nur.pos]), sum(I[1,N.ret.pos]), sum(I[1,ret.pos]))
  
  
  SI_array(t+1,1,0) = sum(I.row(t+1).col(ncol_A-2)) ;
  SI_array(t+1,1,1) = sum(I.row(t+1).col(ncol_A-1)) ;
  SI_array(t+1,1,2) = sum(I.row(t+1).cols( 0,ncom -1  )) ;
  SI_array(t+1,1,3) = sum(I.row(t+1).cols( ncom , (ncom+ncons-1)  )) ;
  SI_array(t+1,1,4) = sum(I.row(t+1).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
  SI_array(t+1,1,5) = sum(I.row(t+1).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
  SI_array(t+1,1,6) = sum(I.row(t+1).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ; 
  
  
  
  }
  
  return  SI_array;
  
  
}





// quicker version of disease model with no control measures



// [[Rcpp::export]]
arma::cube Do_Nothing(
    
    arma::sp_mat A_matrix,
    arma::vec param_vec){
  
  
  
  
//  double  p_grown = param_vec(0);
  double  beta_n = param_vec(0) ;
  double  beta_r = param_vec(1) ;
  double  death_s = param_vec(2);
  double  death_i = param_vec(3) ;
  double  customer_death_S =  param_vec(4);
  double  customer_death_I = param_vec(5);
  int  total_time = param_vec(6);
  double ncom = param_vec(7);
  double ncons = param_vec(8);
  double nnur = param_vec(9);
  double nret = param_vec(10);
  int seeding = param_vec(11);
  
  
  
  // end of inputs
  
  double Vinitial = 0; 
  double ncol_A = A_matrix.n_cols ;
  
  
  arma::cube SI_array(total_time+1, 2, 7);
  
  
  
  // int com_pos = A_matrix.n_cols - 2;
  // int cons_pos = com_pos + 1;
  
  arma::vec N_com_pos = arma::linspace<arma::vec>( (1-1) , (ncom-1) );
  arma::vec N_cons_pos = arma::linspace<arma::vec>( ncom , (ncom+ncons-1) );
  arma::vec N_nur_pos = arma::linspace<arma::vec>( ncom +ncons , (ncom+ncons + nnur -1) );
  arma::vec N_ret_pos = arma::linspace<arma::vec>( ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) );
//  arma::vec ret_pos = arma::linspace<arma::vec>( ncom+ncons + nnur + nret,  ncol_A-3 );
//  arma::vec Nur_pos = arma::linspace<arma::vec>(0, (ncom+ncons + nnur + nret -1)  );
//  arma::vec N_to_R = arma::linspace<arma::vec>(0, ncol_A-3 );  
  
  
  
  arma::mat dummy( 1, ncol_A, arma::fill::zeros );  
  
  
  //arma::mat dummy_p_grown = dummy;
  //dummy_p_grown.cols(0,(160 -1)) = arma::mat(1, (160) , arma::fill::value(p_grown)); // nurseries
  //dummy_p_grown.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::zeros) ;//retailers
  
  
  arma::mat dummy_beta = dummy;
  dummy_beta.cols(0,(160 -1)) = arma::mat(1, (160) , arma::fill::value(beta_n));
  dummy_beta.cols(160,  ncol_A-3) = arma::mat(1, (ncol_A-162) , arma::fill::value(beta_r)) ;
  
  
  
  
  arma::mat N_sizes = N_sizes_function(A_matrix).t();
  
  if(seeding == 1){ Vinitial = Rcpp::RcppArmadillo::sample(N_com_pos, 1, false).eval()(0); };
  if(seeding == 2){Vinitial =  Rcpp::RcppArmadillo::sample(N_cons_pos, 1, false).eval()(0);};
  if(seeding == 3){Vinitial =  Rcpp::RcppArmadillo::sample(N_nur_pos, 1, false).eval()(0);};
  if(seeding == 4){Vinitial =  Rcpp::RcppArmadillo::sample(N_ret_pos, 1, false).eval()(0);};
  
  
  
  arma::mat S(2, ncol_A, arma::fill::zeros);
  arma::mat I = S;
  
  
  S.row(0) = N_sizes;
  S(0, ncol_A-2)  = 0;
  S(0, ncol_A-1)  = 0;
  
  I(0, Vinitial) = 1;
  S(0,Vinitial)  = S(0, Vinitial) - I(0, Vinitial);
  
  //#initial S
  
  SI_array(0,0,0) = 0 ;
  SI_array(0,0,1) = 0 ;
  SI_array(0,0,2) = sum(S.row(0).cols( 0,ncom -1  )) ;
  SI_array(0,0,3) = sum(S.row(0).cols( ncom , (ncom+ncons-1)  )) ;
  SI_array(0,0,4) = sum(S.row(0).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
  SI_array(0,0,5) = sum(S.row(0).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
  SI_array(0,0,6) = sum(S.row(0).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ;
  
  //#initial I
  //  SIR.node.array[1,2,] <- c((I[1,com.pos]), (I[1,cons.pos]), sum(I[1,N.com.pos]), sum(I[1,N.cons.pos]), sum(I[1,N.nur.pos]), sum(I[1,N.ret.pos]), sum(I[1,ret.pos]))
  
  
  SI_array(0,1,0) = 0 ;
  SI_array(0,1,1) = 0 ;
  SI_array(0,1,2) = sum(I.row(0).cols( 0,ncom -1  )) ;
  SI_array(0,1,3) = sum(I.row(0).cols( ncom , (ncom+ncons-1)  )) ;
  SI_array(0,1,4) = sum(I.row(0).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
  SI_array(0,1,5) = sum(I.row(0).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
  SI_array(0,1,6) = 0 ;
  
  
  
  //      a can be calculated outside the time step
  //a <- colSums(A.matrix[,N.to.R]) - colSums(  t(A.matrix[N.to.R,]) )
  
  arma::mat  a_1(1, ncol_A-2, arma::fill::zeros);
  arma::mat  a_2(1, ncol_A-2, arma::fill::zeros);
  
  
  a_1 = Arma_sp_colsums(A_matrix.cols(0,ncol_A-3)); // These are [N_to_R, 1] matrices
  //a_2= Arma_sp_rowsums(A_matrix.rows(0,A_matrix.n_cols-3)) ;
  a_2= Arma_sp_colsums(   arma::trans(A_matrix.rows(0,ncol_A-3))  ) ;
  arma::mat a = a_1 - a_2;
  
  a = arma::trans(a) ;
  
  
  // initialise every new object I need outside the for loop
  
  
  arma::mat I_over_N(1, ncol_A);
  arma::mat F_I_K(ncol_A-2  , ncol_A, arma::fill::zeros );
  
  
  arma::mat b_1(1, ncol_A - 2);
  arma::mat b_2(1, ncol_A - 2);
  arma::mat b(1, ncol_A - 2);
  
  arma::sp_mat G_vector(1,  ncol_A - 2) ;
  arma::sp_mat export_vector(1,  ncol_A - 2) ;
  
  arma::mat customer_bought(  ncol_A - 2, 2 ) ;
  
  arma::mat I_1 = arma::ones( 1, ncol_A );
  arma::mat I_2 = arma::ones( 1, ncol_A - 2 );
  
  arma::mat s_1 = arma::mat(ncol_A-2, (ncol_A) );
  
  
  // arma::mat dummy_mat_1(ncol_A-2, ncol_A, arma::fill::ones);
  //  arma::mat dummy_mat_2(ncol_A, ncol_A-2, arma::fill::ones);
  
  
 
  
  for(int t = 0; t < (total_time ); ++t){
    //   int t = 0;
    
    I_over_N = I.row(0)/N_sizes;
    
    F_I_K.each_col() = arma::trans(  I_over_N.cols(0,(ncol_A-3)) )  ;
    
    
    b_1 = S.row(0).cols(0,ncol_A - 3)*death_s;
    
    b_2 = (arma::ones(1,ncol_A -2)*death_i )% I.row(0).cols(0, ncol_A - 3) ; 
    
    
    b = b_1 + b_2 ;
    
    
    
    
    G_vector = arma::sp_mat(1,  ncol_A - 2) ;
    export_vector = G_vector ;
    
    
    
    
    G_vector =  clamp((b - a), 0, 1000000000);
    
    
    
    export_vector = clamp((a-b), 0, 1000000000);
    
    // For commercial & consumers
    
    // customer_bought = arma::trans(arma::repmat( ( (I_2 - dummy_alpha_out.cols(0,ncol_A -3))%I_over_N.cols(0,ncol_A -3)/(I_2 - dummy_alpha_out.cols(0,ncol_A -3)%I_over_N.cols(0,ncol_A -3)) ), 2, 1  ) ) ;  
    
    customer_bought.each_col() = arma::trans( I_over_N.cols(0,ncol_A -3) );
    
    //customer_bought = arma::trans(customer_bought);
    
    
    S.row(1).cols(ncol_A-2,ncol_A-1) = (1 - customer_death_S)*S.row(0).cols(ncol_A-2,ncol_A-1)  +
      
      arma::trans(Arma_sp_colsums( A_matrix.rows(0,ncol_A-3).cols(ncol_A-2,ncol_A-1) %( arma::ones(ncol_A-2,2)   - customer_bought))) ; 
    
    
    I.row(1).cols(ncol_A-2,ncol_A-1) = (1 - customer_death_I)*I.row(0).cols(ncol_A-2,ncol_A-1)  +
      
      arma::trans(Arma_sp_colsums( A_matrix.rows(0,ncol_A-3).cols(ncol_A-2,ncol_A-1) % customer_bought )) ;
    
    
    
    
    // create matrices for S(t+1) eqn:
    
    
    // arma::repmat(I_over_N, ncol_A-2, 1 )
    
    s_1.each_row() = I_over_N  ;  
    
    
    
    // for nurseries and retailers
    
    S.row(1).cols(0, ncol_A-3 ) = 
      
      
      (1 - death_s)*S.row(0).cols(0, ncol_A-3 ) +   
      // total susceptible bought                        
      //  matrix(I.over.N, nrow = ncol.A, ncol = max(N.to.R), byrow = FALSE )
      arma::trans( Arma_sp_colsums(   (arma::ones(ncol_A, ncol_A-2) - arma::trans(s_1 ))%
      
      A_matrix.cols(0, ncol_A - 3)     ) )  - 
      
      
      // total susceptible sold
      
      
      //arma::trans(Arma_sp_rowsums(  (arma::ones(ncol_A-2,ncol_A) - F_I_K)%A_matrix.rows(0,ncol_A-3) )) +
      
      arma::trans(Arma_sp_colsums( arma::trans(  (arma::ones(ncol_A-2,ncol_A) - F_I_K)%A_matrix.rows(0,ncol_A-3) ) )) +
      
      //growth term (Proportion grown term collapses in this iteration)
      G_vector.cols(0, ncol_A - 3) - 
      
      
      // susceptible plants exported
      
      // (1- I.over.N[N.to.R]*  ((1 - alpha.export.in)*(1 - alpha.vector.out[N.to.R])/   ((1 - alpha.vector.out[N.to.R]* (I.over.N[N.to.R]))*(1 - (alpha.export.in*I.over.N[N.to.R]*
      // (1 - alpha.vector.out[N.to.R]))/(1 -  alpha.vector.out[N.to.R]*I.over.N[N.to.R]))  )   )    )
      
      (I_2 - I_over_N.cols(0,ncol_A-3))%export_vector.cols(0,ncol_A-3) -
      
      
      // disease spread
      dummy_beta.cols(0, ncol_A-3)%S.row(0).cols(0,ncol_A-3)%I_over_N.cols(0,ncol_A-3) ;
    
    
    
    //to not allow negatives
    
    S.row(1) = max(S.row(1), arma::zeros(1,ncol_A)) ; 
    
    // to not allow more Susceptibles than N.size in nurseries & retailers 
    S.row(1).cols(0,ncol_A-3) = min( S.row(1).cols(0,ncol_A-3), N_sizes.cols(0,ncol_A-3)) ;
    
    
    I.row(1).cols(0,ncol_A-3) = N_sizes.cols(0,ncol_A-3) - S.row(1).cols(0,ncol_A-3); 
    
    
    I.row(1) = max(I.row(1), arma::zeros(1,ncol_A)) ;  
    
    
    
    
    //#initial S
    
    SI_array(t+1,0,0) = sum(S.row(1).col(ncol_A-2)) ;
    SI_array(t+1,0,1) = sum(S.row(1).col(ncol_A-1)) ;
    SI_array(t+1,0,2) = sum(S.row(1).cols( 0,ncom -1  )) ;
    SI_array(t+1,0,3) = sum(S.row(1).cols( ncom , (ncom+ncons-1)  )) ;
    SI_array(t+1,0,4) = sum(S.row(1).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
    SI_array(t+1,0,5) = sum(S.row(1).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
    SI_array(t+1,0,6) = sum(S.row(1).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ;
    
    //#initial I
    //  SIR.node.array[1,2,] <- c((I[1,com.pos]), (I[1,cons.pos]), sum(I[1,N.com.pos]), sum(I[1,N.cons.pos]), sum(I[1,N.nur.pos]), sum(I[1,N.ret.pos]), sum(I[1,ret.pos]))
    
    
    SI_array(t+1,1,0) = sum(I.row(1).col(ncol_A-2)) ;
    SI_array(t+1,1,1) = sum(I.row(1).col(ncol_A-1)) ;
    SI_array(t+1,1,2) = sum(I.row(1).cols( 0,ncom -1  )) ;
    SI_array(t+1,1,3) = sum(I.row(1).cols( ncom , (ncom+ncons-1)  )) ;
    SI_array(t+1,1,4) = sum(I.row(1).cols(  ncom +ncons , (ncom+ncons + nnur -1)  )) ;
    SI_array(t+1,1,5) = sum(I.row(1).cols(ncom +ncons+nnur , (ncom+ncons + nnur + nret -1) ) ) ;
    SI_array(t+1,1,6) = sum(I.row(1).cols( ncom+ncons + nnur + nret,  ncol_A-3  )) ; 
    
    S.row(0) = S.row(1);
    I.row(0) = I.row(1); 
    
  }
  
  return  SI_array;
  
}




// [[Rcpp::export]]

Rcpp::List  hundred_sims_function(arma::sp_mat A_matrix,
                                  arma::vec param_vec, int no_rep){
  
  
  Rcpp::List sims_list(no_rep) ;
  
  for(int iter = 0; iter < (no_rep ); ++iter){
    
    sims_list[iter] = Virus_SI_Sim_Fun(A_matrix, param_vec);
    
    
  }
  
  
  return(sims_list) ;
}




// [[Rcpp::export]]

Rcpp::List  hundred_networks(Rcpp::List A_matrix_list,
                                arma::vec param_vec, int no_rep, int no_networks){
  
  
  Rcpp::List net_sims_list(no_networks) ;
  
  for(int iter_2 = 0; iter_2 < (no_networks ); ++iter_2){
    
    net_sims_list[iter_2] = hundred_sims_function(A_matrix_list[iter_2], param_vec, no_rep);
    
  }
  
  
  return(net_sims_list) ;
}







// [[Rcpp::export]]

Rcpp::List  DN_hundred_sims(arma::sp_mat A_matrix,
                            arma::vec param_vec, int no_rep){
  
  
  Rcpp::List sims_list(no_rep) ;
  
  for(int iter = 0; iter < (no_rep ); ++iter){
    
    sims_list[iter] = Do_Nothing(A_matrix, param_vec);
    
    
  }
  
  
  return(sims_list) ;
}

// [[Rcpp::export]]

Rcpp::List  DN_hundred_networks(Rcpp::List A_matrix_list,
                            arma::vec param_vec, int no_rep, int no_networks){
  
  
  Rcpp::List net_sims_list(no_networks) ;
  
  for(int iter_2 = 0; iter_2 < (no_networks ); ++iter_2){
    
    net_sims_list[iter_2] = DN_hundred_sims(A_matrix_list[iter_2], param_vec, no_rep);
    
  }
  
  
  return(net_sims_list) ;
}



