# vary beta values


source("R_functions_For_Armadillo_Version.R")
# rounded to 1 s.f for simplicity
#            6month, 1yr ,10yrs, 100yrs

alpha_outs <- seq(0,1,0.1)

node.list <-  list(ncom = 40, ncons = 40, nnur = 40, nret = 40, Ret = 160*10)

oak.distribution.list <- list(out.deg.mean = 380*(160/630), out.deg.dispersal = (160/630)*(380)^2/(114587*(160/630) - 380),
                              commercial.mean = 79*(160/630) , commercial.sd = 297*(160/630),
                              consumer.mean = 185*(160/630), consumer.sd = 822*(160/630),
                              nursery.mean = 1844*(160/630) , nursery.sd = 3567*(160/630),
                              retailer.mean = 3497*(160/630), retailer.sd = 9588*(160/630) )

param_vector <-c(
  0, # alpha_n_in
  0, # alpha_n_out
  0, # alpha_r_in
  0, # alpha_r_out
  0, # p_grown
  2 , # beta_n
  2 , # beta_r
  0, # removal_n
  0, # removal_r
  0, # alpha_export_in
  0, # p_import
  0.7, # death_s
  1 , # death_i
  0, # customer_death_S
  0, # customer_death_I
  36, # total_time
  6, # tau import
  6, # tau insp
  40, # ncom
  40, # ncons
  40, # nnur
  40, # nret
  1 # seeding
)
param_list <- list("node.list" = node.list, "distribution.list" = oak.distribution.list,
                   "param_vec" = param_vector)


A_matrix_list <- list()

for (i in 1:100) {
  
  A_matrix_list[[i]] = netgen.for.SI(param_list$node.list, param_list$distribution.list)
  
}

#a <- getwd()

#Nursery comp 1
#setwd(paste0(a,"/Nursery_comp_1/Vary_Beta"))

#vary betas
for (j in 1:length(alpha_outs)) {
  seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
  param_list$param_vec[2] =  alpha_outs[j]
  param_list$param_vec[4] =  alpha_outs[j]
  
  seeding.results.array =  Parallel_Over_Seedings(A_matrix_list,param_list, 4, 100, 100, seedings = 1:4)
  
  save('seeding.results.array', file = paste0("S1_results_array_alpha_out_",alpha_outs[j],".RData"))
  # rm(seeding.results.array)
  
}



#Nursery comp 2
#setwd(paste0(a,"/Nursery_comp_2/Vary_Beta"))
param_list$node.list = list(ncom = 80, ncons = 20, nnur = 40, nret = 20, Ret = 160*10)

param_list$param_vec[19:22] = c(80, 20,  40, 20)

rm(A_matrix_list)
A_matrix_list <- list()

for (i in 1:100) {
  
  A_matrix_list[[i]] = netgen.for.SI(param_list$node.list, param_list$distribution.list)
  
}




for (j in 1:length(alpha_outs)) {
  seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
  param_list$param_vec[2] =  alpha_outs[j]
  param_list$param_vec[4] =  alpha_outs[j]
  
  seeding.results.array =  Parallel_Over_Seedings(A_matrix_list,param_list, 4, 100, 100, seedings = 1:4)
  save('seeding.results.array', file =  paste0("S2_results_array_alpha_out_",alpha_outs[j],".RData"))
  # rm(seeding.results.array)
  
}


#Nursery comp 3
#setwd(paste0(a,"/Nursery_comp_3/Vary_Beta"))
param_list$node.list = list(ncom = 20, ncons = 50, nnur = 40, nret = 50, Ret = 160*10)
param_list$param_vec[19:22] = c(20, 50,  40, 50)




rm(A_matrix_list)
A_matrix_list <- list()

for (i in 1:100) {
  
  A_matrix_list[[i]] = netgen.for.SI(param_list$node.list, param_list$distribution.list)
  
}



for (j in 1:length(alpha_outs)) {
  seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
  
  param_list$param_vec[2] =  alpha_outs[j]
  param_list$param_vec[4] =  alpha_outs[j]
  
  seeding.results.array =  Parallel_Over_Seedings(A_matrix_list,param_list, 4, 100, 100, seedings = 1:4)
  
  save('seeding.results.array', file =  paste0("S3_results_array_alpha_out_",alpha_outs[j],".RData"))
  # rm(seeding.results.array)
  
  
}




