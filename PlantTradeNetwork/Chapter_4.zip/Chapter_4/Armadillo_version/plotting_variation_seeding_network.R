library(patchwork)
library(gridExtra)
library(grid)
library(ggplot2)
# how to calculate monthly death rate from annual death rate 
#d.i <- 0.75
#1 - (1 - d.i)^(1/12)
# data is of the form: results.array = [ network, iteration, time, SI, Node group   ]

# plots to consider:
# test.data <- array(2, dim = c(100, 100, 37, 2, 7))
# test.data[, , , 2, ] = 1
# boxplots showing proportion infected per node group by time = 36
boxplots.function <- function(data, upper.y.lim){
 # data <- test.data
 # boxplot(as.vector(data[,,37,2,3] /(data[,,37,1,3] + data[,,37,2,3] ) ))  #I/N over all simulations
  
#  boxplot(rowSums(data[,,37,2,3]/(data[,,37,1,3] + data[,,37,2,3] ))/100)   #average I/N for each network 
  
  
  com.sols.df <-as.vector(data[,,37,2,1] /(data[,,37,1,1] + data[,,37,2,1] ) )
  com.sols.df[1] = 0
  
  cons.sols.df <- as.vector(data[,,37,2,2] /(data[,,37,1,2] + data[,,37,2,2] ) )
  cons.sols.df[1] = 0
  
  N.com.sols.df <- as.vector(data[,,37,2,3] /(data[,,37,1,3] + data[,,37,2,3] ) )
  N.cons.sols.df <- as.vector(data[,,37,2,4] /(data[,,37,1,4] + data[,,37,2,4] ) )
  N.nur.sols.df <- as.vector(data[,,37,2,5] /(data[,,37,1,5] + data[,,37,2,5] ) )
  N.ret.sols.df <- as.vector(data[,,37,2,6] /(data[,,37,1,6] + data[,,37,2,6] ) )
  ret.sols.df <-  as.vector(data[,,37,2,7] /(data[,,37,1,7] + data[,,37,2,7] ) )
  
  
  com.sols.df.per.network <-rowSums(data[,,37,2,1]/(data[,,37,1,1] + data[,,37,2,1] ))/dim(data)[1]
  com.sols.df.per.network[1] = 0
  
  cons.sols.df.per.network <- rowSums(data[,,37,2,2]/(data[,,37,1,2] + data[,,37,2,2] ))/dim(data)[1]
  cons.sols.df.per.network[1] = 0
  
  N.com.sols.df.per.network <-rowSums(data[,,37,2,3]/(data[,,37,1,3] + data[,,37,2,3] ))/dim(data)[1]
  N.cons.sols.df.per.network <- rowSums(data[,,37,2,4]/(data[,,37,1,4] + data[,,37,2,4] ))/dim(data)[1]
  N.nur.sols.df.per.network <- rowSums(data[,,37,2,5]/(data[,,37,1,5] + data[,,37,2,5] ))/dim(data)[1]
  N.ret.sols.df.per.network <- rowSums(data[,,37,2,6]/(data[,,37,1,6] + data[,,37,2,6] ))/dim(data)[1]
  ret.sols.df.per.network <-  rowSums(data[,,37,2,7]/(data[,,37,1,7] + data[,,37,2,7] ))/dim(data)[1]
  
  

  
  sols.df <- data.frame("Score" =c(com.sols.df, cons.sols.df, N.com.sols.df,
                                  N.cons.sols.df, N.nur.sols.df, N.ret.sols.df, ret.sols.df  ) , 
                        "Type" = rep( c("Com", "Cons", "N.com", "N.cons", "N.nur", "N.ret", "Ret"), c(rep(length(N.com.sols.df), 7)) ) )
  
  
  sols.df.per.network <- data.frame("Score" =c(com.sols.df.per.network, cons.sols.df.per.network, N.com.sols.df.per.network,
                                   N.cons.sols.df.per.network, N.nur.sols.df.per.network, N.ret.sols.df.per.network, ret.sols.df.per.network  ) , 
                        "Type" = rep( c("Com", "Cons", "N.com", "N.cons", "N.nur", "N.ret", "Ret"), c(rep(length(N.com.sols.df.per.network), 7)) ) )
  

  
  
  
  
  
#  dat.max <- max( c(#sols.df$Com.max, sols.df$Cons.max,
 #   sols.df$N.com.max, sols.df$N.cons.max, sols.df$N.nur.max, sols.df$N.ret.max, sols.df$ret.max ) )
  
  #dat.max <- ceiling_dec(dat.max, level = 2)
  
  
  
  #p.com <-
    
p1<-  ggplot(sols.df, aes(x = Type, y = Score )) + geom_boxplot() + theme_grey() + # ylim(0,dat.max) +
    xlab("") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete(labels = c( "Com", "Cons", expression(N[Com]),
                                                                       expression(N[Cons]),
                                                                       expression(N[Nur]),
                                                                       expression(N[Ret]),
                                                                       "Ret")) + 
    ggtitle(label = "Proportion infected after 3 years" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                             #   ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
                                                ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                , axis.text.x = element_text(size = 20, hjust = 0.5)
                                                , plot.title = element_text(hjust = 0.5, size = 20)
                                                , axis.text=element_text(size=20)
                                                ,legend.text = element_text(size = 20)
                                                ,legend.title = element_text(size = 20) ) + ylim(c(0,1))
    
    scale_y_continuous(limits = c(0,upper.y.lim)) 
  
  
  
 p2 <- ggplot(sols.df.per.network, aes(x = Type, y = Score )) + geom_boxplot() + theme_grey() + # ylim(0,dat.max) +
   xlab("") + ylab(expression("Proportion infected")) +
   theme(text = element_text(size=14)) + scale_x_discrete(labels = c( "Com", "Cons", expression(N[Com]),
                                                                      expression(N[Cons]),
                                                                      expression(N[Nur]),
                                                                      expression(N[Ret]),
                                                                      "Ret")) + 
   ggtitle(label = "Proportion infected after 3 years (per network)" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                                # ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
                                                                 ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                                 , axis.text.x = element_text(size = 20, hjust = 0.5)
                                                                 , plot.title = element_text(hjust = 0.5, size = 20)
                                                                 , axis.text=element_text(size=20)
                                                                 ,legend.text = element_text(size = 20)
                                                                 ,legend.title = element_text(size = 20) )  + ylim(c(0,1)) #+
   
 #  scale_y_continuous(limits = c(0,upper.y.lim)) 
  
 
  
  

  
  
  p10 <- p1# + p2 
  
  
  
  return(p10)

}











boxplots.function.nurseries <- function(data, upper.y.lim){
  # data <- test.data
  # boxplot(as.vector(data[,,37,2,3] /(data[,,37,1,3] + data[,,37,2,3] ) ))  #I/N over all simulations
  
  #  boxplot(rowSums(data[,,37,2,3]/(data[,,37,1,3] + data[,,37,2,3] ))/100)   #average I/N for each network 
  
  
  com.sols.df <-as.vector(data[,,37,2,1] /(data[,,37,1,1] + data[,,37,2,1] ) )
  com.sols.df[1] = 0
  
  cons.sols.df <- as.vector(data[,,37,2,2] /(data[,,37,1,2] + data[,,37,2,2] ) )
  cons.sols.df[1] = 0
  
  N.com.sols.df <- as.vector(data[,,37,2,3] /(data[,,37,1,3] + data[,,37,2,3] ) )
  N.cons.sols.df <- as.vector(data[,,37,2,4] /(data[,,37,1,4] + data[,,37,2,4] ) )
  N.nur.sols.df <- as.vector(data[,,37,2,5] /(data[,,37,1,5] + data[,,37,2,5] ) )
  N.ret.sols.df <- as.vector(data[,,37,2,6] /(data[,,37,1,6] + data[,,37,2,6] ) )
  ret.sols.df <-  as.vector(data[,,37,2,7] /(data[,,37,1,7] + data[,,37,2,7] ) )
  
  
  com.sols.df.per.network <-rowSums(data[,,37,2,1]/(data[,,37,1,1] + data[,,37,2,1] ))/dim(data)[1]
  com.sols.df.per.network[1] = 0
  
  cons.sols.df.per.network <- rowSums(data[,,37,2,2]/(data[,,37,1,2] + data[,,37,2,2] ))/dim(data)[1]
  cons.sols.df.per.network[1] = 0
  
  N.com.sols.df.per.network <-rowSums(data[,,37,2,3]/(data[,,37,1,3] + data[,,37,2,3] ))/dim(data)[1]
  N.cons.sols.df.per.network <- rowSums(data[,,37,2,4]/(data[,,37,1,4] + data[,,37,2,4] ))/dim(data)[1]
  N.nur.sols.df.per.network <- rowSums(data[,,37,2,5]/(data[,,37,1,5] + data[,,37,2,5] ))/dim(data)[1]
  N.ret.sols.df.per.network <- rowSums(data[,,37,2,6]/(data[,,37,1,6] + data[,,37,2,6] ))/dim(data)[1]
  ret.sols.df.per.network <-  rowSums(data[,,37,2,7]/(data[,,37,1,7] + data[,,37,2,7] ))/dim(data)[1]
  
  
  
  
  sols.df <- data.frame("Score" =c(com.sols.df, cons.sols.df, N.com.sols.df,
                                   N.cons.sols.df, N.nur.sols.df, N.ret.sols.df, ret.sols.df  ) , 
                        "Type" = rep( c("Com", "Cons", "N.com", "N.cons", "N.nur", "N.ret", "Ret"), c(rep(length(N.com.sols.df), 7)) ) )
  
  
  sols.df = sols.df[which(sols.df$Type %in% c("N.com", "N.cons", "N.nur", "N.ret")),]
  
  
  sols.df.per.network <- data.frame("Score" =c(com.sols.df.per.network, cons.sols.df.per.network, N.com.sols.df.per.network,
                                               N.cons.sols.df.per.network, N.nur.sols.df.per.network, N.ret.sols.df.per.network, ret.sols.df.per.network  ) , 
                                    "Type" = rep( c("Com", "Cons", "N.com", "N.cons", "N.nur", "N.ret", "Ret"), c(rep(length(N.com.sols.df.per.network), 7)) ) )
  
  
  
  
  
  
  
  #  dat.max <- max( c(#sols.df$Com.max, sols.df$Cons.max,
  #   sols.df$N.com.max, sols.df$N.cons.max, sols.df$N.nur.max, sols.df$N.ret.max, sols.df$ret.max ) )
  
  #dat.max <- ceiling_dec(dat.max, level = 2)
  
  
  
  #p.com <-
  
  p1<-  ggplot(sols.df, aes(x = Type, y = Score )) + geom_boxplot() + theme_grey() +  ylim(0,upper.y.lim) +
    xlab("") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete(labels = c( expression(N[Com]),
                                                                       expression(N[Cons]),
                                                                       expression(N[Nur]),
                                                                       expression(N[Ret])
                                                                       )) + 
    ggtitle(label = "Proportion infected after 3 years" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                                  #   ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
                                                                  ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                                  , axis.text.x = element_text(size = 20, hjust = 0.5)
                                                                  , plot.title = element_text(hjust = 0.5, size = 20)
                                                                  , axis.text=element_text(size=20)
                                                                  ,legend.text = element_text(size = 20)
                                                                  ,legend.title = element_text(size = 20) )
  
  #  scale_y_continuous(limits = c(0,upper.y.lim)) 
  
  
  
  p2 <- ggplot(sols.df.per.network, aes(x = Type, y = Score )) + geom_boxplot() + theme_grey() + # ylim(0,dat.max) +
    xlab("") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete(labels = c( "Com", "Cons", expression(N[Com]),
                                                                       expression(N[Cons]),
                                                                       expression(N[Nur]),
                                                                       expression(N[Ret]),
                                                                       "Ret")) + 
    ggtitle(label = "Proportion infected after 3 years (per network)" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                                                # ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
                                                                                ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                                                , axis.text.x = element_text(size = 20, hjust = 0.5)
                                                                                , plot.title = element_text(hjust = 0.5, size = 20)
                                                                                , axis.text=element_text(size=20)
                                                                                ,legend.text = element_text(size = 20)
                                                                                ,legend.title = element_text(size = 20) )  + ylim(c(0,1)) #+
  
  #  scale_y_continuous(limits = c(0,upper.y.lim)) 
  
  
  
  
  
  
  
  p10 <- p1# + p2 
  
  
  
  return(p10)
  
}





boxplots.nurseries.aggregate <- function(data, upper.y.lim){
  # data <- test.data
  # boxplot(as.vector(data[,,37,2,3] /(data[,,37,1,3] + data[,,37,2,3] ) ))  #I/N over all simulations
  
  #  boxplot(rowSums(data[,,37,2,3]/(data[,,37,1,3] + data[,,37,2,3] ))/100)   #average I/N for each network 
  
  
  com.sols.df <-as.vector(data[,,37,2,1] /(data[,,37,1,1] + data[,,37,2,1] ) )
  com.sols.df[1] = 0
  
  cons.sols.df <- as.vector(data[,,37,2,2] /(data[,,37,1,2] + data[,,37,2,2] ) )
  cons.sols.df[1] = 0
  
 # N.com.sols.df <- as.vector(data[,,37,2,3] /(data[,,37,1,3] + data[,,37,2,3] ) )
#  N.cons.sols.df <- as.vector(data[,,37,2,4] /(data[,,37,1,4] + data[,,37,2,4] ) )
#  N.nur.sols.df <- as.vector(data[,,37,2,5] /(data[,,37,1,5] + data[,,37,2,5] ) )
#  N.ret.sols.df <- as.vector(data[,,37,2,6] /(data[,,37,1,6] + data[,,37,2,6] ) )
  
  Nur.sols.df <- as.vector( (data[,,37,2,3] + data[,,37,2,4] + data[,,37,2,5] + data[,,37,2,6])/
                      (  data[,,37,1,3] + data[,,37,2,3] + data[,,37,1,4] + data[,,37,2,4] + data[,,37,1,5] + data[,,37,2,5] + data[,,37,1,6] + data[,,37,2,6]   ) )
  
  ret.sols.df <-  as.vector(data[,,37,2,7] /(data[,,37,1,7] + data[,,37,2,7] ) )
  
  
  com.sols.df.per.network <-rowSums(data[,,37,2,1]/(data[,,37,1,1] + data[,,37,2,1] ))/dim(data)[1]
  com.sols.df.per.network[1] = 0
  
  cons.sols.df.per.network <- rowSums(data[,,37,2,2]/(data[,,37,1,2] + data[,,37,2,2] ))/dim(data)[1]
  cons.sols.df.per.network[1] = 0
  
  #N.com.sols.df.per.network <-rowSums(data[,,37,2,3]/(data[,,37,1,3] + data[,,37,2,3] ))/dim(data)[1]
  #N.cons.sols.df.per.network <- rowSums(data[,,37,2,4]/(data[,,37,1,4] + data[,,37,2,4] ))/dim(data)[1]
  #N.nur.sols.df.per.network <- rowSums(data[,,37,2,5]/(data[,,37,1,5] + data[,,37,2,5] ))/dim(data)[1]
  #N.ret.sols.df.per.network <- rowSums(data[,,37,2,6]/(data[,,37,1,6] + data[,,37,2,6] ))/dim(data)[1]
  
  Nur.sols.df.per.network <-  rowSums( (data[,,37,2,3] + data[,,37,2,4] + data[,,37,2,5] + data[,,37,2,6])/
                                         (  data[,,37,1,3] + data[,,37,2,3] + data[,,37,1,4] + data[,,37,2,4] + data[,,37,1,5] + data[,,37,2,5] + data[,,37,1,6] + data[,,37,2,6]   )     )/dim(data)[1]
  
  ret.sols.df.per.network <-  rowSums(data[,,37,2,7]/(data[,,37,1,7] + data[,,37,2,7] ))/dim(data)[1]
  
  
  
  
  # sols.df <- data.frame("Score" =c(com.sols.df, cons.sols.df, N.com.sols.df,
  #                                  N.cons.sols.df, N.nur.sols.df, N.ret.sols.df, ret.sols.df  ) , 
  #                       "Type" = rep( c("Com", "Cons", "N.com", "N.cons", "N.nur", "N.ret", "Ret"), c(rep(length(N.com.sols.df), 7)) ) )
  
  # VERSION TO JUST PLOT FOR ALL NODE 
  # sols.df <- data.frame("Score" =c(com.sols.df, cons.sols.df, Nur.sols.df, ret.sols.df  ) , 
  #                       "Type" = rep( c("Com", "Cons", "Nur", "Ret"), c(rep(length(com.sols.df), 4)) ) )
  
  
  # VERSION TO JUST PLOT FOR NURSERIES
  sols.df <- data.frame("Score" =c( Nur.sols.df  ) , 
                        "Type" = rep( c("Nur"), c(rep(length(com.sols.df), 1)) ) )
  
  
  #sols.df = sols.df[which(sols.df$Type %in% c("Nur", "Ret")),]
  
  
  #sols.df.per.network <- data.frame("Score" =c(com.sols.df.per.network, cons.sols.df.per.network, N.com.sols.df.per.network,
  #                                             N.cons.sols.df.per.network, N.nur.sols.df.per.network, N.ret.sols.df.per.network, ret.sols.df.per.network  ) , 
  #                                  "Type" = rep( c("Com", "Cons", "N.com", "N.cons", "N.nur", "N.ret", "Ret"), c(rep(length(N.com.sols.df.per.network), 7)) ) )
  
  
  sols.df.per.network <- data.frame("Score" =c(com.sols.df.per.network, cons.sols.df.per.network, Nur.sols.df.per.network, ret.sols.df.per.network  ) , 
                                    "Type" = rep( c("Com", "Cons", "Nur", "Ret"), c(rep(length(com.sols.df.per.network), 4)) ) )
  
  
  
  
  #  dat.max <- max( c(#sols.df$Com.max, sols.df$Cons.max,
  #   sols.df$N.com.max, sols.df$N.cons.max, sols.df$N.nur.max, sols.df$N.ret.max, sols.df$ret.max ) )
  
  #dat.max <- ceiling_dec(dat.max, level = 2)
  
  
  
  #p.com <-
  
  
  # VERSION TO PLOT FOR ALL NODE GROUPS
  # p1<-  ggplot(sols.df, aes(x = Type, y = Score )) + geom_boxplot() + theme_grey() +  ylim(0,upper.y.lim) +
  #   xlab("") + ylab(expression("Proportion")) +
  #   theme(text = element_text(size=14)) + scale_x_discrete(labels = c( expression("Com"), expression("Cons") ,expression("Nur"), expression("Ret") )
  #   ) + 
  #   ggtitle(label = "Proportion infected after 3 years" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
  #                                                                 #   ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
  #                                                                 ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
  #                                                                 , axis.text.x = element_text(size = 20, hjust = 0.5)
  #                                                                 , plot.title = element_text(hjust = 0.5, size = 20)
  #                                                                 , axis.text=element_text(size=20)
  #                                                                 ,legend.text = element_text(size = 20)
  #                                                                 ,legend.title = element_text(size = 20) )
  
  
  
  # VERSION TO JUST PLOT FOR NURSERIES
  p1<-  ggplot(sols.df, aes(x = Type, y = Score )) + geom_boxplot() + theme_grey() +  ylim(0,upper.y.lim) +
    xlab("") + ylab(expression("Proportion")) +
    theme(text = element_text(size=14)) + scale_x_discrete(labels = c( expression("Nursery") )
    ) + 
    ggtitle(label = "Proportion infected after 3 years" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                                  #   ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
                                                                  ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                                  , axis.text.x = element_text(size = 20, hjust = 0.5)
                                                                  , plot.title = element_text(hjust = 0.5, size = 20)
                                                                  , axis.text=element_text(size=20)
                                                                  ,legend.text = element_text(size = 20)
                                                                  ,legend.title = element_text(size = 20) )
  
  
  
  #  scale_y_continuous(limits = c(0,upper.y.lim)) 
  
  
  
#  p2 <- ggplot(sols.df.per.network, aes(x = Type, y = Score )) + geom_boxplot() + theme_grey() + # ylim(0,dat.max) +
#    xlab("") + ylab(expression("Proportion infected")) +
#    theme(text = element_text(size=14)) + scale_x_discrete(labels = c( "Com", "Cons", expression(N[Com]),
 #                                                                      expression(N[Cons]),
#                                                                       expression(N[Nur]),
#                                                                       expression(N[Ret]),
#                                                                       "Ret")) + 
#    ggtitle(label = "Proportion infected after 3 years (per network)" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                                                # ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
 #                                                                               ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
#                                                                                , axis.text.x = element_text(size = 20, hjust = 0.5)
#                                                                                , plot.title = element_text(hjust = 0.5, size = 20)
#                                                                                , axis.text=element_text(size=20)
#                                                                                ,legend.text = element_text(size = 20)
#                                                                                ,legend.title = element_text(size = 20) )  + ylim(c(0,1)) #+
  
  #  scale_y_continuous(limits = c(0,upper.y.lim)) 
  
  
  
  
  
  
  
  #p10 <- p1 + p2 
  
  
  
  return(p1)
  
}



# 
# time until 20% of nurseries are infected
#
till.twenty.function <- function(data, min_y_lim){
   #data <- test
  
  #cbind(seq(from = 1, by = 10000, length = 37),
  #seq(from = 10000, by = 10000, to = 370000) )
  
  
  Total.Nur.Inf <-as.vector(data[,,,2,3] + data[,,,2,4] +
                   data[,,,2,5] + data[,,,2,6]) # every 10,000 elements is a time-step
                   
    
    Total.Nur.N <-   as.vector(data[,,,1,3] + data[,,,2,3] ) +
                     as.vector(data[,,,1,4] + data[,,,2,4] ) +
                     as.vector(data[,,,1,5] + data[,,,2,5] ) +
                     as.vector(data[,,,1,6] + data[,,,2,6] ) 
                     
  
Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
Total.Nur.prop.inf = as.data.frame(Total.Nur.prop.inf)
#2nd column to detail time step
Total.Nur.prop.inf[,2] = NA
Total.Nur.prop.inf[,2] <- sort(rep(c(0:36),(dim(data)[1] * dim(data)[2])))
# 3rd column to identify simulation number
Total.Nur.prop.inf[,3] = NA
Total.Nur.prop.inf[,3] = rep((1:(dim(data)[1] * dim(data)[2])), 37)

# extract where >20% nurseries are infected
Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2:3]       

# problem is that this also includes further time-points
# we only want the first occurrence of >20% nurseries are infected per sim.

#returns earliest time-steps where >20% nurseries are infected
#Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])]


  
  sols.df <- data.frame("Time" = Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])] ,
                         "Type" = rep("Nursery", length(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])])))
  
  sols.df$Time = as.numeric(sols.df$Time)
  
  Total.Nur.prop.inf.per.network <-sapply(X=1:37,  function(X) rowSums((data[,,X,2,3]+data[,,X,2,4]+data[,,X,2,5]+data[,,X,2,6] ) # total infected averaged over 100 iterations 
   /(data[,,X,2,3]+data[,,X,2,4]+data[,,X,2,5]+data[,,X,2,6] + data[,,X,1,3]+data[,,X,1,4]+data[,,X,1,5]+data[,,X,1,6]) ))/dim(data)[1]
  
  
  Total.Nur.prop.inf.per.network = as.data.frame(as.numeric(unlist(Total.Nur.prop.inf.per.network)))
  
  
  #2nd column to detail time step
  Total.Nur.prop.inf.per.network[,2] = NA
  Total.Nur.prop.inf.per.network[,2] <- sort(rep(c(0:36),dim(data)[1]))
  # 3rd column to identify network number
  Total.Nur.prop.inf.per.network[,3] = NA
  Total.Nur.prop.inf.per.network[,3] = rep(dim(data)[1], 37)
  
  # extract where >20% nurseries are infected
  Total.Nur.prop.inf.per.network[which(Total.Nur.prop.inf.per.network[,1] > 0.2),3] 
  
  
  
  sols.df.per.network <- data.frame("Time" = Total.Nur.prop.inf.per.network[which(Total.Nur.prop.inf.per.network[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf.per.network[which(Total.Nur.prop.inf.per.network[,1] > 0.2),3])],
                                   "Type" = rep("Nursery",length(Total.Nur.prop.inf.per.network[which(Total.Nur.prop.inf.per.network[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf.per.network[which(Total.Nur.prop.inf.per.network[,1] > 0.2),3])])) )
  
  
  sols.df.per.network$Time = as.numeric(sols.df.per.network$Time)


  p1 <-  ggplot(sols.df, aes(x = Type, y = Time )) + geom_boxplot() + theme_grey() +  ylim(min_y_lim,36) +
    xlab("") + ylab(expression("Time")) +
    theme(text = element_text(size=14)) + 
    ggtitle(label = "Time until 20% of nurseries are infected" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                                  #   ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
                                                                  ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                                  , axis.text.x = element_text(size = 20, hjust = 0.5)
                                                                  , plot.title = element_text(hjust = 0.5, size = 20)
                                                                  , axis.text=element_text(size=20)
                                                                  ,legend.text = element_text(size = 20)
                                                                  ,legend.title = element_text(size = 20) ) 
  
  #  scale_y_continuous(limits = c(0,upper.y.lim)) 
  
  if(length(unlist(sols.df.per.network)) !=0){
  
  p2 <- ggplot(sols.df.per.network, aes(x = Type, y = Time )) + geom_boxplot() + theme_grey() +  ylim(18,36) +
    xlab("") + ylab(expression("Time")) +
    theme(text = element_text(size=14)) + 
    ggtitle(label = "Time until 20% of nurseries are infected per network" ) + theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                                         #   ,axis.title.y.right = element_text(size = 20,margin = margin(t = 0, r = 10, b = 0, l = 10))
                                                                         ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                                         , axis.text.x = element_text(size = 20, hjust = 0.5)
                                                                         , plot.title = element_text(hjust = 0.5, size = 20)
                                                                         , axis.text=element_text(size=20)
                                                                         ,legend.text = element_text(size = 20)
                                                                         ,legend.title = element_text(size = 20) ) 
  
  
  
  
  p10 <- p1 + p2 

  
  }
  
  p10 <- p1
  
  
  
  
  
  
  
  
  
  
  
  return(p10)

}





boxplots.function(test.10)
boxplots.function(test.20)
boxplots.function(test.50)
boxplots.function(test.70)
boxplots.function(test.80)
boxplots.function(test.100)



# plotting function

# inputs: the data, quantiles, 


#a <- getwd()




# 3 scenarios
# 6 parameters
# 4 plots for each

#varied beta: 0.5, 1, 1.5, 2, 2.5, 3. 

#beta = 0.5, 1: no infection
# beta =  1.5, low infection ( max 25% infected)
# beta = 2, medium infection (max 50% infected)
# beta = 2.5, <65% infected
# beta = 3, <75% infected

#less of a jump from 2.5-3 than 2-2.5

#boxplots.function(get(load( paste0("S",1,"_results_array_beta_3.RData")))[3,,,, , ])

#plot 1

# X axis: beta values

# y axis: time until 20% of nurseries infected (use median, upper, lower quartiles)

till.twenty.lineplot <- function(scenario, lower_quant, upper_quant){

betas <- seq(0.5, 3, by = 0.5)

sols.df <- data.frame("betas" = betas) 

sols.df[,2:13 ] = NA

for (j in 2:5) {
  t.prop.inf <- c()
  t.lower.quant <- c()
  t.upper.quant <- c()
  
for (k in 1:length(betas)) {
  
dat <-get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[(j-1),,,, , ]
  
Total.Nur.Inf <-as.vector(dat[,,,2,3] + dat[,,,2,4] +
                            dat[,,,2,5] + dat[,,,2,6]) # every 10,000 elements is a time-step


Total.Nur.N <-   as.vector(dat[,,,1,3] + dat[,,,2,3] ) +
  as.vector(dat[,,,1,4] + dat[,,,2,4] ) +
  as.vector(dat[,,,1,5] + dat[,,,2,5] ) +
  as.vector(dat[,,,1,6] + dat[,,,2,6] ) 

Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
Total.Nur.prop.inf = as.data.frame(Total.Nur.prop.inf)
#2nd column to detail time step
Total.Nur.prop.inf[,2] = NA
Total.Nur.prop.inf[,2] <- sort(rep(c(0:36),(dim(dat)[1] * dim(dat)[2])))
# 3rd column to identify simulation number
Total.Nur.prop.inf[,3] = NA
Total.Nur.prop.inf[,3] = rep((1:(dim(dat)[1] * dim(dat)[2])), 37)

# extract where >20% nurseries are infected
Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2:3]       

t.prop.inf = c(t.prop.inf,
               median(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])]) )


t.lower.quant = c(t.lower.quant,
               quantile(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])], lower_quant) )


t.upper.quant = c(t.upper.quant,
                  quantile(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])], upper_quant) )




  }


sols.df[,j] = t.prop.inf
sols.df[,(j + 4) ] = t.lower.quant
sols.df[,(j + 8) ] = t.upper.quant

}


colnames(sols.df) = c("betas", "N.com", "N.cons", "N.nur", "N.ret" )

sols.df.2 <- data.frame("betas" = rep(betas, 4), 
                        "Median_Time" = c(sols.df[,2], sols.df[,3], sols.df[,4], sols.df[,5] ), 
                        "LQ_Time" = c(sols.df[,6], sols.df[,7], sols.df[,8], sols.df[,9] ),
                        "UQ_Time" = c(sols.df[,10], sols.df[,11], sols.df[,12], sols.df[,13] ),
                        "Seeding" = c(rep("N.com", 6), rep("N.cons", 6), rep("N.nur", 6), rep("N.ret", 6) ))


p1 <- ggplot(sols.df.2, aes(x = betas, y = Median_Time, group = Seeding )) +
  geom_line(aes(color = Seeding), size = 1) + geom_point(aes(color = Seeding), size = 2) + 
  geom_errorbar(aes(ymin = LQ_Time, ymax = UQ_Time , width=.1, color = Seeding ), size = 1) +
  theme_grey() +
  xlab(expression(beta)) + ylab(expression("Time")) +
  scale_x_continuous(expand=c(0,0), breaks = seq(0.5,3, by = 0.5), limits = c(-0.01, 3.1))+
  scale_y_continuous(expand=c(0,0), breaks = seq(10,35, by = 5), limits = c(9.99, 35.1))+
  theme(text = element_text(size=14)) + 
  ggtitle(label = paste0("S",scenario,": Time until 20% of nurseries infected" ) ) + 
  theme(plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
        axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
  ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
  , axis.text.x = element_text(size = 20, hjust = 0.5)
  , plot.title = element_text(hjust = 0.5, size = 20)
  , axis.text=element_text(size=20)
  ,legend.text = element_text(size = 20, hjust = 0)
  ,legend.title = element_text(size = 20) ) +
                      

 scale_color_manual(values=c("#228b22ff", "#db7093ff", "#00008bff", "black"), 
                   name= "Seeding",
                           breaks= c("N.com","N.cons","N.nur", "N.ret"),
                           labels=c(expression(N[Com]),
                                    expression(N[Cons]),
                                    expression(N[Nur]),
                                    expression(N[Ret])))

return(p1)
}



p1 <- till.twenty.lineplot(1, 0.25, 0.75) + till.twenty.lineplot(2, 0.25, 0.75) +
  till.twenty.lineplot(3, 0.25, 0.75)  + plot_layout( guides = "collect")
ggsave(
  filename = "Time_till_20_inf_VaryBeta_S123_50_perc_int.png",
  device="png",
  width=1.5*3600,
  height=0.75*3600,
  units="px",
  plot=p1, 
  limitsize = TRUE
)

p1







# plot 2: line graph for each node group

# X axis: beta values

# y axis: proportion infected by t=36 (use median value, upper, lower quartiles)



prop.inf.by.t36.lineplot <- function(scenario, lower_quant, upper_quant){
  
  betas <- seq(0.5, 3, by = 0.5)
  
  sols.df <- data.frame("betas" = betas) 
  
sols.df[,2:13] = NA
  
  
  
  
  
  for (j in 2:5) {
    t.prop.inf <- c()
    t.lower.quant <- c()
    t.upper.quant <- c()
    
    for (k in 1:length(betas)) {
      
      dat <-get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[(j-1),,,, , ]
        
 # com.sols.df <-as.vector(dat[,,37,2,1] /(dat[,,37,1,1] + dat[,,37,2,1] ) )
#  com.sols.df[1] = 0
  
 # cons.sols.df <- as.vector(dat[,,37,2,2] /(dat[,,37,1,2] + dat[,,37,2,2] ) )
 # cons.sols.df[1] = 0
  

      Total.Nur.Inf <-as.vector(dat[,,37,2,3] + dat[,,37,2,4] +
                                  dat[,,37,2,5] + dat[,,37,2,6]) # every 10,000 elements is a time-step
      
      
      Total.Nur.N <-   as.vector(dat[,,37,1,3] + dat[,,37,2,3] ) +
        as.vector(dat[,,37,1,4] + dat[,,37,2,4] ) +
        as.vector(dat[,,37,1,5] + dat[,,37,2,5] ) +
        as.vector(dat[,,37,1,6] + dat[,,37,2,6] ) 
      
      Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
      
      t.prop.inf = c(t.prop.inf, median(Total.Nur.prop.inf)    )
      t.lower.quant = c( t.lower.quant, quantile(Total.Nur.prop.inf, lower_quant)    )
      t.upper.quant = c( t.upper.quant, quantile(Total.Nur.prop.inf, upper_quant)    )
    }
    
    
    sols.df[,j] = t.prop.inf
    sols.df[,(j + 4) ] = t.lower.quant
    sols.df[,(j + 8) ] = t.upper.quant
    
  }
  
  
  colnames(sols.df) = c("betas", "N.com", "N.cons", "N.nur", "N.ret" )
  
  sols.df.2 <- data.frame("betas" = rep(betas, 4), 
                          "Proportion" = c(sols.df[,2], sols.df[,3], sols.df[,4], sols.df[,5] ),
                          "LQ_Time" = c(sols.df[,6], sols.df[,7], sols.df[,8], sols.df[,9] ),
                          "UQ_Time" = c(sols.df[,10], sols.df[,11], sols.df[,12], sols.df[,13] ),
                          "Seeding" = c(rep("N.com", 6), rep("N.cons", 6), rep("N.nur", 6), rep("N.ret", 6) ))
  
  
  p1 <- ggplot(sols.df.2, aes(x = betas, y = Proportion, group = Seeding )) + geom_line(aes(color = Seeding)) + geom_point() +
    geom_errorbar(aes(ymin = LQ_Time, ymax = UQ_Time , width=.1, color = Seeding ), size = 1)+
    theme_grey() +
    xlab(expression(beta)) + ylab(expression("Proportion")) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0.5,3, by = 0.5), limits = c(-0.01, 3.1))+
    scale_y_continuous(expand=c(0,0), breaks = seq(0,0.7, by = 0.1), limits = c(-0.01, 0.71))+
    theme(text = element_text(size=14)) + 
    ggtitle(label = paste0("S",scenario,": Proportion infected in nurseries by t = 36" ) ) + 
    theme(plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
          axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(size = 20, hjust = 0.5)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20, hjust = 0)
          ,legend.title = element_text(size = 20) ) +
    
    
    scale_color_manual(values=c("#228b22ff", "#db7093ff", "#00008bff", "black"), 
                       name= "Seeding",
                       breaks= c("N.com","N.cons","N.nur", "N.ret"),
                       labels=c(expression(N[Com]),
                                expression(N[Cons]),
                                expression(N[Nur]),
                                expression(N[Ret])))
  
  return(p1)
}

prop.inf.by.t36.lineplot(1, 0.25, 0.75)

p2 <- prop.inf.by.t36.lineplot(1, 0.25, 0.75) + 
  prop.inf.by.t36.lineplot(2, 0.25, 0.75) + 
  prop.inf.by.t36.lineplot(3, 0.25, 0.75)  + plot_layout( guides = "collect")
ggsave(
  filename = "Prop_inf_by_t36_VaryBeta_S123_50_perc_int.png",
  device="png",
  width=1.75*3600,
  height=0.75*3600,
  units="px",
  plot=p2, 
  limitsize = TRUE
)





scenario = 3

betas <- seq(2, 3, by = 0.5)



for (k in 1:length(betas)) {
  


    
    dat <-(get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[1,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[2,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[3,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[4,,,, , ]) /4 
    
    
  
  
  a<-bquote(atop( beta ==  .(betas[k]) )  )
  
  p12 <-  till.twenty.function(dat, min_y_lim = 10) +ggtitle("Time until 20% infected", a)
  
  
  
  assign(paste0("P.",k), p12)
  
  
}


layout <- '
ABC
'


p.12 <-  wrap_plots(A = P.1, B = P.2, C= P.3,  design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.12
ggsave(
  filename = paste0("S", scenario, "_Vary_beta_t_until_20_perc_inf"  , ".png"),
  device="png",
  width=1.5*3600,
  height=0.75*3600,
  units="px",
  plot=p.12, 
  limitsize = TRUE
)





scenario = 3


betas <- seq(0.5, 3, by = 0.5)


for (k in 1:length(betas)) {
  
  
  dat <-(get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[1,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[2,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[3,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_beta_", betas[k],".RData"))))[4,,,, , ]) /4 
  
  a<-bquote(atop( beta ==  .(betas[k]) )  )
  
  p11 <-  boxplots.function.nurseries(dat, 1) +ggtitle("Infected by t=36", a)
  
  
  
  assign(paste0("P.",k), p11)
  
  
}


layout <- '
ABC
DEG
'


p.10 <-   wrap_plots(A = P.1, B = P.2, C= P.3,
                     D = P.4, E = P.5, G= P.6, design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.10
ggsave(
  filename = paste0("S", scenario, "_Vary_beta_prop_inf_by_t36_boxplots"  , ".png"),
  device="png",
  width=1.35*3600,
  height=1.25*3600,
  units="px",
  plot=p.10, 
  limitsize = TRUE
)




# death rate functions -----------------------------------------

# plot idea: average over the seedings first:

#  6 panels of  boxplots for each scenario.






scenario = 1
  
  D.i <- c(0,0.7,0.9,1)
  D.s <- c(0, 0.7, 0.9, 1)
  combinations <- expand.grid(D.i, D.s)
  
  combinations <- combinations[combinations[,1] >= combinations[,2] , ]
  
  sols.df <- data.frame("D.I" = combinations[,1], "D.S" = combinations[,2] ) 
  
  
    for (k in 1:nrow(combinations)) {
      
      
      dat <-(get(load( paste0("S",scenario,paste0("_results_array_Di_", combinations[k,1],
                                                  "_Ds_", combinations[k,2],".RData"))))[1,,,, , ] +
               
               get(load( paste0("S",scenario,paste0("_results_array_Di_", combinations[k,1],
                                                    "_Ds_", combinations[k,2],".RData"))))[2,,,, , ] +
               
               get(load( paste0("S",scenario,paste0("_results_array_Di_", combinations[k,1],
                                                    "_Ds_", combinations[k,2],".RData"))))[3,,,, , ] +
               
               get(load( paste0("S",scenario,paste0("_results_array_Di_", combinations[k,1],
                                                    "_Ds_", combinations[k,2],".RData"))))[4,,,, , ]) /4 
      
      a<-bquote(atop( d['S'] == .(combinations[k,2]) ~","~  d['I'] == .(combinations[k,1])  )  )
      
      p11 <-  till.twenty.function(dat, 10 ) +ggtitle("Time until 20% infected", a)
      
    
      
      assign(paste0("P.",k), p11)
      
      
    }
    

layout <- '
ABCD
#EGH
##IJ
###K
'


p.12 <-   wrap_plots(A = P.1, B = P.2, C= P.3, D= P.4,
                     E = P.5, G = P.6, H = P.7 , I = P.8, J = P.9, K = P.10, design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.12
ggsave(
  filename = paste0("S", scenario, "_Vary_Deathrates_boxplots_time_till_20_inf"  , ".png"),
  device="png",
  width=1.25*3600,
  height=3600,
  units="px",
  plot=p.12, 
  limitsize = TRUE
)



scenario = 3

D.i <- c(0, 0.7,0.9,1)
D.s <- c(0, 0.7, 0.9, 1)
combinations <- expand.grid(D.i, D.s)

combinations <- combinations[combinations[,1] >= combinations[,2] , ]

sols.df <- data.frame("D.I" = combinations[,1], "D.S" = combinations[,2] ) 


for (k in 1:nrow(combinations)) {
  
  
  dat <-(get(load( paste0("S",scenario,paste0("_results_array_Di_", combinations[k,1],
                                              "_Ds_", combinations[k,2],".RData"))))[1,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Di_", combinations[k,1],
                                                "_Ds_", combinations[k,2],".RData"))))[2,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Di_", combinations[k,1],
                                                "_Ds_", combinations[k,2],".RData"))))[3,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Di_", combinations[k,1],
                                                "_Ds_", combinations[k,2],".RData"))))[4,,,, , ]) /4 
  
  a<-bquote(atop( d['S'] == .(combinations[k,2]) ~ ","~  d['I'] == .(combinations[k,1])  )  )

  p11 <-  boxplots.nurseries.aggregate(dat, 1) +ggtitle("Infected by t=36", a)
  
  
  
  assign(paste0("P.",k), p11)
  
  
}


layout <- '
ABCD
#EGH
##IJ
###K

'


p.10 <-   wrap_plots(A = P.1, B = P.2, C= P.3, D= P.4,
                     E = P.5, G = P.6, H = P.7, I = P.8, J = P.9, K = P.10, design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.10
ggsave(
  filename = paste0("S", scenario, "_Deathrates_prop_inf_by_t36_boxplots_Jan2023"  , ".png"),
  device="png",
  width=1.35*3600,
  height=1.25*3600,
  units="px",
  plot=p.10, 
  limitsize = TRUE
)







# code for plotting time-series for all node groups


#load("S1_results_array_beta_2.RData")
str(seeding.results.array)
#loading in S1 beta 2 ( baseline parameters)



ceiling_dec <- function(x, level=1){ round(x + 5*10^(-level-1), level) }

disease.plotting.function <- function(data, lower.quantile, upper.quantile){
 
  
#  data <- (seeding.results.array[1, , , , , ] + seeding.results.array[2, , , , , ] + seeding.results.array[3, , , , , ] + seeding.results.array[4, , , , , ])/4  
  
  for (j in 1:2) {
    
  for (i in 37:2) {
    
  data[ , , i, , j] = data[ , , i, , j] - data[ , , i-1, , j]
  
  } 
    
  }
  # every 10000 a time step
  a1 <- seq(1, by = 10000, to =  360001)
  a2 <- seq(10000, by = 10000, to = 370000)
  a3 <- cbind(a1, a2)
  
  
  com.sols.df <- as.vector(data[, , , 2, 1])/( as.vector(data[, , , 1, 1]) + as.vector(data[, , , 2, 1]))
  com.sols.df[1:10000] = 0
  
  cons.sols.df <- as.vector(data[, , , 2, 2])/( as.vector(data[, , , 1, 2]) + as.vector(data[, , , 2, 2]))
  cons.sols.df[1:10000] = 0
  
  N.com.sols.df <- as.vector(data[, , , 2, 3])/( as.vector(data[, , , 1, 3]) + as.vector(data[, , , 2, 3]))
  
  N.cons.sols.df <- as.vector(data[, , , 2, 4])/( as.vector(data[, , , 1, 4]) + as.vector(data[, , , 2, 4]))
  
  N.nur.sols.df <- as.vector(data[, , , 2, 5])/( as.vector(data[, , , 1, 5]) + as.vector(data[, , , 2, 5]))
  
  N.ret.sols.df <- as.vector(data[, , , 2, 6])/( as.vector(data[, , , 1, 6]) + as.vector(data[, , , 2, 6]))
  
  ret.sols.df <- as.vector(data[, , , 2, 7])/( as.vector(data[, , , 1, 7]) + as.vector(data[, , , 2, 7]))
  
  
  
  

  
  Time <- 0:(dim(data)[3]-1)
  
  sols.df <- data.frame("Time" = Time , "Com.mean" = sapply(1:dim(data)[3], function(x) mean(as.numeric(com.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "Com.med" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(com.sols.df[a3[x,1]:a3[x,2]]), probs = 0.5, na.rm = TRUE)),
                        "Com.lower.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(com.sols.df[a3[x,1]:a3[x,2]]), probs = lower.quantile, na.rm = TRUE)),
                        "Com.upper.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(com.sols.df[a3[x,1]:a3[x,2]]), probs = upper.quantile, na.rm = TRUE)),
                        "Com.min" = sapply(1:dim(data)[3], function(x) min(as.numeric(com.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "Com.max" = sapply(1:dim(data)[3], function(x) max(as.numeric(com.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "Com.sd" = sapply(1:dim(data)[3], function(x) sd(as.numeric(com.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "Cons.mean" = sapply(1:dim(data)[3], function(x) mean(as.numeric(cons.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "Cons.med" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(cons.sols.df[a3[x,1]:a3[x,2]]), probs = 0.5, na.rm = TRUE)),
                        "Cons.lower.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(cons.sols.df[a3[x,1]:a3[x,2]]), probs = lower.quantile, na.rm = TRUE)),
                        "Cons.upper.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(cons.sols.df[a3[x,1]:a3[x,2]]), probs = upper.quantile, na.rm = TRUE)),
                        "Cons.min" = sapply(1:dim(data)[3], function(x) min(as.numeric(cons.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "Cons.max" = sapply(1:dim(data)[3], function(x) max(as.numeric(cons.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "Cons.sd" = sapply(1:dim(data)[3], function(x) sd(as.numeric(cons.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "N.com.mean" = sapply(1:dim(data)[3], function(x) mean(as.numeric(N.com.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "N.com.med" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.com.sols.df[a3[x,1]:a3[x,2]]), probs = 0.5, na.rm = TRUE)),
                        "N.com.lower.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.com.sols.df[a3[x,1]:a3[x,2]]), probs = lower.quantile, na.rm = TRUE)),
                        "N.com.upper.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.com.sols.df[a3[x,1]:a3[x,2]]), probs = upper.quantile, na.rm = TRUE)),
                        "N.com.min" = sapply(1:dim(data)[3], function(x) min(as.numeric(N.com.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "N.com.max" = sapply(1:dim(data)[3], function(x) max(as.numeric(N.com.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "N.com.sd" = sapply(1:dim(data)[3], function(x) sd(as.numeric(N.com.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "N.cons.mean" = sapply(1:dim(data)[3], function(x) mean(as.numeric(N.cons.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "N.cons.med" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.cons.sols.df[a3[x,1]:a3[x,2]]), probs = 0.5, na.rm = TRUE)),
                        "N.cons.lower.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.cons.sols.df[a3[x,1]:a3[x,2]]), probs = lower.quantile, na.rm = TRUE)),
                        "N.cons.upper.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.cons.sols.df[a3[x,1]:a3[x,2]]), probs = upper.quantile, na.rm = TRUE)),
                        "N.cons.min" = sapply(1:dim(data)[3], function(x) min(as.numeric(N.cons.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "N.cons.max" = sapply(1:dim(data)[3], function(x) max(as.numeric(N.cons.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "N.cons.sd" = sapply(1:dim(data)[3], function(x) sd(as.numeric(N.cons.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "N.nur.mean" = sapply(1:dim(data)[3], function(x) mean(as.numeric(N.nur.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "N.nur.med" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.nur.sols.df[a3[x,1]:a3[x,2]]), probs = 0.5, na.rm = TRUE)),
                        "N.nur.lower.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.nur.sols.df[a3[x,1]:a3[x,2]]), probs = lower.quantile, na.rm = TRUE)),
                        "N.nur.upper.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.nur.sols.df[a3[x,1]:a3[x,2]]), probs = upper.quantile, na.rm = TRUE)),
                        "N.nur.min" = sapply(1:dim(data)[3], function(x) min(as.numeric(N.nur.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "N.nur.max" = sapply(1:dim(data)[3], function(x) max(as.numeric(N.nur.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "N.nur.sd" = sapply(1:dim(data)[3], function(x) sd(as.numeric(N.nur.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "N.ret.mean" = sapply(1:dim(data)[3], function(x) mean(as.numeric(N.ret.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "N.ret.med" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.ret.sols.df[a3[x,1]:a3[x,2]]), probs = 0.5, na.rm = TRUE)),
                        "N.ret.lower.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.ret.sols.df[a3[x,1]:a3[x,2]]), probs = lower.quantile, na.rm = TRUE)),
                        "N.ret.upper.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(N.ret.sols.df[a3[x,1]:a3[x,2]]), probs = upper.quantile, na.rm = TRUE)),
                        "N.ret.min" = sapply(1:dim(data)[3], function(x) min(as.numeric(N.ret.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "N.ret.max" = sapply(1:dim(data)[3], function(x) max(as.numeric(N.ret.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "N.ret.sd" = sapply(1:dim(data)[3], function(x) sd(as.numeric(N.ret.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "ret.mean" = sapply(1:dim(data)[3], function(x) mean(as.numeric(ret.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)),
                        "ret.med" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(ret.sols.df[a3[x,1]:a3[x,2]]), probs = 0.5, na.rm = TRUE)),
                        "ret.lower.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(ret.sols.df[a3[x,1]:a3[x,2]]), probs = lower.quantile, na.rm = TRUE)),
                        "ret.upper.quantile" = sapply(1:dim(data)[3], function(x) quantile(as.numeric(ret.sols.df[a3[x,1]:a3[x,2]]), probs = upper.quantile, na.rm = TRUE)),
                        "ret.min" = sapply(1:dim(data)[3], function(x) min(as.numeric(ret.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "ret.max" = sapply(1:dim(data)[3], function(x) max(as.numeric(ret.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)), 
                        "ret.sd" = sapply(1:dim(data)[3], function(x) sd(as.numeric(ret.sols.df[a3[x,1]:a3[x,2]]), na.rm = TRUE)))
  #create data frame, rows= time, cols = com.mean, com.sd, cons.mean, cons.sd,  
  
  dat.max <- max( c(sols.df$Com.max, sols.df$Cons.max, sols.df$N.com.max, sols.df$N.cons.max, sols.df$N.nur.max, sols.df$N.ret.max, sols.df$ret.max ) )
  
  dat.max <- ceiling_dec(dat.max, level = 2)
  
  p.com <- ggplot(sols.df, aes(x = Time, y = Com.med)) +
    #  geom_line(colour = c("black"), size = 1.5)+ 
    geom_line( colour = c("yellow"), size = 1.5) +      #F0F757
    geom_point( colour = "black") +
    geom_errorbar(aes(ymin = Com.lower.quantile, ymax = Com.upper.quantile , width=.2,
    )) + theme_grey() +  ylim(0,dat.max) + xlab("Time (months)") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete( limits = seq(from = 0, to = max(Time), by =6) ) + 
    ggtitle(label = expression("Com" )) + theme(axis.title.y = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                , axis.text.x = element_text(size = 20, hjust = 1)
                                                , plot.title = element_text(hjust = 0.5, size = 20)
                                                , axis.text=element_text(size=20)
                                                ,legend.text = element_text(size = 20)
                                                ,legend.title = element_text(size = 20) )
  
  
  
  
  
  
  
  p.cons <- ggplot(sols.df, aes(x = Time, y = Cons.med)) +
    #  geom_line(colour = c("black"), size = 1.5)+ 
    geom_line( colour = c("#89043D"), size = 1.5) +
    geom_point( colour = "black") +
    geom_errorbar(aes(ymin = Cons.lower.quantile, ymax = Cons.upper.quantile , width=.2,
    )) + theme_grey() + ylim(0,dat.max) + xlab("Time (months)") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete( limits = seq(from = 0, to = max(Time), by =6) ) + 
    ggtitle(label = expression("Cons" )) + theme(axis.title.y = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                 ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                 , axis.text.x = element_text(size = 20, hjust = 1)
                                                 , plot.title = element_text(hjust = 0.5, size = 20)
                                                 , axis.text=element_text(size=20)
                                                 ,legend.text = element_text(size = 20)
                                                 ,legend.title = element_text(size = 20) )
  
  
  
  p.N.com <- ggplot(sols.df, aes(x = Time, y = N.com.med), colour = c("#228B22")) +
    geom_line(colour = c("#228B22"), size = 1.5) +
    geom_point( colour = "black") +
    geom_errorbar(aes(ymin = N.com.lower.quantile, ymax = N.com.upper.quantile , width=.2,
    )) + theme_grey() +  ylim(0,dat.max) + xlab("Time (months)") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete( limits = seq(from = 0, to = max(Time), by =6) ) + 
    ggtitle(label = expression("N"["Com"] )) + theme(axis.title.y = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                     ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                     , axis.text.x = element_text(size = 20, hjust = 1)
                                                     , plot.title = element_text(hjust = 0.5, size = 20)
                                                     , axis.text=element_text(size=20)
                                                     ,legend.text = element_text(size = 20)
                                                     ,legend.title = element_text(size = 20) )
  
  
  
  
  
  p.N.cons <- ggplot(sols.df, aes(x = Time, y = N.cons.med), colour = c("#DB7093")) +
    geom_line(colour = c("#DB7093"), size = 1.5) +
    geom_point( colour = "black") +
    geom_errorbar(aes(ymin = N.cons.lower.quantile, ymax = N.cons.upper.quantile , width=.2,
    )) + theme_grey() +  ylim(0,dat.max) + xlab("Time (months)") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete( limits = seq(from = 0, to = max(Time), by =6) ) + 
    ggtitle(label = expression("N"["Cons"] )) + theme(axis.title.y = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                      ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                      , axis.text.x = element_text(size = 20, hjust = 1)
                                                      , plot.title = element_text(hjust = 0.5, size = 20)
                                                      , axis.text=element_text(size=20)
                                                      ,legend.text = element_text(size = 20)
                                                      ,legend.title = element_text(size = 20) )
  
  
  
  
  p.N.nur <- ggplot(sols.df, aes(x = Time, y = N.nur.med), colour = c("#00008B")) +
    geom_line(colour = c("#00008B"), size = 1.5) +
    geom_point( colour = "black") +
    geom_errorbar(aes(ymin = N.nur.lower.quantile, ymax = N.nur.upper.quantile , width=.2,
    ))+ theme_grey() +  ylim(0,dat.max) + xlab("Time (months)") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete( limits = seq(from = 0, to = max(Time), by =6) ) + 
    ggtitle(label = expression("N"["Nur"] )) + theme(axis.title.y = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                     ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                     , axis.text.x = element_text(size = 20, hjust = 1)
                                                     , plot.title = element_text(hjust = 0.5, size = 20)
                                                     , axis.text=element_text(size=20)
                                                     ,legend.text = element_text(size = 20)
                                                     ,legend.title = element_text(size = 20) )
  
  
  
  p.N.ret <- ggplot(sols.df, aes(x = Time, y = N.ret.med), colour = c("#0A0908")) +
    geom_line(colour = c("#0A0908"), size = 1.5) +
    geom_point( colour = "black") +
    geom_errorbar(aes(ymin = N.ret.lower.quantile, ymax = N.ret.upper.quantile , width=.2,
    ))+ theme_grey() +  ylim(0,dat.max) + xlab("Time (months)") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete( limits = seq(from = 0, to = max(Time), by =6) ) + 
    ggtitle(label = expression("N"["Ret"] )) + theme(axis.title.y = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                     ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                     , axis.text.x = element_text(size = 20, hjust = 1)
                                                     , plot.title = element_text(hjust = 0.5, size = 20)
                                                     , axis.text=element_text(size=20)
                                                     ,legend.text = element_text(size = 20)
                                                     ,legend.title = element_text(size = 20) )
  
  
  p.ret <- ggplot(sols.df, aes(x = Time, y = ret.med), colour = c("#98D2EB")) +
    geom_line(colour = c("#98D2EB"), size = 1.5) +
    geom_point( colour = "black") +
    geom_errorbar(aes(ymin = ret.lower.quantile, ymax = ret.upper.quantile , width=.2,
    )) + theme_grey() +  ylim(0,dat.max) + xlab("Time (months)") + ylab(expression("Proportion infected")) +
    theme(text = element_text(size=14)) + scale_x_discrete( limits = seq(from = 0, to = max(Time), by =6) ) + 
    ggtitle(label = expression("Ret" )) + theme(axis.title.y = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
                                                ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
                                                , axis.text.x = element_text(size = 20, hjust = 1)
                                                , plot.title = element_text(hjust = 0.5, size = 20)
                                                , axis.text=element_text(size=20)
                                                ,legend.text = element_text(size = 20)
                                                ,legend.title = element_text(size = 20) )
  
  
  
  
  
  layout <- '
ABCD
E###
FG##
'
  
  
  
  # table_label <- function(label, params=list())  {
  #   
  #   params <- modifyList(list(hjust=0, x=0), params)
  #   
  #   mytheme <- theme_minimal(core = list(fg_params = params), parse=TRUE)
  #   disect <- strsplit(label, "\\n")[[1]]
  #   m <- as.matrix(disect)
  #   tableGrob(m, theme=mytheme)
  #   
  # }
  # #need to use unicode for greek letters in tablegrob
  # txt<- '\U03B1 = 0.1, P.g = 0.5, \U03B2 = 0.5,
  #         \n Removal = 0.01,
  #         \n Species = Oak,
  #         \n No. of Nurseries = 160,
  #         \n P. import = 0'
  # 
  # #grid.newpage()
  # 
  # H <- table_label(txt)
  
  
  p10 <- wrap_plots(A = p.N.com, B = p.N.cons, C= p.N.nur, D= p.N.ret,
                    E = p.ret, F = p.com, G=  p.cons, 
                    #H = H,
                    design = layout)
  
  
  
  return(p10)
  
}



p1<- disease.plotting.function(seeding.results.array[1, , , , , ], lower.quantile = 0.25, upper.quantile = 0.75)


p2<- disease.plotting.function(seeding.results.array[2, , , , , ], lower.quantile = 0.25, upper.quantile = 0.75)

p3<-disease.plotting.function(seeding.results.array[3, , , , , ], lower.quantile = 0.25, upper.quantile = 0.75)

p4<-disease.plotting.function(seeding.results.array[4, , , , , ], lower.quantile = 0.25, upper.quantile = 0.75)




ggsave("TimeSeriesForBaselineParams_NcomSeeding_50_perc_int.png", plot = p1, width = 1.25*3600, height  = 0.75 * 3600, units = 'px')

ggsave("TimeSeriesForBaselineParams_NconsSeeding_50_perc_int.png", plot = p2, width = 1.25*3600, height  = 0.75 * 3600, units = 'px')

ggsave("TimeSeriesForBaselineParams_NnurSeeding_50_perc_int.png", plot = p3, width = 1.25*3600, height  = 0.75 * 3600, units = 'px')

ggsave("TimeSeriesForBaselineParams_NretSeeding_50_perc_int.png", plot = p4, width = 1.25*3600, height  = 0.75 * 3600, units = 'px')






# Vary Removal parameter plots


scenario = 3
removal <- seq(0, 1, 0.1)



for (k in 1:length(removal)) {
  
  
  dat <-(get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[1,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[2,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[3,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[4,,,, , ]) /4 
  
  a<-bquote(atop( r == .(removal[k])  )  )
  
  p12 <-  boxplots.function.nurseries(dat, 0.6) +ggtitle("Infected by t=36", a)
  
  assign(paste0("P.",k), p12)
  
  
}


layout <- '
ABCD
EGHI
JKL#

'


p.12 <-   wrap_plots(A = P.1, B = P.2, C= P.3, D= P.4,
                     E = P.5, G = P.6, H = P.7, I = P.8, J = P.9, K = P.10, L = P.11,  design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
#p.12
ggsave(
  filename = paste0("S", scenario, "_Vary_Removal_prop_inf_by_t36_boxplots"  , ".png"),
  device="png",
  width=1.35*3600,
  height=3600,
  units="px",
  plot=p.12, 
  limitsize = TRUE
)






scenario = 3

removal <- seq(0, 1, 0.1)



for (k in 1:length(removal)) {
  
  
  dat <-(get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[1,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[2,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[3,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[4,,,, , ]) /4 
  
  a<-bquote(atop( r == .(removal[k]) )  )
  
  p12 <-  till.twenty.function(dat, min_y_lim = 20) +ggtitle("Time until 20% infected", a)
  
  
  
  assign(paste0("P.",k), p12)
  
  
}


layout <- '
ABCD
EGHI
JKL#
'


p.12 <-  wrap_plots(A = P.1, B = P.2, C= P.3, D= P.4,
                     E = P.5, G = P.6, H = P.7 , I = P.8, J = P.9, K = P.10, L = P.11, design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.12
ggsave(
  filename = paste0("S", scenario, "_Vary_Removal_t_until_20_perc_inf"  , ".png"),
  device="png",
  width=1.25*3600,
  height=3600,
  units="px",
  plot=p.12, 
  limitsize = TRUE
)













till.twenty.lineplot.removal <- function(scenario, lower_quant, upper_quant, lower.y.lim){
  
  removal <-seq(0, 1, 0.1)
  
  sols.df <- data.frame("Removal" = removal) 
  
  sols.df[,2:13 ] = NA
  
  for (j in 2:5) {
    t.prop.inf <- c()
    t.lower.quant <- c()
    t.upper.quant <- c()
    
    for (k in 1:length(removal)) {
      
      dat <-get(load( paste0("S",scenario,paste0("_results_array_Removal_", removal[k],".RData"))))[(j-1),,,, , ]
      
      Total.Nur.Inf <-as.vector(dat[,,,2,3] + dat[,,,2,4] +
                                  dat[,,,2,5] + dat[,,,2,6]) # every 10,000 elements is a time-step
      
      
      Total.Nur.N <-   as.vector(dat[,,,1,3] + dat[,,,2,3] ) +
        as.vector(dat[,,,1,4] + dat[,,,2,4] ) +
        as.vector(dat[,,,1,5] + dat[,,,2,5] ) +
        as.vector(dat[,,,1,6] + dat[,,,2,6] ) 
      
      Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
      Total.Nur.prop.inf = as.data.frame(Total.Nur.prop.inf)
      #2nd column to detail time step
      Total.Nur.prop.inf[,2] = NA
      Total.Nur.prop.inf[,2] <- sort(rep(c(0:36),(dim(dat)[1] * dim(dat)[2])))
      # 3rd column to identify simulation number
      Total.Nur.prop.inf[,3] = NA
      Total.Nur.prop.inf[,3] = rep((1:(dim(dat)[1] * dim(dat)[2])), 37)
      
      # extract where >20% nurseries are infected
      Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2:3]       
      
      t.prop.inf = c(t.prop.inf,
                     median(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])]) )
      
      
      t.lower.quant = c(t.lower.quant,
                        quantile(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])], lower_quant) )
      
      
      t.upper.quant = c(t.upper.quant,
                        quantile(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])], upper_quant) )
      
      
      
      
    }
    
    
    sols.df[,j] = t.prop.inf
    sols.df[,(j + 4) ] = t.lower.quant
    sols.df[,(j + 8) ] = t.upper.quant
    
  }
  
  
  colnames(sols.df) = c("Removal", "N.com", "N.cons", "N.nur", "N.ret" )
  
  sols.df.2 <- data.frame("Removal" = rep(removal, 4), 
                          "Median_Time" = c(sols.df[,2], sols.df[,3], sols.df[,4], sols.df[,5] ), 
                          "LQ_Time" = c(sols.df[,6], sols.df[,7], sols.df[,8], sols.df[,9] ),
                          "UQ_Time" = c(sols.df[,10], sols.df[,11], sols.df[,12], sols.df[,13] ),
                          "Seeding" = c(rep("N.com", length(removal)), rep("N.cons", length(removal)), rep("N.nur", length(removal)), rep("N.ret", length(removal)) ))
  
  
  p1 <- ggplot(sols.df.2, aes(x = Removal, y = Median_Time, group = Seeding )) +
    geom_line(aes(color = Seeding), size = 1) + geom_point(aes(color = Seeding), size = 2) + 
    geom_errorbar(aes(ymin = LQ_Time, ymax = UQ_Time , width=.1, color = Seeding ), size = 1) +
    theme_grey() +  
    scale_x_continuous(expand=c(0,0), breaks = seq(0,1, by = 0.2))+
    scale_y_continuous(expand=c(0,0), breaks = seq(20, 36, by = 2), limits = c(19.99,36.01))+
    xlab(expression(r)) + ylab(expression("Time")) +
    theme(text = element_text(size=14)) + 
    ggtitle(label = paste0("S",scenario,": Time until 20% of nurseries infected" ) ) + 
    theme(plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
      axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(size = 20, hjust = 0.5)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20, hjust = 0)
          ,legend.title = element_text(size = 20) ) +
    
    
    scale_color_manual(values=c("#228b22ff", "#db7093ff", "#00008bff", "black"), 
                       name= "Seeding",
                       breaks= c("N.com","N.cons","N.nur", "N.ret"),
                       labels=c(expression(N[Com]),
                                expression(N[Cons]),
                                expression(N[Nur]),
                                expression(N[Ret])))
  
  return(p1)
}

p1 <- till.twenty.lineplot.removal(1, 0.25, 0.75, lower.y.lim = 20) +
  till.twenty.lineplot.removal(2, 0.25, 0.75, lower.y.lim = 20) +
  till.twenty.lineplot.removal(3, 0.25, 0.75, lower.y.lim = 20) + plot_layout( guides = "collect")
ggsave(
  filename = "Time_till_20_inf_VaryRemoval_S123_50_perc_int.png",
  device="png",
  width=1.5*3600,
  height=0.75*3600,
  units="px",
  plot=p1, 
  limitsize = TRUE
)

prop.inf.by.t36.lineplot.removal <- function(scenario, lower_quant, upper_quant, upper.y.lim){
  
  removal <- seq(0, 1, by = 0.1)
  
  sols.df <- data.frame("Removal" = removal) 
  
  sols.df[,2:13] = NA
  
  
  
  
  
  for (j in 2:5) {
    t.prop.inf <- c()
    t.lower.quant <- c()
    t.upper.quant <- c()
    
    for (k in 1:length(removal)) {
      
      dat <-get(load( paste0("S",scenario,paste0("_results_array_removal_", removal[k],".RData"))))[(j-1),,,, , ]
      
      # com.sols.df <-as.vector(dat[,,37,2,1] /(dat[,,37,1,1] + dat[,,37,2,1] ) )
      #  com.sols.df[1] = 0
      
      # cons.sols.df <- as.vector(dat[,,37,2,2] /(dat[,,37,1,2] + dat[,,37,2,2] ) )
      # cons.sols.df[1] = 0
      
      
      Total.Nur.Inf <-as.vector(dat[,,37,2,3] + dat[,,37,2,4] +
                                  dat[,,37,2,5] + dat[,,37,2,6]) # every 10,000 elements is a time-step
      
      
      Total.Nur.N <-   as.vector(dat[,,37,1,3] + dat[,,37,2,3] ) +
        as.vector(dat[,,37,1,4] + dat[,,37,2,4] ) +
        as.vector(dat[,,37,1,5] + dat[,,37,2,5] ) +
        as.vector(dat[,,37,1,6] + dat[,,37,2,6] ) 
      
      Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
      
      t.prop.inf = c(t.prop.inf, median(Total.Nur.prop.inf)    )
      t.lower.quant = c( t.lower.quant, quantile(Total.Nur.prop.inf, lower_quant)    )
      t.upper.quant = c( t.upper.quant, quantile(Total.Nur.prop.inf, upper_quant)    )
    }
    
    
    sols.df[,j] = t.prop.inf
    sols.df[,(j + 4) ] = t.lower.quant
    sols.df[,(j + 8) ] = t.upper.quant
    
  }
  
  
  colnames(sols.df) = c("Removal", "N.com", "N.cons", "N.nur", "N.ret" )
  
  sols.df.2 <- data.frame("Removal" = rep(removal, 4), 
                          "Proportion" = c(sols.df[,2], sols.df[,3], sols.df[,4], sols.df[,5] ),
                          "LQ_Time" = c(sols.df[,6], sols.df[,7], sols.df[,8], sols.df[,9] ),
                          "UQ_Time" = c(sols.df[,10], sols.df[,11], sols.df[,12], sols.df[,13] ),
                          "Seeding" = c(rep("N.com", length(removal)), rep("N.cons", length(removal)), rep("N.nur", length(removal)), rep("N.ret", length(removal)) ))
  
  
  p1 <- ggplot(sols.df.2, aes(x = Removal, y = Proportion, group = Seeding )) + geom_line(aes(color = Seeding)) + geom_point() +
    geom_errorbar(aes(ymin = LQ_Time, ymax = UQ_Time , width=.1, color = Seeding ), size = 1)+
    theme_grey() + 
    xlab("r") + ylab(expression("Proportion")) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,1, by = 0.2))+
    scale_y_continuous(expand=c(0,0), breaks = seq(0,0.5, by = 0.1), limits = c(-0.01,0.51))+
    theme(text = element_text(size=14)) + 
    ggtitle(label = paste0("S",scenario,": Proportion infected in nurseries by t = 36" ) ) + 
    theme(plot.margin = margin(t = 0, r = 50, b = 0, l = 0, unit = "pt"),
          axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(size = 20, hjust = 0.5)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20, hjust = 0)
          ,legend.title = element_text(size = 20) ) +
    
    
    scale_color_manual(values=c("#228b22ff", "#db7093ff", "#00008bff", "black"), 
                       name= "Seeding",
                       breaks= c("N.com","N.cons","N.nur", "N.ret"),
                       labels=c(expression(N[Com]),
                                expression(N[Cons]),
                                expression(N[Nur]),
                                expression(N[Ret])))
  
  return(p1)
}



p2 <- prop.inf.by.t36.lineplot.removal(1, 0.25, 0.75, upper.y.lim = 0.5 ) +
  prop.inf.by.t36.lineplot.removal(2, 0.25, 0.75, upper.y.lim = 0.5) +
  prop.inf.by.t36.lineplot.removal(3, 0.25, 0.75, upper.y.lim = 0.5)   + plot_layout( guides = "collect")
ggsave(
  filename = "Prop_inf_by_t36_VaryRemoval_S123_50_perc_int.png",
  device="png",
  width=1.75*3600,
  height=0.75*3600,
  units="px",
  plot=p2, 
  limitsize = TRUE
)






# vary alpha in alpha out

scenario = 1
alphas <- seq(0, 0.9, 0.1)



for (k in 1:length(alphas)) {

  dat <-(get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[1,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[2,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[3,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[4,,,, , ]) /4 
  
 a<-bquote(atop( alpha^{out} ==  .(alphas[k]) ~ "," ~
                 alpha^{'in'} ==  .(alphas[k])   )  )
 
 
  p12 <-  boxplots.function.nurseries(dat, 0.6) +ggtitle("Infected by t=36", a)
  
  assign(paste0("P.",k), p12)
  
  
}


layout <- '
ABCD
EGHI
JK##

'


p.12 <-   wrap_plots(A = P.1, B = P.2, C= P.3, D= P.4,
                     E = P.5, G = P.6, H = P.7, I = P.8, J = P.9, K = P.10,  design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.12
ggsave(
  filename = paste0("S", scenario, "_Vary_alpha_in_alpha_out_prop_inf_by_t36_boxplots"  , ".png"),
  device="png",
  width=1.35*3600,
  height=3600,
  units="px",
  plot=p.12, 
  limitsize = TRUE
)






scenario = 3

alphas <- seq(0, 0.9, 0.1)



for (k in 1:length(alphas)) {
  
  
  dat <-(get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[1,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[2,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[3,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[4,,,, , ]) /4 
  
  a<-bquote(atop( alpha^{out} ==  .(alphas[k]) ~ "," ~
                    alpha^{'in'} ==  .(alphas[k])   )  )
  
  p12 <-  till.twenty.function(dat, min_y_lim = 20) +ggtitle("Time until 20% infected", a)
  
  
  
  assign(paste0("P.",k), p12)
  
  
}


layout <- '
ABCD
EGHI
JK##
'


p.12 <-  wrap_plots(A = P.1, B = P.2, C= P.3, D= P.4,
                    E = P.5, G = P.6, H = P.7 , I = P.8, J = P.9, K = P.10, design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.12
ggsave(
  filename = paste0("S", scenario, "_Vary_alpha_in_alpha_out_t_until_20_perc_inf"  , ".png"),
  device="png",
  width=1.25*3600,
  height=3600,
  units="px",
  plot=p.12, 
  limitsize = TRUE
)







till.twenty.lineplot.alpha.in.out <- function(scenario, lower_quant, upper_quant){
  
  alphas <-seq(0, 0.9, 0.1)
  
  sols.df <- data.frame("Alpha" = alphas) 
  
  sols.df[,2:13 ] = NA
  
  for (j in 2:5) {
    t.prop.inf <- c()
    t.lower.quant <- c()
    t.upper.quant <- c()
    
    for (k in 1:length(alphas)) {
      
      dat <-get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[(j-1),,,, , ]
      
      Total.Nur.Inf <-as.vector(dat[,,,2,3] + dat[,,,2,4] +
                                  dat[,,,2,5] + dat[,,,2,6]) # every 10,000 elements is a time-step
      
      
      Total.Nur.N <-   as.vector(dat[,,,1,3] + dat[,,,2,3] ) +
        as.vector(dat[,,,1,4] + dat[,,,2,4] ) +
        as.vector(dat[,,,1,5] + dat[,,,2,5] ) +
        as.vector(dat[,,,1,6] + dat[,,,2,6] ) 
      
      Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
      Total.Nur.prop.inf = as.data.frame(Total.Nur.prop.inf)
      #2nd column to detail time step
      Total.Nur.prop.inf[,2] = NA
      Total.Nur.prop.inf[,2] <- sort(rep(c(0:36),(dim(dat)[1] * dim(dat)[2])))
      # 3rd column to identify simulation number
      Total.Nur.prop.inf[,3] = NA
      Total.Nur.prop.inf[,3] = rep((1:(dim(dat)[1] * dim(dat)[2])), 37)
      
      # extract where >20% nurseries are infected
      Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2:3]       
      
      t.prop.inf = c(t.prop.inf,
                     median(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])]) )
      
      
      t.lower.quant = c(t.lower.quant,
                        quantile(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])], lower_quant) )
      
      
      t.upper.quant = c(t.upper.quant,
                        quantile(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])], upper_quant) )
      
      
      
      
    }
    
    
    sols.df[,j] = t.prop.inf
    sols.df[,(j + 4) ] = t.lower.quant
    sols.df[,(j + 8) ] = t.upper.quant
    
  }
  
  
  colnames(sols.df) = c("Alpha", "N.com", "N.cons", "N.nur", "N.ret" )
  
  sols.df.2 <- data.frame("Alpha" = rep(alphas, 4), 
                          "Median_Time" = c(sols.df[,2], sols.df[,3], sols.df[,4], sols.df[,5] ), 
                          "LQ_Time" = c(sols.df[,6], sols.df[,7], sols.df[,8], sols.df[,9] ),
                          "UQ_Time" = c(sols.df[,10], sols.df[,11], sols.df[,12], sols.df[,13] ),
                          "Seeding" = c(rep("N.com", length(alphas)), rep("N.cons", length(alphas)),
                                        rep("N.nur", length(alphas)), rep("N.ret", length(alphas)) ))
  
  
  p1 <- ggplot(sols.df.2, aes(x = Alpha, y = Median_Time, group = Seeding )) +
    geom_line(aes(color = Seeding), size = 1) + geom_point(aes(color = Seeding), size = 2) + 
    geom_errorbar(aes(ymin = LQ_Time, ymax = UQ_Time , width=.1, color = Seeding ), size = 1) +
    theme_grey() +  ylim(20,36) +
    xlab(bquote(atop( alpha^{out} ==  alpha^{'in'}))) + ylab(expression("Time")) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3))+
    #scale_y_continuous(expand=c(0,0), breaks = seq(20,36, by = 2))+
    theme(text = element_text(size=14)) + 
    ggtitle(label = paste0("S",scenario,": Time until 20% of nurseries infected" ) ) + 
    theme( plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
      axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(size = 20, hjust = 0.5)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20, hjust = 0)
          ,legend.title = element_text(size = 20) ) +
    
    
    scale_color_manual(values=c("#228b22ff", "#db7093ff", "#00008bff", "black"), 
                       name= "Seeding",
                       breaks= c("N.com","N.cons","N.nur", "N.ret"),
                       labels=c(expression(N[Com]),
                                expression(N[Cons]),
                                expression(N[Nur]),
                                expression(N[Ret])))
  
  return(p1)
}

p1 <- till.twenty.lineplot.alpha.in.out(1, 0.25, 0.75) + till.twenty.lineplot.alpha.in.out(2, 0.25, 0.75) +
  till.twenty.lineplot.alpha.in.out(3, 0.25, 0.75)  + plot_layout( guides = "collect")
ggsave(
  filename = "Time_till_20_inf_alpha_in_alpha_out_S123_50_perc_int.png",
  device="png",
  width=1.5*3600,
  height=0.75*3600,
  units="px",
  plot=p1, 
  limitsize = TRUE
)

prop.inf.by.t36.lineplot.alpha.in.out <- function(scenario, lower_quant, upper_quant, upper_y_lim){
  
  alphas <- seq(0, 0.9, by = 0.1)
  
  sols.df <- data.frame("Alpha" = alphas) 
  
  sols.df[,2:13] = NA
  
  
  
  
  
  for (j in 2:5) {
    t.prop.inf <- c()
    t.lower.quant <- c()
    t.upper.quant <- c()
    
    for (k in 1:length(alphas)) {
      
      dat <-get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[(j-1),,,, , ]
      
      # com.sols.df <-as.vector(dat[,,37,2,1] /(dat[,,37,1,1] + dat[,,37,2,1] ) )
      #  com.sols.df[1] = 0
      
      # cons.sols.df <- as.vector(dat[,,37,2,2] /(dat[,,37,1,2] + dat[,,37,2,2] ) )
      # cons.sols.df[1] = 0
      
      
      Total.Nur.Inf <-as.vector(dat[,,37,2,3] + dat[,,37,2,4] +
                                  dat[,,37,2,5] + dat[,,37,2,6]) # every 10,000 elements is a time-step
      
      
      Total.Nur.N <-   as.vector(dat[,,37,1,3] + dat[,,37,2,3] ) +
        as.vector(dat[,,37,1,4] + dat[,,37,2,4] ) +
        as.vector(dat[,,37,1,5] + dat[,,37,2,5] ) +
        as.vector(dat[,,37,1,6] + dat[,,37,2,6] ) 
      
      Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
      
      t.prop.inf = c(t.prop.inf, median(Total.Nur.prop.inf)    )
      t.lower.quant = c( t.lower.quant, quantile(Total.Nur.prop.inf, lower_quant)    )
      t.upper.quant = c( t.upper.quant, quantile(Total.Nur.prop.inf, upper_quant)    )
    }
    
    
    sols.df[,j] = t.prop.inf
    sols.df[,(j + 4) ] = t.lower.quant
    sols.df[,(j + 8) ] = t.upper.quant
    
  }
  
  
  colnames(sols.df) = c("Alpha", "N.com", "N.cons", "N.nur", "N.ret" )
  
  sols.df.2 <- data.frame("Alpha" = rep(alphas, 4), 
                          "Proportion" = c(sols.df[,2], sols.df[,3], sols.df[,4], sols.df[,5] ),
                          "LQ_Time" = c(sols.df[,6], sols.df[,7], sols.df[,8], sols.df[,9] ),
                          "UQ_Time" = c(sols.df[,10], sols.df[,11], sols.df[,12], sols.df[,13] ),
                          "Seeding" = c(rep("N.com", length(alphas)), rep("N.cons", length(alphas)), rep("N.nur", length(alphas)), rep("N.ret", length(alphas)) ))
  
  
  p1 <- ggplot(sols.df.2, aes(x = Alpha, y = Proportion, group = Seeding )) + geom_line(aes(color = Seeding)) + geom_point() +
    geom_errorbar(aes(ymin = LQ_Time, ymax = UQ_Time , width=.1, color = Seeding ), size = 1)+
    theme_grey() +  ylim(0,upper_y_lim) +
    xlab(bquote(atop( alpha^{out} ==  alpha^{'in'}))) + ylab(expression("Proportion")) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3))+
    theme(text = element_text(size=14)) + 
    ggtitle(label = paste0("S",scenario,": Proportion infected in nurseries by t = 36" ) ) + 
    theme(plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
      axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(size = 20, hjust = 0.5)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20, hjust = 0)
          ,legend.title = element_text(size = 20) ) +
    
    
    scale_color_manual(values=c("#228b22ff", "#db7093ff", "#00008bff", "black"), 
                       name= "Seeding",
                       breaks= c("N.com","N.cons","N.nur", "N.ret"),
                       labels=c(expression(N[Com]),
                                expression(N[Cons]),
                                expression(N[Nur]),
                                expression(N[Ret])))
  
  return(p1)
}



p2 <- prop.inf.by.t36.lineplot.alpha.in.out(1, 0.25, 0.75, upper_y_lim = 0.5) +
  prop.inf.by.t36.lineplot.alpha.in.out(2, 0.25, 0.75, upper_y_lim = 0.5) +
  prop.inf.by.t36.lineplot.alpha.in.out(3, 0.25, 0.75, upper_y_lim = 0.5) + plot_layout( guides = "collect")
ggsave(
  filename = "Prop_inf_by_t36_alpha_in_out_S123_50_perc_int.png",
  device="png",
  width=1.75*3600,
  height=0.75*3600,
  units="px",
  plot=p2, 
  limitsize = TRUE
)









#vary alpha out only 

scenario = 1
alphas <- seq(0, 0.9, 0.1)



for (k in 1:length(alphas)) {
  
  
  if(k==1){
    
    dat <-(get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[1,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[2,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[3,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[4,,,, , ]) /4 
    
    
    
    
  }
  
  if(k >1){
  
  dat <-(get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[1,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[2,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[3,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[4,,,, , ]) /4 
  
  }
  
  a<-bquote(atop( alpha^{"out"} == .(alphas[k])  )  )
  
  p12 <-  boxplots.function.nurseries(dat, 0.6) +ggtitle("Infected by t=36", a)
  
  assign(paste0("P.",k), p12)
  
  
}


layout <- '
ABCD
EGHI
JK##

'


p.12 <-   wrap_plots(A = P.1, B = P.2, C= P.3, D= P.4,
                     E = P.5, G = P.6, H = P.7, I = P.8, J = P.9, K = P.10,  design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.12
ggsave(
  filename = paste0("S", scenario, "_Vary_alpha_out_prop_inf_by_t36_boxplots"  , ".png"),
  device="png",
  width=1.35*3600,
  height=3600,
  units="px",
  plot=p.12, 
  limitsize = TRUE
)




scenario = 1

alphas <- seq(0, 0.9, 0.1)



for (k in 1:length(alphas)) {
  
  if(k==1){
    
    dat <-(get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[1,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[2,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[3,,,, , ] +
             
             get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[4,,,, , ]) /4 
    
  }
  
  if(k >1){
    
  
  dat <-(get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[1,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[2,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[3,,,, , ] +
           
           get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[4,,,, , ]) /4 
  
  
  }
  
  a<-bquote(atop( alpha^{out} ==  .(alphas[k]) )  )
  
  p12 <-  till.twenty.function(dat, min_y_lim = 20) +ggtitle("Time until 20% infected", a)
  
  
  
  assign(paste0("P.",k), p12)
  
  
}


layout <- '
ABCD
EGHI
JK##
'


p.12 <-  wrap_plots(A = P.1, B = P.2, C= P.3, D= P.4,
                    E = P.5, G = P.6, H = P.7 , I = P.8, J = P.9, K = P.10, design = layout) + 
  plot_annotation(title = expression("" ), theme = theme(plot.title = element_text(hjust = 0.5)))
p.12
ggsave(
  filename = paste0("S", scenario, "_Vary_alpha_out_t_until_20_perc_inf"  , ".png"),
  device="png",
  width=1.25*3600,
  height=3600,
  units="px",
  plot=p.12, 
  limitsize = TRUE
)




till.twenty.lineplot.alpha.out <- function(scenario, lower_quant, upper_quant, lower_y_lim){
  
  alphas <-seq(0, 0.9, 0.1)
  
  sols.df <- data.frame("Alpha" = alphas) 
  
  sols.df[,2:13 ] = NA
  
  for (j in 2:5) {
    t.prop.inf <- c()
    t.lower.quant <- c()
    t.upper.quant <- c()
    
    for (k in 1:length(alphas)) {
      
      
      
      if(k==1){
        
        dat <-get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[(j-1),,,, , ]
        
      }
      
      if(k >1){
        
        dat <-get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[(j-1),,,, , ]  
      }
     
      
      
      
      Total.Nur.Inf <-as.vector(dat[,,,2,3] + dat[,,,2,4] +
                                  dat[,,,2,5] + dat[,,,2,6]) # every 10,000 elements is a time-step
      
      
      Total.Nur.N <-   as.vector(dat[,,,1,3] + dat[,,,2,3] ) +
        as.vector(dat[,,,1,4] + dat[,,,2,4] ) +
        as.vector(dat[,,,1,5] + dat[,,,2,5] ) +
        as.vector(dat[,,,1,6] + dat[,,,2,6] ) 
      
      Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
      Total.Nur.prop.inf = as.data.frame(Total.Nur.prop.inf)
      #2nd column to detail time step
      Total.Nur.prop.inf[,2] = NA
      Total.Nur.prop.inf[,2] <- sort(rep(c(0:36),(dim(dat)[1] * dim(dat)[2])))
      # 3rd column to identify simulation number
      Total.Nur.prop.inf[,3] = NA
      Total.Nur.prop.inf[,3] = rep((1:(dim(dat)[1] * dim(dat)[2])), 37)
      
      # extract where >20% nurseries are infected
      Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2:3]       
      
      t.prop.inf = c(t.prop.inf,
                     median(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])]) )
      
      
      t.lower.quant = c(t.lower.quant,
                        quantile(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])], lower_quant) )
      
      
      t.upper.quant = c(t.upper.quant,
                        quantile(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])], upper_quant) )
      
      
      
      
    }
    
    
    sols.df[,j] = t.prop.inf
    sols.df[,(j + 4) ] = t.lower.quant
    sols.df[,(j + 8) ] = t.upper.quant
    
  }
  
  
  colnames(sols.df) = c("Alpha", "N.com", "N.cons", "N.nur", "N.ret" )
  
  sols.df.2 <- data.frame("Alpha" = rep(alphas, 4), 
                          "Median_Time" = c(sols.df[,2], sols.df[,3], sols.df[,4], sols.df[,5] ), 
                          "LQ_Time" = c(sols.df[,6], sols.df[,7], sols.df[,8], sols.df[,9] ),
                          "UQ_Time" = c(sols.df[,10], sols.df[,11], sols.df[,12], sols.df[,13] ),
                          "Seeding" = c(rep("N.com", length(alphas)), rep("N.cons", length(alphas)),
                                        rep("N.nur", length(alphas)), rep("N.ret", length(alphas)) ))
  
  
  p1 <- ggplot(sols.df.2, aes(x = Alpha, y = Median_Time, group = Seeding )) +
    geom_line(aes(color = Seeding), size = 1) + geom_point(aes(color = Seeding), size = 2) + 
    geom_errorbar(aes(ymin = LQ_Time, ymax = UQ_Time , width=.1, color = Seeding ), size = 1) +
    theme_grey() +  ylim(lower_y_lim,36) +
    xlab(expression(alpha^{out})) + ylab(expression("Time")) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3))+
    theme(text = element_text(size=14)) + 
    ggtitle(label = paste0("S",scenario,": Time until 20% of nurseries infected" ) ) + 
    theme(plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
      axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(size = 20, hjust = 0.5)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20, hjust = 0)
          ,legend.title = element_text(size = 20) ) +
    
    
    scale_color_manual(values=c("#228b22ff", "#db7093ff", "#00008bff", "black"), 
                       name= "Seeding",
                       breaks= c("N.com","N.cons","N.nur", "N.ret"),
                       labels=c(expression(N[Com]),
                                expression(N[Cons]),
                                expression(N[Nur]),
                                expression(N[Ret])))
  
  return(p1)
}

p1 <- till.twenty.lineplot.alpha.out(1, 0.25, 0.75, lower_y_lim =  20) + till.twenty.lineplot.alpha.out(2, 0.25, 0.75, lower_y_lim =  20) +
  till.twenty.lineplot.alpha.out(3, 0.25, 0.75, lower_y_lim =  20)+ plot_layout( guides = "collect")
ggsave(
  filename = "Time_till_20_inf_alpha_out_S123_50_perc_int.png",
  device="png",
  width=1.5*3600,
  height=0.75*3600,
  units="px",
  plot=p1, 
  limitsize = TRUE
)

prop.inf.by.t36.lineplot.alpha.out <- function(scenario, lower_quant, upper_quant, upper_y_lim){
  
  alphas <- seq(0, 0.9, by = 0.1)
  
  sols.df <- data.frame("Alpha" = alphas) 
  
  sols.df[,2:13] = NA
  
  
  
  
  
  for (j in 2:5) {
    t.prop.inf <- c()
    t.lower.quant <- c()
    t.upper.quant <- c()
    
    for (k in 1:length(alphas)) {
      
      if(k==1){
        
        dat <-get(load( paste0("S",scenario,paste0("_results_array_alpha_in_alpha_out_", alphas[k],".RData"))))[(j-1),,,, , ]
        
      }
      
      if(k >1){
        
        dat <-get(load( paste0("S",scenario,paste0("_results_array_alpha_out_", alphas[k],".RData"))))[(j-1),,,, , ]  
      }
      
      # com.sols.df <-as.vector(dat[,,37,2,1] /(dat[,,37,1,1] + dat[,,37,2,1] ) )
      #  com.sols.df[1] = 0
      
      # cons.sols.df <- as.vector(dat[,,37,2,2] /(dat[,,37,1,2] + dat[,,37,2,2] ) )
      # cons.sols.df[1] = 0
      
      
      Total.Nur.Inf <-as.vector(dat[,,37,2,3] + dat[,,37,2,4] +
                                  dat[,,37,2,5] + dat[,,37,2,6]) # every 10,000 elements is a time-step
      
      
      Total.Nur.N <-   as.vector(dat[,,37,1,3] + dat[,,37,2,3] ) +
        as.vector(dat[,,37,1,4] + dat[,,37,2,4] ) +
        as.vector(dat[,,37,1,5] + dat[,,37,2,5] ) +
        as.vector(dat[,,37,1,6] + dat[,,37,2,6] ) 
      
      Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
      
      t.prop.inf = c(t.prop.inf, median(Total.Nur.prop.inf)    )
      t.lower.quant = c( t.lower.quant, quantile(Total.Nur.prop.inf, lower_quant)    )
      t.upper.quant = c( t.upper.quant, quantile(Total.Nur.prop.inf, upper_quant)    )
    }
    
    
    sols.df[,j] = t.prop.inf
    sols.df[,(j + 4) ] = t.lower.quant
    sols.df[,(j + 8) ] = t.upper.quant
    
  }
  
  
  colnames(sols.df) = c("Alpha", "N.com", "N.cons", "N.nur", "N.ret" )
  
  sols.df.2 <- data.frame("Alpha" = rep(alphas, 4), 
                          "Proportion" = c(sols.df[,2], sols.df[,3], sols.df[,4], sols.df[,5] ),
                          "LQ_Time" = c(sols.df[,6], sols.df[,7], sols.df[,8], sols.df[,9] ),
                          "UQ_Time" = c(sols.df[,10], sols.df[,11], sols.df[,12], sols.df[,13] ),
                          "Seeding" = c(rep("N.com", length(alphas)), rep("N.cons", length(alphas)), rep("N.nur", length(alphas)), rep("N.ret", length(alphas)) ))
  
  
  p1 <- ggplot(sols.df.2, aes(x = Alpha, y = Proportion, group = Seeding )) + geom_line(aes(color = Seeding)) + geom_point() +
    geom_errorbar(aes(ymin = LQ_Time, ymax = UQ_Time , width=.1, color = Seeding ), size = 1)+
    theme_grey() +  ylim(0,upper_y_lim) +
    xlab(expression(alpha^{out})) + ylab(expression("Proportion")) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3))+
    theme(plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
      text = element_text(size=14)) + 
    ggtitle(label = paste0("S",scenario,": Proportion infected in nurseries by t = 36" ) ) + 
    theme(axis.title.y.left = element_text( size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(size = 20, hjust = 0.5)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20, hjust = 0)
          ,legend.title = element_text(size = 20) ) +
    
    
    scale_color_manual(values=c("#228b22ff", "#db7093ff", "#00008bff", "black"), 
                       name= "Seeding",
                       breaks= c("N.com","N.cons","N.nur", "N.ret"),
                       labels=c(expression(N[Com]),
                                expression(N[Cons]),
                                expression(N[Nur]),
                                expression(N[Ret])))
  
  return(p1)
}



p2 <- prop.inf.by.t36.lineplot.alpha.out(1, 0.25, 0.75, upper_y_lim = 0.5) +
  prop.inf.by.t36.lineplot.alpha.out(2, 0.25, 0.75, upper_y_lim = 0.5) +
  prop.inf.by.t36.lineplot.alpha.out(3, 0.25, 0.75, upper_y_lim = 0.5)+ plot_layout( guides = "collect")
ggsave(
  filename = "Prop_inf_by_t36_alpha_out_S123_50_perc_int.png",
  device="png",
  width=1.75*3600,
  height=0.75*3600,
  units="px",
  plot=p2, 
  limitsize = TRUE
)











