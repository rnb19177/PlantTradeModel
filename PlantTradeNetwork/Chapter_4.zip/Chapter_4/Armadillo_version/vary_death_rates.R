#
source("R_functions_For_Armadillo_Version.R")
# rounded to 1 s.f for simplicity
#            6month, 1yr ,10yrs, 100yrs
A_matrix_list <- list()

for (i in 1:100) {
  
  A_matrix_list[[i]] = netgen.for.SI(node.list, oak.distribution.list)
  
}






ncores <- 10

# looking at "sales period" of 1 month, 6 months, 1 year, indefinite 
# sales period refers to susceptible death rate for  nurseries and retailers
# set customer deaths to 0. Looks like I can just add in the death rates afterward
#1 - (1 - 0.999999)^(1/6)

# sales periods of a month, 6 months, a year, indefinite
death.S <-  c(1, 0.9,   0.7,  0)
death.I <-  c(0.9,   0.7,  0)

combinations <- expand.grid(death.S,death.I)


combinations = combinations[combinations$Var1 >= combinations$Var2,]

names(combinations) = c("D.I", "D.S")

node.list <-  list(ncom = 40, ncons = 40, nnur = 40, nret = 40, Ret = 160*10)

oak.distribution.list <- list(out.deg.mean = 380*(160/630), out.deg.dispersal = (160/630)*(380)^2/(114587*(160/630) - 380),
                              commercial.mean = 79*(160/630) , commercial.sd = 297*(160/630),
                              consumer.mean = 185*(160/630), consumer.sd = 822*(160/630),
                              nursery.mean = 1844*(160/630) , nursery.sd = 3567*(160/630),
                              retailer.mean = 3497*(160/630), retailer.sd = 9588*(160/630) )

param_vector_2 <-c(
  2 , # beta_n
  2 , # beta_r
  0.7, # death_s
  1 , # death_i
  0, # customer_death_S
  0, # customer_death_I
  36, # total_time
  40, # ncom
  40, # ncons
  40, # nnur
  40, # nret
  1 # seeding
)

param_list <- list("node.list" = node.list, "distribution.list" = oak.distribution.list,
                   "param_vec" = param_vector_2)



a <- getwd()

#Nursery comp 1
setwd(paste0(a,"/Nursery_comp_1/Vary_Death_Rates"))
seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
#vary death rates
for (j in 1:nrow(combinations)) {
  seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
  param_list$param_vec[4] = combinations$D.S[j]
  param_list$param_vec[5] = combinations$D.I[j]

param_list$param_vec[13] = 1

seeding.results.array[1, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))

param_list$param_vec[13] = 2
seeding.results.array[2, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))


param_list$param_vec[13] = 3
seeding.results.array[3, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))


param_list$param_vec[13] = 4
seeding.results.array[4, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))

save('seeding.results.array', file = paste0("S1_results_array_Di_",combinations$D.I[j],"_Ds_",combinations$D.S[j],".RData"))
#rm(seeding.results.array)

}









#Nursery comp 2
#setwd(paste0(a,"/Nursery_comp_2/Vary_Death_Rates"))
param_list$node.list = list(ncom = 80, ncons = 20, nnur = 40, nret = 20, Ret = 160*10)
param_list$param_vec[9:12] = c(80, 20,  40, 20)


rm(A_matrix_list)
A_matrix_list <- list()

for (i in 1:100) {
  
  A_matrix_list[[i]] = netgen.for.SI(param_list$node.list, param_list$distribution.list)
  
}



seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
#vary death rates
for (j in 1:nrow(combinations)) {
  seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
  param_list$param_vec[4] = combinations$D.S[j]
  param_list$param_vec[5] = combinations$D.I[j]

  param_list$param_vec[13] = 1
  
  seeding.results.array[1, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))
  
  param_list$param_vec[13] = 2
  seeding.results.array[2, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))
  
  
  param_list$param_vec[13] = 3
  seeding.results.array[3, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))
  
  
  param_list$param_vec[13] = 4
  seeding.results.array[4, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))

  save('seeding.results.array', file = paste0("S2_results_array_Di_",combinations$D.I[j],"_Ds_",combinations$D.S[j],".RData"))
#  rm(seeding.results.array)

}


#Nursery comp 3
#setwd(paste0(a,"/Nursery_comp_3/Vary_Death_Rates"))
param_list$node.list = list(ncom = 20, ncons = 50, nnur = 40, nret = 50, Ret = 160*10)

param_list$param_vec[9:12] = c(20, 50,  40, 50)




rm(A_matrix_list)
A_matrix_list <- list()

for (i in 1:100) {
  
  A_matrix_list[[i]] = netgen.for.SI(param_list$node.list, param_list$distribution.list)
  
}



seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
#vary death rates
for (j in 1:nrow(combinations)) {
  seeding.results.array <- array(NA, dim = c(4, 100, 100, 37, 2, 7 ))
  param_list$param_vec[4] = combinations$D.S[j]
  param_list$param_vec[5] = combinations$D.I[j]
  
  param_list$param_vec[13] = 1
  
  seeding.results.array[1, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))
  
  param_list$param_vec[13] = 2
  seeding.results.array[2, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))
  
  
  param_list$param_vec[13] = 3
  seeding.results.array[3, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))
  
  
  param_list$param_vec[13] = 4
  seeding.results.array[4, , , , , ] <- results_to_array_fun(DN_hundred_networks(A_matrix_list, param_list$param_vec, 100,100))
  
  save('seeding.results.array', file = paste0("S3_results_array_Di_",combinations$D.I[j],"_Ds_",combinations$D.S[j],".RData"))
 # rm(seeding.results.array)
  
}



