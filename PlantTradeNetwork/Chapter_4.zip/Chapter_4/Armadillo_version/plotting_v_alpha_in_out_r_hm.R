# plotting vary alpha in and out and removal heatmap
library(patchwork)
library(gridExtra)
library(grid)
library(ggplot2)
library(metR)
library(viridis)
# vary alpha_in_out_removal heatmap
setwd("C:/Users/matth/OneDrive - University of Strathclyde/PhD Stuff/RStudioStuff/Rstudio/Final data work/Static spread/Armadillo_version/Data/Alpha_in_out_removal")

alpha_outs <- seq(0,0.9,0.1)
removals <- seq(0,1,0.1)

combinations <- expand.grid(alpha_outs, removals)




prep.data.fun <- function(combinations){
  
  
  data <- combinations
  
  # 3rd column for median time until 20% infected: for each seeding
  data[,3:6] = NA
  
  
  #4th column for median prop. nurseries infected by t=36 : for each seeding
  data[,7:10] = NA
  
  
  
  
  for (j in 1:nrow(combinations)) {

  
  dat <- get(load(paste0(paste0("S1_alpha_in_alpha_out", combinations[j,1], "_removal", combinations[j,2] ), ".RData")))
  
   
  # calculate median time until 20% infected
  
  
  for (j2 in 1:4) {
    
  
  mini.dat <- dat[j2, , , , , ]
  
  Total.Nur.Inf <-as.vector(mini.dat[,,,2,3] + mini.dat[,,,2,4] +
                              mini.dat[,,,2,5] + mini.dat[,,,2,6]) # every 10,000 elements is a time-step
  
  Total.Nur.N <-   as.vector(mini.dat[,,,1,3] + mini.dat[,,,2,3] ) +
    as.vector(mini.dat[,,,1,4] + mini.dat[,,,2,4] ) +
    as.vector(mini.dat[,,,1,5] + mini.dat[,,,2,5] ) +
    as.vector(mini.dat[,,,1,6] + mini.dat[,,,2,6] ) 
  
  
  Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
  Total.Nur.prop.inf = as.data.frame(Total.Nur.prop.inf)
  #2nd column to detail time step
  Total.Nur.prop.inf[,2] = NA
  Total.Nur.prop.inf[,2] <- sort(rep(c(0:36),(dim(mini.dat)[1] * dim(mini.dat)[2])))
  # 3rd column to identify simulation number
  Total.Nur.prop.inf[,3] = NA
  Total.Nur.prop.inf[,3] = rep((1:(dim(mini.dat)[1] * dim(mini.dat)[2])), 37)
  
  # extract where >20% nurseries are infected
  #Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2:3]       
  
  # problem is that this also includes further time-points
  # we only want the first occurrence of >20% nurseries are infected per sim.
  
  #returns earliest time-steps where >20% nurseries are infected
  #Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])]
 data[j,j2+2] = median(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])])
  
 
 
 
 
 
 # proportion infected in nurseries by t=36
 
 Total.Nur.Inf <-as.vector(mini.dat[,,37,2,3] + mini.dat[,,37,2,4] +
                             mini.dat[,,37,2,5] + mini.dat[,,37,2,6]) # every 10,000 elements is a time-step
 
 
 Total.Nur.N <-   as.vector(mini.dat[,,37,1,3] + mini.dat[,,37,2,3] ) +
   as.vector(mini.dat[,,37,1,4] + mini.dat[,,37,2,4] ) +
   as.vector(mini.dat[,,37,1,5] + mini.dat[,,37,2,5] ) +
   as.vector(mini.dat[,,37,1,6] + mini.dat[,,37,2,6] ) 
 
 data[j, j2+6] = median(  Total.Nur.Inf/Total.Nur.N)
 
 
 
 
 
 
  }  
  
  
  }
  
  return(data)
}




data <- prep.data.fun(combinations)



heatmap.fun <- function(data, legend_name, x_label, y_label, min.lim,  max.lim){
  
  
#  x_label <-x_label
#  y_label <-y_label
  
  # the_plot below is a contour plot with 20 bins
 # binz <- bins
  
  
#  pal <- viridis(20, option = "A")
  
  # visualise pallete:
  # show_col(pal)
  
  # scale_fill_fermenter_custom <- function(pal, na.value = "grey50", guide = "coloursteps", aesthetics = "fill", ...) {
  #   binned_scale("fill", "fermenter", ggplot2:::binned_pal(scales::manual_pal(unname(pal))), na.value = na.value
  #                #,n.breaks = 10
  #               # ,breaks = seq(min.lim, max.lim, length.out = 10)
  #               # ,limits = c(min.lim, max.lim)
  #                ,guide = guide, ...)
  # }
  
  
  the_plot_1 <- ggplot(data, aes(data[,1],data[,2], z = data[,3]))  +
    # geom_contour_fill(bins = 20) +
    geom_contour_fill() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Com],  " seeding")'))
         ,subtitle = ""
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
 #   scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0,1, by = 0.2)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw() +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1,
                                           margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"))
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 20, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = -90)
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE, 
      even.steps = FALSE,
      frame.linewidth = 0.55, 
      frame.colour = "black", 
      ticks.colour = "black",
      barheight = 25,
      ticks.linewidth = 0.3
      , title.position = "right"))
  
  
  
  
  
  
  
  the_plot_2 <- ggplot(data, aes(data[,1],data[,2], z = data[,4]))  +
   #  geom_contour_fill(bins = 20) +
    geom_contour_fill() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Cons],  " seeding")'))
         ,subtitle = ""
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
#    scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0,1, by = 0.2)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw() +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = -90)
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE, 
      even.steps = FALSE,
      frame.linewidth = 0.55, 
      frame.colour = "black", 
      ticks.colour = "black",
      barheight = 25,
      ticks.linewidth = 0.3
      , title.position = "right"))
  
  the_plot_3 <- ggplot(data, aes(data[,1],data[,2], z = data[,5]))  +
   #  geom_contour_fill(bins = 20) +
   geom_contour_fill() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Nur],  " seeding")'))
         ,subtitle = ""
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
 #   scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0,1, by = 0.2)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw() +
    theme( plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
      panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1 )
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 20, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = -90)
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE, 
      even.steps = FALSE,
      frame.linewidth = 0.55, 
      frame.colour = "black", 
      ticks.colour = "black",
      barheight = 25,
      ticks.linewidth = 0.3
      , title.position = "right"))
  
  
  
  the_plot_4 <- ggplot(data, aes(data[,1],data[,2], z = data[,6]))  +
   #  geom_contour_fill(bins = 20) +
    geom_contour_fill() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Ret],  " seeding")'))
         ,subtitle = ""
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
#  scale_x_continuous(expand=c(0,0)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0,1, by = 0.2)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw() +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = -90) 
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE, 
      even.steps = FALSE,
      frame.linewidth = 0.55, 
      frame.colour = "black", 
      ticks.colour = "black",
      barheight = 25,
      ticks.linewidth = 0.3
      , title.position = "right"))
  
  
  layout <- '
AB
CD
'
  
  
  the_plot <-  wrap_plots(A = the_plot_1, B = the_plot_2, C= the_plot_3, D = the_plot_4,  design = layout) + plot_layout( guides = "collect")
  #the_plot <- the_plot_1 + the_plot_2 + the_plot_3 + the_plot_4
  
  
  return(the_plot)
}  









x_label <- bquote(atop( alpha^{out} ==  alpha^{'in'}))
y_label <- "r"
legend_name <- "Time until 20% of nurseries are infected"
#legend_name <-""

min(c(dat[,3], dat[,4], dat[,5], dat[,6] ), na.rm = TRUE)
min.lim <- 25
max(c(dat[,3], dat[,4], dat[,5], dat[,6] ), na.rm = TRUE)
max.lim <- 36

p.10 <- heatmap.fun(dat, legend_name, x_label, y_label, min.lim, max.lim )


ggsave(
  filename = "Time_till_20_v_a_in_out_r_heatmap.png",
  device="png",
  width= 1.25*3600,
  height=3600,
  units="px",
  plot=p.10, 
  limitsize = TRUE
)



legend_name <- "Proportion infected by t = 36"
#legend_name <-""

min(as.vector(dat[,7:10]), na.rm = TRUE)
min.lim <- 0
max(as.vector(dat[,7:10]), na.rm = TRUE)
max.lim <- 0.5
dat2<- dat[,c(1, 2, 7,8,9,10)]
p.11 <- heatmap.fun(dat2, legend_name, x_label, y_label, min.lim,max.lim)

ggsave(
  filename = "prop_inf_t_36_v_a_in_out_r_heatmap.png",
  device="png",
  width= 1.25*3600,
  height=3600,
  units="px",
  plot=p.11, 
  limitsize = TRUE
)




