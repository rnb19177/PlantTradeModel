# plotting vary alpha in and out and removal heatmap
library(patchwork)
library(gridExtra)
library(grid)
library(ggplot2)
library(metR)
library(viridis)
# vary alpha_in_out_removal heatmap

alpha_outs <- seq(0,0.9,0.1)
removals <- seq(0,1,0.1)

combinations <- expand.grid(alpha_outs, removals)

names(combinations) = c("alpha_out", "removal")

#combinations = combinations[-which(combinations$alpha_out == 0),]
#combinations = combinations[-which(combinations$removal == 0),]

frequencies <- c(1, 3, 6)
#frequencies <- frequencies[1:5] # already done 6

rem_starts <- c(1, 3) # timing of the first scheduled inspection 


combs2 <- expand.grid(frequencies, rem_starts)

combs2 = combs2[ combs2[,2] <= combs2[,1]   , ]




prep.data.fun <- function(combinations, row){
  
  
  data <- combinations
  
  # 3rd column for median time until 20% infected: for each seeding
  data[,3:6] = NA
  
  
  #4th column for median prop. nurseries infected by t=36 : for each seeding
  data[,7:10] = NA
  
  
  
  
  for (j in 1:nrow(combinations)) {
    
    
    if(j <11){
      dat <- get(load(paste0("S1_alpha_in_alpha_out", combinations[j,1], "_removal", combinations[j,2],".RData")))
    }
    else{

      
      dat <- get(load(paste0("row_", row, "/a_in_out", combinations[j,1], "_removal", combinations[j,2],
                           "insp_freq", combs2[row,1], "rem_start",combs2[row,2], ".RData")))
      }
    
    # calculate median time until 20% infected
    
    
    for (j2 in 1:4) {
      
      
      mini.dat <- dat[j2, , , , , ]
      
      Total.Nur.Inf <-as.vector(mini.dat[,,,2,3] + mini.dat[,,,2,4] +
                                  mini.dat[,,,2,5] + mini.dat[,,,2,6]) # every 10,000 elements is a time-step
      
      Total.Nur.N <-   as.vector(mini.dat[,,,1,3] + mini.dat[,,,2,3] ) +
        as.vector(mini.dat[,,,1,4] + mini.dat[,,,2,4] ) +
        as.vector(mini.dat[,,,1,5] + mini.dat[,,,2,5] ) +
        as.vector(mini.dat[,,,1,6] + mini.dat[,,,2,6] ) 
      
      
      Total.Nur.prop.inf <-    Total.Nur.Inf/Total.Nur.N
      Total.Nur.prop.inf = as.data.frame(Total.Nur.prop.inf)
      #2nd column to detail time step
      Total.Nur.prop.inf[,2] = NA
      Total.Nur.prop.inf[,2] <- sort(rep(c(0:36),(dim(mini.dat)[1] * dim(mini.dat)[2])))
      # 3rd column to identify simulation number
      Total.Nur.prop.inf[,3] = NA
      Total.Nur.prop.inf[,3] = rep((1:(dim(mini.dat)[1] * dim(mini.dat)[2])), 37)
      
      # extract where >20% nurseries are infected
      #Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2:3]       
      
      # problem is that this also includes further time-points
      # we only want the first occurrence of >20% nurseries are infected per sim.
      
      #returns earliest time-steps where >20% nurseries are infected
      #Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])]
      data[j,j2+2] = median(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),2][!duplicated(Total.Nur.prop.inf[which(Total.Nur.prop.inf[,1] > 0.2),3])])
      
      
      
      
      
      
      # proportion infected in nurseries by t=36
      
      Total.Nur.Inf <-as.vector(mini.dat[,,37,2,3] + mini.dat[,,37,2,4] +
                                  mini.dat[,,37,2,5] + mini.dat[,,37,2,6]) # every 10,000 elements is a time-step
      
      
      Total.Nur.N <-   as.vector(mini.dat[,,37,1,3] + mini.dat[,,37,2,3] ) +
        as.vector(mini.dat[,,37,1,4] + mini.dat[,,37,2,4] ) +
        as.vector(mini.dat[,,37,1,5] + mini.dat[,,37,2,5] ) +
        as.vector(mini.dat[,,37,1,6] + mini.dat[,,37,2,6] ) 
      
      data[j, j2+6] = median(  Total.Nur.Inf/Total.Nur.N)
      
      
      
      
      
      
    }  
    
    
  }
  
  return(data)
}




prep.data.fun.2 <- function(combinations, row){
  
  
  data <- combinations
  
  # 3rd column for median total infected across all timepoints: for each seeding
  data[,3:6] = NA
  
 
  for (j in 1:nrow(combinations)) {
    
    
    if(j <11){
      dat <- get(load(paste0("S1_alpha_in_alpha_out", combinations[j,1], "_removal", combinations[j,2],".RData")))
    }
    else{
      
      
      dat <- get(load(paste0("row_", row, "/a_in_out", combinations[j,1], "_removal", combinations[j,2],
                             "insp_freq", combs2[row,1], "rem_start",combs2[row,2], ".RData")))
    }
    
    # calculate median time until 20% infected
    
    
    for (j2 in 1:4) {
      
      
      mini.dat <- dat[j2, , , ,2 , ]
    
      # summing over all time-steps  
      data[j,j2+2] = median (as.vector((rowSums(mini.dat[,,,3], dims = 2)) + 
                           (rowSums(mini.dat[,,,3], dims = 2)) + 
                           (rowSums(mini.dat[,,,5], dims = 2)) + 
                           (rowSums(mini.dat[,,,6], dims = 2))))
  
      
      
    }  
    
    
  }
  
  return(data)
}




heatmap.fun <- function(data, legend_name, x_label, y_label, min.lim,  max.lim, row){
  
  
  #  x_label <-x_label
  #  y_label <-y_label
  
  # the_plot below is a contour plot with 20 bins
  # binz <- bins
  
  
  #  pal <- viridis(20, option = "A")
  
  # visualise pallete:
  # show_col(pal)
  
  # scale_fill_fermenter_custom <- function(pal, na.value = "grey50", guide = "coloursteps", aesthetics = "fill", ...) {
  #   binned_scale("fill", "fermenter", ggplot2:::binned_pal(scales::manual_pal(unname(pal))), na.value = na.value
  #                #,n.breaks = 10
  #               # ,breaks = seq(min.lim, max.lim, length.out = 10)
  #               # ,limits = c(min.lim, max.lim)
  #                ,guide = guide, ...)
  # }
  
  
  the_plot_1 <- ggplot(data, aes(data[,1],data[,2], z = data[,3]))  +
    # geom_contour_fill(bins = 20) +
    geom_contour_fill() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Com],  " seeding")'))
         ,subtitle =  bquote(atop( tau^{'insp'} == .(combs2[row,1]) ~","~  z == .(combs2[row,2])  )  )
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
    #   scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0, 1, by = 0.2), limits = c(0,1)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3), limits = c(0,0.9))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw(base_size = 20) +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1,
                                           margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"))
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 20, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = -90)
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE, 
      even.steps = FALSE,
      frame.linewidth = 0.55, 
      frame.colour = "black", 
      ticks.colour = "black",
      barheight = 25,
      ticks.linewidth = 0.3
      , title.position = "right"))
  
  
  
  
  
  
  
  the_plot_2 <- ggplot(data, aes(data[,1],data[,2], z = data[,4]))  +
    #  geom_contour_fill(bins = 20) +
    geom_contour_fill() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Cons],  " seeding")'))
         ,subtitle =  bquote(atop( tau^{'insp'} == .(combs2[row,1]) ~","~  z == .(combs2[row,2])  )  )
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
    #    scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0, 1, by = 0.2), limits = c(0,1)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0, 0.9, by = 0.3), limits = c(0,0.9))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw(base_size = 20) +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = -90)
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE, 
      even.steps = FALSE,
      frame.linewidth = 0.55, 
      frame.colour = "black", 
      ticks.colour = "black",
      barheight = 25,
      ticks.linewidth = 0.3
      , title.position = "right"))
  
  the_plot_3 <- ggplot(data, aes(data[,1],data[,2], z = data[,5]))  +
    #  geom_contour_fill(bins = 20) +
    geom_contour_fill() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Nur],  " seeding")'))
         ,subtitle =  bquote(atop( tau^{'insp'} == .(combs2[row,1]) ~","~  z == .(combs2[row,2])  )  )
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
    #   scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0, 1, by = 0.2), limits = c(0,1)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3), limits = c(0,0.9))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw(base_size = 20) +
    theme( plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
           panel.grid.major = element_blank()
           ,panel.grid.minor = element_blank()
           ,panel.background = element_rect(colour = "black", size=0.1 )
           ,legend.position = "right"
           ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
           ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 20, b = 0, l = 0))
           , axis.text.x = element_text(angle = 45, hjust = 1)
           , plot.title = element_text(hjust = 0.5, size = 20)
           , axis.text=element_text(size=20)
           ,legend.text = element_text(size = 20)
           ,legend.title = element_text(size = 20, angle = -90)
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE, 
      even.steps = FALSE,
      frame.linewidth = 0.55, 
      frame.colour = "black", 
      ticks.colour = "black",
      barheight = 25,
      ticks.linewidth = 0.3
      , title.position = "right"))
  
  
  
  the_plot_4 <- ggplot(data, aes(data[,1],data[,2], z = data[,6]))  +
    #  geom_contour_fill(bins = 20) +
    geom_contour_fill() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    
    # scale_fill_fermenter_custom(pal) +
   
    
    labs(title = parse(text=sprintf('paste(N[Ret],  " seeding")'))
         ,subtitle =  bquote(atop( tau^{'insp'} == .(combs2[row,1]) ~","~  z == .(combs2[row,2])  )  )
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
    #  scale_x_continuous(expand=c(0,0)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0, 1, by = 0.2), limits = c(0,1)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3), limits = c(0,0.9))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw(base_size = 20) +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = -90) 
    ) +
    # edit the colourbar...
    guides(fill = guide_colorbar(
      ticks = TRUE, 
      even.steps = FALSE,
      frame.linewidth = 0.55, 
      frame.colour = "black", 
      ticks.colour = "black",
      barheight = 25,
      ticks.linewidth = 0.3
      , title.position = "right"))
  
  
  layout <- '
AB
CD
'
  
  
  the_plot <-  wrap_plots(A = the_plot_1, B = the_plot_2, C= the_plot_3, D = the_plot_4,  design = layout) + plot_layout( guides = "collect")
  #the_plot <- the_plot_1 + the_plot_2 + the_plot_3 + the_plot_4
  
  
  return(the_plot)
}  




row <- 5

#data <- prep.data.fun(combinations, row)
data <- prep.data.fun.2(combinations, row)

#data[,3:6] = log10(data[,3:6])

min(c(data[,3], data[,4], data[,5], data[,6] ), na.rm = TRUE)
min.lim <- 0
max(c(data[,3], data[,4], data[,5], data[,6] ), na.rm = TRUE)
max.lim <- 3*10^7

p.10 <- heatmap.fun(data,
                    legend_name = "Total infections" ,
                    x_label = bquote(atop( alpha^{out} ==  alpha^{'in'})),
                    y_label = "r",
                    min.lim,
                    max.lim,
                    row )


p.10





ggsave(
  filename = paste0("Time_till_20_v_a_in_out_r_tau_", combs2[row,1], "_z_", combs2[row,2], "_heatmap.png"  ),
  device="png",
  width= 1.25*3600,
  height=3600,
  units="px",
  plot=p.10, 
  limitsize = TRUE
)




# prop inf by t=36


min(as.vector(data[,7:10]), na.rm = TRUE)
min.lim <- 0
max(as.vector(data[,7:10]), na.rm = TRUE)
max.lim <- 0.5
data2<- data[,c(1, 2, 7,8,9,10)]

p.11 <- heatmap.fun(data2,
                    legend_name = "Proportion infected by t = 36",
                    x_label = bquote(atop( alpha^{out} ==  alpha^{'in'})),
                    y_label = "r",
                    min.lim,
                    max.lim,
                    row )

ggsave(
  filename = paste0("prop_inf_t_36_v_a_in_out_r_tau_", combs2[row,1], "_z_", combs2[row,2], "_heatmap.png"  ),
  device="png",
  width= 1.25*3600,
  height=3600,
  units="px",
  plot=p.11, 
  limitsize = TRUE
)









# cost benefit analysis (probably not the right term)

# calculate total no. inf in nurseries by t=36. (assume cost of plant is ?1.00)
# Calculate median from 100 X 100 sims. 
# Store Value + cost of inspections per year (cost per inspection: assume ?1000?)




insp.cost.benefit <- function(combinations, row){
  
  
  data <- combinations
  
  # columns for median infected in nurseries by t=36 : for each seeding
  data[,3:6] = NA
  
  
  
  
  for (j in 1:nrow(combinations)) {
    
    
    if(j <11){
      dat <- get(load(paste0("S1_alpha_in_alpha_out", combinations[j,1], "_removal", combinations[j,2],".RData")))
    }
    else{
      
      
      dat <- get(load(paste0("row_", row, "/a_in_out", combinations[j,1], "_removal", combinations[j,2],
                             "insp_freq", combs2[row,1], "rem_start",combs2[row,2], ".RData")))
    }
    
    
    
    for (j2 in 1:4) {
      
      
      mini.dat <- dat[j2, , , , , ]
      
      #  infected in nurseries by t=36
      
      Total.Nur.Inf <-as.vector(mini.dat[,,37,2,3] + mini.dat[,,37,2,4] +
                                  mini.dat[,,37,2,5] + mini.dat[,,37,2,6]) # every 10,000 elements is a time-step
      
      
      data[j, j2+2] = median(  Total.Nur.Inf)# + insp.price*( 12/combs2[row,1] )
    
    }  
    
    
  }
  
  return(data)
}




heatmap.fun <- function(data, legend_name, x_label, y_label, min.lim,  max.lim, sub.title){
  
  
  #  x_label <-x_label
  #  y_label <-y_label
  
  # the_plot below is a contour plot with 20 bins
  # binz <- bins
  
  
  #  pal <- viridis(20, option = "A")
  
  # visualise pallete:
  # show_col(pal)
  
  # scale_fill_fermenter_custom <- function(pal, na.value = "grey50", guide = "coloursteps", aesthetics = "fill", ...) {
  #   binned_scale("fill", "fermenter", ggplot2:::binned_pal(scales::manual_pal(unname(pal))), na.value = na.value
  #                #,n.breaks = 10
  #               # ,breaks = seq(min.lim, max.lim, length.out = 10)
  #               # ,limits = c(min.lim, max.lim)
  #                ,guide = guide, ...)
  # }
  
  
  the_plot_1 <- ggplot(data, aes(data[,1],data[,2], z = data[,3]))  +
    # geom_contour_fill(bins = 20) +
    geom_contour_fill() + 
 #   geom_contour_tanaka( ) +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
    #geom_contour_filled(breaks = c(min.lim*c(1, 0.75, 0.5, 0.25), 0, max.lim*c(0.25, 0.5, 0.75, 1)  )) + 
    #scale_fill_brewer(palette = "Spectral") +
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Com],  " seeding")'))
         ,subtitle =  sub.title 
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
    #   scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0, 1, by = 0.2), limits = c(0,1)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3), limits = c(0,0.9))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw(base_size = 20) +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1,
                                           margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"))
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 20, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = 0)
    ) +
    # edit the colourbar...
  guides(fill = guide_colorbar(
    ticks = TRUE,
     even.steps = FALSE,
     frame.linewidth = 0.55,
     frame.colour = "black",
     ticks.colour = "black",
     barheight = 25,
     ticks.linewidth = 0.3
     , title.position = "right"))
  
  
  
  
  
  
  
  the_plot_2 <- ggplot(data, aes(data[,1],data[,2], z = data[,4]))  +
    #  geom_contour_fill(bins = 20) +
    geom_contour_fill() + 
#    geom_contour_tanaka() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
  #  geom_contour_filled(breaks = c(min.lim*c(1, 0.75, 0.5, 0.25), 0, max.lim*c(0.25, 0.5, 0.75, 1)  )) + 
  #  scale_fill_brewer(palette = "Spectral") +
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Cons],  " seeding")'))
         ,subtitle =  sub.title
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
    #    scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0, 1, by = 0.2), limits = c(0,1)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0, 0.9, by = 0.3), limits = c(0,0.9))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw(base_size = 20) +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = 0)
    ) +
    # edit the colourbar...
  guides(fill = guide_colorbar(
    ticks = TRUE,
    even.steps = FALSE,
    frame.linewidth = 0.55,
    frame.colour = "black",
    ticks.colour = "black",
    barheight = 25,
    ticks.linewidth = 0.3
     , title.position = "right"))
#  
  the_plot_3 <- ggplot(data, aes(data[,1],data[,2], z = data[,5]))  +
    #  geom_contour_fill(bins = 20) +
    geom_contour_fill() + 
#    geom_contour_tanaka() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
  #  geom_contour_filled(breaks = c(min.lim*c(1, 0.75, 0.5, 0.25), 0, max.lim*c(0.25, 0.5, 0.75, 1)  )) + 
   # scale_fill_brewer(palette = "Spectral") +
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Nur],  " seeding")'))
         ,subtitle =  sub.title
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
    #   scale_x_continuous(expand=c(0,0.9)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0, 1, by = 0.2), limits = c(0,1)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3), limits = c(0,0.9))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw(base_size = 20) +
    theme( plot.margin = margin(t = 0, r = 30, b = 0, l = 0, unit = "pt"),
           panel.grid.major = element_blank()
           ,panel.grid.minor = element_blank()
           ,panel.background = element_rect(colour = "black", size=0.1 )
           ,legend.position = "right"
           ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
           ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 20, b = 0, l = 0))
           , axis.text.x = element_text(angle = 45, hjust = 1)
           , plot.title = element_text(hjust = 0.5, size = 20)
           , axis.text=element_text(size=20)
           ,legend.text = element_text(size = 20)
           ,legend.title = element_text(size = 20, angle = 0)
    ) +
    # edit the colourbar...
   guides(fill = guide_colorbar(
     ticks = TRUE,
     even.steps = FALSE,
     frame.linewidth = 0.55,
     frame.colour = "black",
     ticks.colour = "black",
     barheight = 25,
     ticks.linewidth = 0.3
     , title.position = "right"))
  
  
  
  the_plot_4 <- ggplot(data, aes(data[,1],data[,2], z = data[,6]))  +
    #  geom_contour_fill(bins = 20) +
    geom_contour_fill() + 
#    geom_contour_tanaka() +
    scale_fill_viridis(limits = c(min.lim, max.lim), option = "magma") +
   # geom_contour_filled(breaks = c(min.lim*c(1, 0.75, 0.5, 0.25), 0, max.lim*c(0.25, 0.5, 0.75, 1)  )) + 
  #  scale_fill_brewer(palette = "Spectral")+
    # scale_fill_fermenter_custom(pal) +
    
    
    labs(title = parse(text=sprintf('paste(N[Ret],  " seeding")'))
         ,subtitle =  sub.title
         ,x = x_label
         ,y = as.expression(bquote(.(as.name(y_label))))
         ,fill = legend_name
    ) +
    #  scale_x_continuous(expand=c(0,0)) + 
    scale_y_continuous(expand=c(0,0), breaks = seq(0, 1, by = 0.2), limits = c(0,1)) +
    scale_x_continuous(expand=c(0,0), breaks = seq(0,0.9, by = 0.3), limits = c(0,0.9))+
    # scale_y_continuous(breaks = formatC(seq(0,max(optimal_gamma$y_data), length.out = 6), format = "e", digits = 2))
    theme_bw(base_size = 20) +
    theme(panel.grid.major = element_blank()
          ,panel.grid.minor = element_blank()
          ,panel.background = element_rect(colour = "black", size=0.1)
          ,legend.position = "right"
          ,axis.title.y = element_text(angle = 90, size = 20, margin = margin(t = 0, r = 10, b = 0, l = 0))
          ,axis.title.x = element_text(size = 20, margin = margin(t = 10, r = 10, b = 0, l = 0))
          , axis.text.x = element_text(angle = 45, hjust = 1)
          , plot.title = element_text(hjust = 0.5, size = 20)
          , axis.text=element_text(size=20)
          ,legend.text = element_text(size = 20)
          ,legend.title = element_text(size = 20, angle = 0) 
    ) +
    # edit the colourbar...
   guides( fill = guide_colorbar(
     ticks = TRUE,
     even.steps = FALSE,
     frame.linewidth = 0.55,
     frame.colour = "black",
     ticks.colour = "black",
     barheight = 25,
     ticks.linewidth = 0.3
     , title.position = "right"))
  
  
  layout <- '
AB
CD
'
  
  
  the_plot <-  wrap_plots(A = the_plot_1, B = the_plot_2, C= the_plot_3, D = the_plot_4,  design = layout) + plot_layout( guides = "collect")
  #the_plot <- the_plot_1 + the_plot_2 + the_plot_3 + the_plot_4
  
  
  return(the_plot)
}  



dat1 <- insp.cost.benefit(combinations, row = 1)

dat2 <- insp.cost.benefit(combinations, row = 2)


dat3 <- insp.cost.benefit(combinations, row = 3)

dat4 <- insp.cost.benefit(combinations, row = 4)

dat5 <- insp.cost.benefit(combinations, row = 5)

dat6 <- combinations
wd <- "C:/Users/matth/OneDrive - University of Strathclyde/PhD Stuff/RStudioStuff/Rstudio/Final data work/Static spread/Armadillo_version/Data/Alpha_in_out_removal"
# columns for median infected in nurseries by t=36 : for each seeding
dat6[,3:6] = NA

for (j in 1:nrow(combinations)) {
  
  dat <- get(load(paste0(wd,"/S1_alpha_in_alpha_out", combinations[j,1], "_removal", combinations[j,2],".RData")))
  

  for (j2 in 1:4) {
    
    
    mini.dat <- dat[j2, , , , , ]
    
    #  infected in nurseries by t=36
    
    Total.Nur.Inf <-as.vector(mini.dat[,,37,2,3] + mini.dat[,,37,2,4] +
                                mini.dat[,,37,2,5] + mini.dat[,,37,2,6]) # every 10,000 elements is a time-step
    
    
    dat6[j, j2+2] = median(  Total.Nur.Inf)# + insp.price*( 12/combs2[row,1] )
    
  }  
  
}
# count how many inspections happen in each simulation by t=36
# add as 3rd column to combs2



combs2[,3] = floor((36-combs2[,2])/combs2[,1])

insp.price = 400
{
dat1.1 = dat1
dat2.1 = dat2 
dat3.1 = dat3
dat4.1 = dat4
dat5.1 = dat5
dat6.1 = dat6


dat1.1[,3:6] = dat1[,3:6] + insp.price*160*combs2[1,3] # 35 inspections
dat2.1[,3:6] = dat2[,3:6] + insp.price*160*combs2[2,3] # 11 inspections
dat3.1[,3:6] = dat3[,3:6] + insp.price*160*combs2[3,3] # 5 inspections
dat4.1[,3:6] = dat4[,3:6] + insp.price*160*combs2[4,3] # 11 inspections
dat5.1[,3:6] = dat5[,3:6] + insp.price*160*combs2[5,3] # 5 inspections
dat6.1[,3:6] = dat6[,3:6] + insp.price*160*5           # 5 inspections
}

#sapply(X = c(10^2, 10^3, 10^4, 10^5, 10^6, 10^7), function(X,...){c( min(dat[,3:6] + X*combs2[1,3] - (dat2[,3:6] + X*combs2[2,3] )),
#   max(dat[,3:6] + X*combs2[1,3] - (dat2[,3:6] + X*combs2[2,3] )) )})



# difference in cost between monthly and quarterly inspections

dat100 = dat1.1
dat100[,3:6] = (dat1.1 - dat2.1)[,3:6] 

# if cost() - cost(4) < 0 : better to inspect every month 

P1 <- heatmap.fun(dat100, legend_name = "Cost",
            x_label =  bquote(atop( alpha^{out} ==  alpha^{'in'})),
            y_label = "r",
            min.lim = 0, max.lim =1.7*10^6,
            sub.title = bquote(atop( (tau^{'insp'} == .(combs2[1,1])) ~"-"~  (tau^{'insp'} == .(combs2[2,1]) ) ~","~ "inspection price" == .(insp.price)  )) )




# difference in cost between monthly and bi-annual inspections

dat200 = dat1.1
dat200[,3:6] = (dat1.1 - dat3.1)[,3:6] 


# if cost() - cost(4) < 0 : better to inspect every month 

P1 <- heatmap.fun(dat200, legend_name = "Cost",
                  x_label =  bquote(atop( alpha^{out} ==  alpha^{'in'})),
                  y_label = "r",
                  min.lim = 0, max.lim =3*10^6,
                  sub.title = bquote(atop( (tau^{'insp'} == .(combs2[1,1])) ~"-"~  (tau^{'insp'} == .(combs2[3,1]) ) ~","~ "inspection price" == .(insp.price)  )) )








ggsave(
  filename = paste0("prop_inf_t_36_v_a_in_out_z_1_tau_6_1_insp_costs_", insp.price,"_heatmap.png"),
  device="png",
  width= 1.5*3600,
  height=3600,
  units="px",
  plot=P1, 
  limitsize = TRUE
)





# difference in cost between quarterly and bi-annual inspections

dat300 = dat2.1
dat300[,3:6] = (dat2.1 - dat3.1)[,3:6] 


# if cost() - cost(4) < 0 : better to inspect every month 

P1 <- heatmap.fun(dat300, legend_name = "Cost",
                  x_label =  bquote(atop( alpha^{out} ==  alpha^{'in'})),
                  y_label = "r",
                  min.lim = 0, max.lim =1.5*10^6,
                  sub.title = bquote(atop( (tau^{'insp'} == .(combs2[2,1])) ~"-"~  (tau^{'insp'} == .(combs2[3,1]) ) ~","~ "inspection price" == .(insp.price)  )) )


P1


ggsave(
  filename = paste0("prop_inf_t_36_v_a_in_out_z_1_tau_6_3_insp_costs_", insp.price,"_heatmap.png"),
  device="png",
  width= 1.5*3600,
  height=3600,
  units="px",
  plot=P1, 
  limitsize = TRUE
)


# difference in average of (tau=3, z=1 z=3) against (tau=1, z=1)
insp.price = 200
{
  dat1.1 = dat1
  dat2.1 = dat2 
  dat3.1 = dat3
  dat4.1 = dat4
  dat5.1 = dat5
  dat6.1 = dat6
  
  
  dat1.1[,3:6] = dat1[,3:6] + insp.price*160*combs2[1,3] # 35 inspections
  dat2.1[,3:6] = dat2[,3:6] + insp.price*160*combs2[2,3] # 11 inspections
  dat3.1[,3:6] = dat3[,3:6] + insp.price*160*combs2[3,3] # 5 inspections
  dat4.1[,3:6] = dat4[,3:6] + insp.price*160*combs2[4,3] # 11 inspections
  dat5.1[,3:6] = dat5[,3:6] + insp.price*160*combs2[5,3] # 5 inspections
  dat6.1[,3:6] = dat6[,3:6] + insp.price*160*5           # 5 inspections
}
P1 <- heatmap.fun(cbind( dat4.1[,1:2], (dat1.1[,3:6] - (dat4.1[,3:6] + dat2.1[,3:6])/2 ) ), legend_name = "Cost",
                  x_label =  bquote(atop( alpha^{out} ==  alpha^{'in'})),
                  y_label = "r",
                  min.lim = 0, max.lim =2.0*10^6,
                  sub.title = bquote(atop( (tau^{'insp'} == .(combs2[1,1])) ~"-"~  (tau^{'insp'} == .(combs2[2,1]) ) ~","~ "inspection price" == .(insp.price)  )) )


#P1


ggsave(
  filename = paste0("prop_inf_t_36_v_a_in_out_z_AVG_tau_3_1_insp_costs_", insp.price,"_heatmap.png"),
  device="png",
  width= 1.5*3600,
  height=3600,
  units="px",
  plot=P1, 
  limitsize = TRUE
)



# difference in average of (tau=6, z=1 z=3, z=6) against (tau=3, z=1, z=3)


P1 <- heatmap.fun(cbind( dat2.1[,1:2], ((dat2.1[,3:6] + dat4.1[,3:6])/2  - (dat3.1[,3:6] + dat5.1[,3:6] + dat6.1[,3:6])/3 ) ), legend_name = "Cost",
                  x_label =  bquote(atop( alpha^{out} ==  alpha^{'in'})),
                  y_label = "r",
                  min.lim = 0, max.lim =1.5*10^6,
                  sub.title = bquote(atop( (tau^{'insp'} == .(combs2[2,1])) ~"-"~  (tau^{'insp'} == .(combs2[3,1]) ) ~","~ "inspection price" == .(insp.price)  )) )

P1

ggsave(
  filename = paste0("prop_inf_t_36_v_a_in_out_z_AVG_tau_6_3_insp_costs_", insp.price,"_heatmap.png"),
  device="png",
  width= 1.5*3600,
  height=3600,
  units="px",
  plot=P1, 
  limitsize = TRUE
)
