#Read me for the code used in from chapter's 2 and 3 of the thesis.


#"Network_Functions.R"
	o      Code includes a script that constructs the model network 

##The code that conducts the social network analysis seen in chapter 3:

#"small_network_vis.R"
	o	Code that visualises the network/small realisation of the network

#"nursery_distribution_analysis.R" (with plotting code "plotting_nursery_distribution_analysis.R") 
	o	This code produces the analysis where we consider the 7 different scenarios of initial nursery distributions on the network  

#"out_deg_mean_var.R" (with plotting code "plotting_out_deg_mean_var_analysis.R")
	o	Code for conducting (& plotting) the sensitivity analysis seen in chapter 3 for changing the out-degree mean and variance parameters. 

#"Consignmnet_Distribution_Analysis_parallel.R" (with plotting code "Plotting_Consignment_Distribution_Analysis.R")

	o	Code to conduct analysis (and plot) where we change the parameters that control how many plants each customer group buys per consignment

#"In_Out_Degree_Analysis.R"

	o	Code to plot the histograms for in-degrees and out-degrees per node group